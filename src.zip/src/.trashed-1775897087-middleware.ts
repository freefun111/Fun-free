import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
 
export function middleware(request: NextRequest) {
  // This middleware is intentionally kept simple to not interfere with routing.
  return NextResponse.next();
}
 
export const config = {
  matcher: [
    // Match all paths except for static files, images, and API routes.
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
