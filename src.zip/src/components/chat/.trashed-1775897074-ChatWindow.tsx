'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Phone, MoreVertical, Send, Paperclip, Loader2, X } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useUser, useFirestore, useDoc, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc, query, orderBy, Timestamp, limitToLast } from 'firebase/firestore';
import type { Chat, ChatMessage } from '@/lib/chat';
import { sendMessage, markChatAsRead } from '@/lib/chat';
import { toDate } from 'date-fns';
import { useTranslation } from 'react-i18next';
import { useRouter } from 'next/navigation';
import { useChat } from '@/providers/ChatProvider';

export function ChatWindow({ chatId }: { chatId: string }) {
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const [newMessage, setNewMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const { i18n, t } = useTranslation();
  const { closeChat } = useChat();

  const formatTimestamp = (timestamp: Timestamp | undefined): string => {
    if (!timestamp) return '';

    const date = toDate(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
    const now = new Date();

    const yesterday = new Date();
    yesterday.setDate(now.getDate() - 1);
    
    const locale = i18n.language === 'ar' ? 'ar-DZ' : i18n.language === 'fr' ? 'fr-FR' : 'en-US';

    if (date.toDateString() === now.toDateString()) {
      return date.toLocaleTimeString(locale, {
        hour: '2-digit',
        minute: '2-digit'
      });
    }

    if (date.toDateString() === yesterday.toDateString()) {
      return `${t('Common.yesterday')} ${date.toLocaleTimeString(locale, {
        hour: '2-digit',
        minute: '2-digit'
      })}`;
    }

    return date.toLocaleDateString(locale) + " " +
           date.toLocaleTimeString(locale, {
             hour: '2-digit',
             minute: '2-digit'
           });
  };

  const chatDocRef = useMemoFirebase(() => (firestore && chatId ? doc(firestore, 'chats', chatId) : null), [firestore, chatId]);
  const { data: chat, isLoading: isChatLoading } = useDoc<Chat>(chatDocRef);
  
  const messagesQuery = useMemoFirebase(() => {
    if (!firestore || !chatId) return null;
    return query(collection(firestore, 'chats', chatId, 'messages'), orderBy('createdAt', 'asc'), limitToLast(20));
  }, [firestore, chatId]);
  const { data: messages, isLoading: areMessagesLoading } = useCollection<ChatMessage>(messagesQuery);
  
  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [isUserLoading, user, router]);

  useEffect(() => {
    if (
      !isChatLoading &&
      chat &&
      user &&
      firestore &&
      chat.lastMessageSenderId !== user.uid
    ) {
      const lastReadMs = chat.lastReadBy?.[user.uid]?.toMillis();
      const lastMessageMs = chat.lastMessageTimestamp?.toMillis();

      if (!lastReadMs || (lastMessageMs && lastMessageMs > lastReadMs)) {
        markChatAsRead(firestore, chatId, user.uid);
      }
    }
  }, [isChatLoading, chat, user, firestore, chatId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSending || !firestore || !chatId || !user || !newMessage.trim()) return;

    setIsSending(true);
    const messageText = newMessage.trim();
    setNewMessage('');

    try {
        await sendMessage(firestore, chatId, user.uid, messageText);
    } catch (error) {
        console.error("Failed to send message:", error);
        setNewMessage(messageText);
    } finally {
        setIsSending(false);
    }
  };
  
  const isLoading = isUserLoading || isChatLoading || areMessagesLoading;
  
  if (isLoading) {
    return (
        <div className="flex-1 flex items-center justify-center bg-background">
            <Loader2 className="size-8 animate-spin text-primary" />
        </div>
    );
  }

  if (!user) {
    return (
        <div className="flex-1 flex items-center justify-center bg-background">
            <p className="text-muted-foreground">{t('Chat.redirectToLogin')}</p>
        </div>
    );
  }

  if (!chat) {
      return (
          <div className="flex-1 flex flex-col pt-16 pb-24 bg-background">
              <h2 className="text-lg font-bold leading-tight text-center p-4">{t('Chat.notFound')}</h2>
              <main className="flex-1 flex items-center justify-center">
                  <p className="text-muted-foreground">{t('Chat.notFoundDescription')}</p>
              </main>
          </div>
      );
  }

  const otherParticipantId = chat.participantIds.find(id => id !== user.uid);
  const otherParticipant = otherParticipantId ? chat.participants[otherParticipantId] : null;

  return (
    <div className="flex flex-col h-full bg-background">
      {otherParticipant && (
        <div className="flex flex-row items-center gap-3 p-3 border-b text-right shrink-0">
            <Avatar className="size-10 border-2 border-primary/20">
                <AvatarImage src={otherParticipant.photoURL} alt={otherParticipant.name} />
                <AvatarFallback>{otherParticipant.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <p className="text-base font-bold leading-tight tracking-tight">{otherParticipant.name}</p>
                <p className="text-xs text-muted-foreground">{chat.jobTitle}</p>
            </div>
            <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon">
                    <Phone className="size-5" />
                </Button>
                <Button variant="ghost" size="icon">
                    <MoreVertical className="size-5" />
                </Button>
                <Button variant="ghost" size="icon" onClick={closeChat}>
                    <X className="size-5" />
                </Button>
            </div>
        </div>
      )}
      
      <main className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages && messages.map((msg) => {
            const sender = msg.senderId === user.uid ? 'me' : 'recipient';
            const senderAvatar = sender === 'me' 
                ? user?.photoURL
                : otherParticipant?.photoURL;
          return (
          <div key={msg.id} className={`flex items-end gap-3 ${sender === 'me' ? 'flex-row-reverse' : ''}`}>
             <Avatar className="size-8">
                <AvatarImage src={senderAvatar || ''} />
                <AvatarFallback>{sender === 'me' ? 'M' : 'R'}</AvatarFallback>
             </Avatar>
            <div className={`max-w-[70%] rounded-xl p-3 ${sender === 'me' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-secondary rounded-bl-none'}`}>
              <p className="text-sm">{msg.text}</p>
              <p className={`text-xs mt-1 ${sender === 'me' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{formatTimestamp(msg.createdAt)}</p>
            </div>
          </div>
        )})}
        <div ref={messagesEndRef} />
      </main>

      <footer className="bg-background/95 p-3 border-t shrink-0">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            <Button size="icon" variant="ghost" type="button" disabled={isSending}>
                <Paperclip className="size-5 text-muted-foreground" />
            </Button>
          <Input
            type="text"
            placeholder={t('Chat.writePlaceholder')}
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 h-11 bg-secondary border-none focus-visible:ring-1 focus-visible:ring-primary"
            autoComplete="off"
            disabled={isSending}
          />
          <Button type="submit" size="icon" className="size-11 shrink-0" disabled={isSending}>
            {isSending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-5" />}
          </Button>
        </form>
      </footer>
    </div>
  );
}
