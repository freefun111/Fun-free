'use client';

import { useState, useMemo } from 'react';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import type { Job } from '@/lib/jobs';
import type { UserProfile } from '@/lib/users';
import { approveJob, rejectJob, deleteJobAsAdmin } from '@/lib/admin';
import { updateUserStatus } from '@/lib/users';

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, XCircle, Trash2, Shield, User, BarChart2, DollarSign, Users, FileText } from 'lucide-react';
import Image from 'next/image';
import { formatDistanceToNow, toDate } from 'date-fns';
import { ar, fr, enUS } from 'date-fns/locale';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

// --- Helper Functions and Types ---
type ActionType = 'approve' | 'reject' | 'deleteJob' | 'ban' | 'unban';

const packageDetails: { [key: string]: { name: string; basePrice: number } } = {
    sponsored: { name: 'الممولة', basePrice: 500 },
    premium: { name: 'المميزة', basePrice: 1000 },
};

const durationPricing: { [key: number]: { name: string; multiplier: number } } = {
    7: { name: '7 أيام', multiplier: 1 },
    15: { name: '15 يوم', multiplier: 1.8 },
    30: { name: '30 يوم', multiplier: 3.5 },
};

const calculatePrice = (job: Job): number => {
    if (job.packageType === 'regular' || !job.durationDays) return 0;
    const pkg = packageDetails[job.packageType];
    const dur = durationPricing[job.durationDays];
    if (!pkg || !dur) return 0;
    return Math.round(pkg.basePrice * dur.multiplier);
};

const getStatusBadgeVariant = (status: Job['status']) => {
    switch (status) {
        case 'active': return 'default';
        case 'pending_review': return 'secondary';
        case 'expired': return 'outline';
        case 'rejected': return 'destructive';
        default: return 'secondary';
    }
};
const getPackageBadgeVariant = (packageType: Job['packageType']) => {
    switch (packageType) {
        case 'premium': return 'destructive';
        case 'sponsored': return 'secondary';
        default: return 'outline';
    }
};


// --- Sub-components ---

const StatCard = ({ title, value, icon: Icon, description }: { title: string; value: string | number; icon: React.ElementType; description?: string }) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </CardContent>
    </Card>
);

const AdsManager = ({ jobs, isLoading, formatTimestamp }: { jobs: Job[], isLoading: boolean, formatTimestamp: (ts: any) => string }) => {
    const [filter, setFilter] = useState('all');
    const firestore = useFirestore();
    
    const filteredJobs = useMemo(() => {
        if (filter === 'all') return jobs;
        return jobs.filter(job => job.status === filter);
    }, [jobs, filter]);

    const handleAction = async (action: ActionType, id: string, durationDays?: number | null) => {
        try {
            switch (action) {
                case 'approve': await approveJob(firestore, id, durationDays); break;
                case 'reject': await rejectJob(firestore, id); break;
                case 'deleteJob': await deleteJobAsAdmin(firestore, id); break;
            }
        } catch (error) {
            console.error(`Admin action ${action} failed for job ${id}:`, error);
        }
    };

    if (isLoading) return <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>;

    return (
        <div className="space-y-4">
            <div className="flex gap-2">
                <Button variant={filter === 'all' ? 'default' : 'outline'} onClick={() => setFilter('all')}>الكل</Button>
                <Button variant={filter === 'pending_review' ? 'default' : 'outline'} onClick={() => setFilter('pending_review')}>قيد المراجعة</Button>
                <Button variant={filter === 'active' ? 'default' : 'outline'} onClick={() => setFilter('active')}>مفعّلة</Button>
            </div>
            <div className="space-y-4">
                {filteredJobs.length === 0 ? <p className="text-muted-foreground text-center p-8">لا توجد إعلانات تطابق هذا الفلتر.</p> : null}
                {filteredJobs.map(job => (
                    <Card key={job.id}>
                        <CardHeader>
                            <div className="flex justify-between items-start">
                                <div>
                                    <CardTitle className="text-base">{job.title}</CardTitle>
                                    <p className="text-sm text-muted-foreground">{job.company}</p>
                                </div>
                                <div className="flex gap-2">
                                    <Badge variant={getPackageBadgeVariant(job.packageType)}>{job.packageType}</Badge>
                                    <Badge variant={getStatusBadgeVariant(job.status)}>{job.status}</Badge>
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="text-sm space-y-4">
                           <p className="text-muted-foreground line-clamp-2">{job.description}</p>
                           <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs">
                               <span>تاريخ: {formatTimestamp(job.createdAt)}</span>
                               <span>الموقع: {job.location}</span>
                               <span>الراتب: {job.salary}</span>
                           </div>
                           {job.paymentReceipt && job.status === 'pending_review' && (
                                <div className="space-y-2">
                                    <p className="font-semibold text-xs">وصل الدفع:</p>
                                    <a href={job.paymentReceipt} target="_blank" rel="noopener noreferrer">
                                        <Image src={job.paymentReceipt} alt="وصل الدفع" width={150} height={150} className="rounded-md border object-cover"/>
                                    </a>
                                </div>
                           )}
                           <div className="flex gap-2 pt-2 border-t">
                               {job.status === 'pending_review' && (
                                   <Button size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50 hover:text-green-700" onClick={() => handleAction('approve', job.id, job.durationDays)}><CheckCircle className="me-2 size-4"/> قبول</Button>
                               )}
                               {job.status === 'pending_review' && (
                                   <Button size="sm" variant="outline" className="text-red-600 border-red-600 hover:bg-red-50 hover:text-red-700" onClick={() => handleAction('reject', job.id)}><XCircle className="me-2 size-4"/> رفض</Button>
                               )}
                                <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                        <Button size="sm" variant="destructive" className="me-auto"><Trash2 className="me-2 size-4"/> حذف</Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                        <AlertDialogHeader>
                                            <AlertDialogTitle>هل أنت متأكد من حذف هذا الإعلان؟</AlertDialogTitle>
                                            <AlertDialogDescription>لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
                                        </AlertDialogHeader>
                                        <AlertDialogFooter>
                                            <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                            <AlertDialogAction onClick={() => handleAction('deleteJob', job.id)}>تأكيد الحذف</AlertDialogAction>
                                        </AlertDialogFooter>
                                    </AlertDialogContent>
                                </AlertDialog>
                           </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}

const UsersManager = ({ users, isLoading, formatTimestamp }: { users: UserProfile[], isLoading: boolean, formatTimestamp: (ts: any) => string }) => {
    const firestore = useFirestore();

    const handleAction = async (action: ActionType, id: string) => {
        try {
            switch (action) {
                case 'ban': await updateUserStatus(firestore, id, 'banned'); break;
                case 'unban': await updateUserStatus(firestore, id, 'active'); break;
            }
        } catch (error) {
            console.error(`Admin action ${action} failed for user ${id}:`, error);
        }
    };

    if (isLoading) return <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>;

    return (
        <div className="space-y-4">
             {users.map(user => (
                 <Card key={user.id}>
                     <CardHeader>
                         <div className="flex justify-between items-center">
                            <div>
                                <CardTitle className="text-base flex items-center gap-2">
                                    {user.name}
                                    {user.role === 'admin' && <Shield className="size-4 text-primary"/>}
                                </CardTitle>
                                <p className="text-sm text-muted-foreground">{user.email}</p>
                            </div>
                            <Badge variant={user.status === 'active' ? 'default' : 'destructive'}>{user.status}</Badge>
                         </div>
                     </CardHeader>
                     <CardContent className="text-xs">
                        <div className="flex justify-between items-center">
                            <p>تاريخ التسجيل: {formatTimestamp(user.createdAt)}</p>
                            {user.role !== 'admin' && (
                                <div className="flex gap-2">
                                    {user.status === 'active' ? (
                                        <Button size="sm" variant="destructive" onClick={() => handleAction('ban', user.id)}>حظر المستخدم</Button>
                                    ) : (
                                        <Button size="sm" variant="outline" onClick={() => handleAction('unban', user.id)}>فك الحظر</Button>
                                    )}
                                </div>
                            )}
                        </div>
                     </CardContent>
                 </Card>
             ))}
        </div>
    );
};

const StatsDashboard = ({ jobs, users, isLoading }: { jobs: Job[], users: UserProfile[], isLoading: boolean }) => {
    
    const stats = useMemo(() => {
        if (!jobs || !users) return null;
        
        const totalUsers = users.length;
        const totalAds = jobs.length;
        
        const paidJobs = jobs.filter(j => j.status === 'active' && j.packageType !== 'regular');
        const totalRevenue = paidJobs.reduce((sum, job) => sum + calculatePrice(job), 0);

        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
        const monthlyRevenue = jobs.filter(j => {
            if (j.status !== 'active' || j.packageType === 'regular' || !j.updatedAt) return false;
            const activationDate = toDate((j.updatedAt as Timestamp).seconds * 1000);
            return activationDate > oneMonthAgo;
        }).reduce((sum, job) => sum + calculatePrice(job), 0);
        
        return {
            totalUsers,
            totalAds,
            paidAdsCount: paidJobs.length,
            totalRevenue,
            monthlyRevenue,
        };
    }, [jobs, users]);

    if (isLoading || !stats) return <div className="flex justify-center p-8"><Loader2 className="animate-spin" /></div>;

    return (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <StatCard title="إجمالي المستخدمين" value={stats.totalUsers} icon={Users} />
            <StatCard title="إجمالي الإعلانات" value={stats.totalAds} icon={FileText} />
            <StatCard title="الإعلانات المدفوعة" value={stats.paidAdsCount} icon={BarChart2} />
            <StatCard title="الدخل الإجمالي" value={`${stats.totalRevenue.toLocaleString('fr-FR')} دج`} icon={DollarSign} />
            <StatCard title="الدخل آخر 30 يوم" value={`${stats.monthlyRevenue.toLocaleString('fr-FR')} دج`} icon={DollarSign} />
        </div>
    );
};


// --- Main Component ---

export function AdminDashboard() {
    const firestore = useFirestore();
    const { t, i18n } = useTranslation();
    const locales: { [key: string]: Locale } = { ar, fr, en: enUS };


    const formatTimestamp = (timestamp: any): string => {
        if (!timestamp) return t('JobDetails.unavailable');
        try {
            const date = toDate(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
            return formatDistanceToNow(date, { addSuffix: true, locale: locales[i18n.language] });
        } catch (e) {
            return new Date(timestamp).toLocaleDateString(i18n.language);
        }
    };


    const jobsQuery = useMemoFirebase(() => query(collection(firestore, 'jobs'), orderBy('createdAt', 'desc')), [firestore]);
    const usersQuery = useMemoFirebase(() => query(collection(firestore, 'users'), orderBy('createdAt', 'desc')), [firestore]);
    
    const { data: jobs, isLoading: jobsLoading } = useCollection<Job>(jobsQuery);
    const { data: users, isLoading: usersLoading } = useCollection<UserProfile>(usersQuery);

    const isLoading = jobsLoading || usersLoading;

    return (
        <div className="container mx-auto py-6">
            <h1 className="text-2xl font-bold mb-4">لوحة التحكم الإدارية</h1>
            <Tabs defaultValue="ads" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="ads">الإعلانات</TabsTrigger>
                    <TabsTrigger value="users">المستخدمون</TabsTrigger>
                    <TabsTrigger value="stats">الإحصائيات</TabsTrigger>
                </TabsList>
                <TabsContent value="ads" className="pt-4">
                    <AdsManager jobs={jobs || []} isLoading={isLoading} formatTimestamp={formatTimestamp} />
                </TabsContent>
                <TabsContent value="users" className="pt-4">
                    <UsersManager users={users || []} isLoading={isLoading} formatTimestamp={formatTimestamp} />
                </TabsContent>
                <TabsContent value="stats" className="pt-4">
                    <StatsDashboard jobs={jobs || []} users={users || []} isLoading={isLoading} />
                </TabsContent>
            </Tabs>
        </div>
    );
}
