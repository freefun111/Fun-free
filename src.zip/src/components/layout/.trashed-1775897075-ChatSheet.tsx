'use client';

import { MessageSquare, Loader2, Inbox } from 'lucide-react';
import { useMemo } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, where, limit } from 'firebase/firestore';
import type { Chat } from '@/lib/chat';
import { useRouter } from 'next/navigation';
import { formatDistanceToNow, toDate } from 'date-fns';
import { ar, enUS, fr } from 'date-fns/locale';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';
import { useChat } from '@/providers/ChatProvider';

const locales: {[key: string]: Locale} = { ar, en: enUS, fr };

export function ChatSheet({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();
    const { t, i18n } = useTranslation();
    const { openChat } = useChat();

    const formatTimestamp = (timestamp: any): string => {
        if (!timestamp) return '';
        try {
            const date = toDate(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
            return formatDistanceToNow(date, { addSuffix: true, locale: locales[i18n.language] });
        } catch (e) {
            return '';
        }
    };

    const chatsQuery = useMemoFirebase(() => {
        if (!firestore || !user) return null;
        return query(
            collection(firestore, 'chats'),
            where('participantIds', 'array-contains', user.uid),
            limit(50)
        );
    }, [firestore, user]);

    const { data: unsortedConversations, isLoading: areConversationsLoading } = useCollection<Chat>(chatsQuery);

    const conversations = useMemo(() => {
        if (!unsortedConversations) return [];
        return [...unsortedConversations].sort((a, b) => {
            const timeA = a.updatedAt?.seconds || 0;
            const timeB = b.updatedAt?.seconds || 0;
            return timeB - timeA;
        });
    }, [unsortedConversations]);

    const handleChatClick = (chatId: string) => {
        onOpenChange(false);
        openChat(chatId);
    };

    const isLoading = isUserLoading || areConversationsLoading;

    return (
        <Sheet open={open} onOpenChange={onOpenChange}>
            <SheetContent className="p-0 flex flex-col" onOpenAutoFocus={(e) => e.preventDefault()}>
                <SheetHeader className="p-6 pb-2 border-b">
                    <SheetTitle>{t('Header.messages')}</SheetTitle>
                </SheetHeader>
                <ScrollArea className="flex-1">
                     <div className="p-6 pt-4 space-y-1">
                        {isLoading && (
                            <div className="flex justify-center py-10">
                                <Loader2 className="size-8 animate-spin text-primary" />
                            </div>
                        )}
                        {!isLoading && conversations.length === 0 && (
                            <div className="text-center py-10 text-muted-foreground">
                                <Inbox className="mx-auto size-12 mb-4" />
                                <p className="font-semibold">{t('Notifications.noNotifications')}</p>
                                <p className="text-sm">{t('Notifications.allQuiet')}</p>
                            </div>
                        )}
                        {conversations.map(convo => {
                            const otherUserId = convo.participantIds.find(id => id !== user?.uid);
                            if (!otherUserId) return null;

                            const otherParticipant = convo.participants[otherUserId];
                            const isUnread = convo.lastMessageSenderId && convo.lastMessageSenderId !== user?.uid;
                            
                            return (
                                <button
                                    key={convo.id}
                                    onClick={() => handleChatClick(convo.id)}
                                    className="flex items-center gap-4 p-3 rounded-lg w-full text-right hover:bg-secondary transition-colors"
                                >
                                    <Avatar className="size-10 border-2 border-primary/20">
                                        <AvatarImage src={otherParticipant.photoURL} alt={otherParticipant.name} />
                                        <AvatarFallback>{otherParticipant.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1 min-w-0">
                                        <div className="grid grid-cols-[1fr_auto] items-start gap-2">
                                            <p className="font-bold truncate text-sm">{otherParticipant.name}</p>
                                            <p className="text-xs text-muted-foreground whitespace-nowrap shrink-0">{formatTimestamp(convo.updatedAt)}</p>
                                        </div>
                                        <p className={cn("text-xs text-muted-foreground break-words", isUnread && convo.lastMessageText && "font-bold text-foreground")}>
                                            {convo.lastMessageText || '...'}
                                        </p>
                                    </div>
                                </button>
                            );
                        })}
                    </div>
                </ScrollArea>
            </SheetContent>
        </Sheet>
    )
}
