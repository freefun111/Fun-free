'use client';

import React, { useState, useEffect } from 'react';
import { User, LogOut, Sun, Moon, Menu, LogIn, UserPlus, Home, Shield, HelpCircle, Info, Share2, Link as LinkIcon, Search, Globe, PlusCircle, MessageSquare, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet"
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTheme } from '@/components/providers/theme-provider';
import { useUser, useAuth } from '@/firebase';
import { useIsMobile } from '@/hooks/use-mobile';
import { useHasMounted } from '@/hooks/use-has-mounted';
import { ChatSheet } from './ChatSheet';
import { NotificationsSheet } from './NotificationsSheet';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';
import { useUnreadChats } from '@/hooks/useUnreadChats';
import { useUnreadNotifications } from '@/hooks/useUnreadNotifications';
import { Badge } from '@/components/ui/badge';


function ProfileMenu({ onOpenChat, onOpenNotifications }: { onOpenChat: () => void, onOpenNotifications: () => void }) {
    const { user, isUserLoading } = useUser();
    const auth = useAuth();
    const router = useRouter();
    const { theme, setTheme } = useTheme();
    const { t, i18n } = useTranslation();
    const { unreadCount: unreadChatsCount } = useUnreadChats();
    const { unreadCount: unreadNotifsCount } = useUnreadNotifications();

    const handleLogout = async () => {
        if (!auth) return;
        await auth.signOut();
        router.push('/login');
    };

    if (isUserLoading) {
        return <div className="size-9 rounded-full bg-muted animate-pulse" />;
    }

    if (!user) {
        return (
            <Link href="/login" aria-label={t('Header.profile')}>
                <Button>
                    {t('Auth.login')}
                </Button>
            </Link>
        )
    }

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 p-1 h-auto rounded-full">
                    <Avatar className="size-9 border-2 border-primary/20">
                        <AvatarImage src={user.photoURL || ''} alt={user.displayName || 'User'} />
                        <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64" align="end" dir={i18n.dir()}>
                <DropdownMenuLabel>
                    <p className="font-bold truncate">{user.displayName}</p>
                    <p className="text-xs text-muted-foreground font-normal truncate">{user.email}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link href="/profile">
                    <DropdownMenuItem>
                        <User className="me-2 opacity-70" />
                        <span>{t('Header.profile')}</span>
                    </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={(e) => { e.preventDefault(); onOpenChat(); }}>
                    <MessageSquare className="me-2 opacity-70" />
                    <span>{t('Header.messages')}</span>
                    {unreadChatsCount > 0 && <Badge variant="destructive" className="ms-auto">{unreadChatsCount > 9 ? '9+' : unreadChatsCount}</Badge>}
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={(e) => { e.preventDefault(); onOpenNotifications(); }}>
                    <Bell className="me-2 opacity-70" />
                    <span>{t('Header.notifications')}</span>
                    {unreadNotifsCount > 0 && <Badge variant="destructive" className="ms-auto">{unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}</Badge>}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
                    <Moon className="me-2 opacity-70" />
                    <span>{t('Header.toggleTheme')}</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                    <LogOut className="me-2 opacity-70" />
                    <span>{t('Header.logout')}</span>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    )
}

function MobileSidebar({ onOpenChat, onOpenNotifications }: { onOpenChat: () => void, onOpenNotifications: () => void }) {
    const { user } = useUser();
    const auth = useAuth();
    const { theme, setTheme } = useTheme();
    const router = useRouter();
    const { toast } = useToast();
    const { t, i18n } = useTranslation();
    const { unreadCount: unreadChatsCount } = useUnreadChats();
    const { unreadCount: unreadNotifsCount } = useUnreadNotifications();

    const handleLogout = async () => {
        if (!auth) return;
        await auth.signOut();
        router.push('/login');
    };

    const toggleLanguage = () => {
        const newLang = i18n.language === 'ar' ? 'en' : 'ar';
        i18n.changeLanguage(newLang);
    };

    const handleShareApp = () => {
        if (navigator.share) {
          navigator.share({
            title: t('Share.shareAppTitle'),
            text: t('Share.shareAppText'),
            url: window.location.origin,
          }).catch((error) => {
              if (error.name === 'AbortError') return;
              navigator.clipboard.writeText(window.location.origin);
              toast({
                  title: t('Share.unavailableTitle'),
                  description: t('Share.unavailableDescription'),
              });
          });
        } else {
          navigator.clipboard.writeText(window.location.origin);
          toast({
            title: t('Share.linkCopiedTitle'),
            description: t('Share.linkCopiedDescription'),
          });
        }
    };

    return (
        <Sheet>
            <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                    <Menu />
                    <span className="sr-only">Open menu</span>
                </Button>
            </SheetTrigger>
            <SheetContent side={i18n.dir() === 'rtl' ? 'right' : 'left'} className="flex flex-col p-0">
                <SheetHeader className='p-4'>
                    <SheetTitle>
                        <SheetClose asChild>
                            <Link href="/" className="flex items-center">
                                <h1 className="text-xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
                            </Link>
                        </SheetClose>
                    </SheetTitle>
                </SheetHeader>
                
                <div className="flex-1 overflow-y-auto">
                    {user && (
                         <div className="p-4 border-y">
                            <div className="flex items-center gap-3">
                                <Avatar className="size-10 border-2 border-primary/20">
                                    <AvatarImage src={user.photoURL || ''} alt={user.displayName || 'User'} />
                                    <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
                                </Avatar>
                                <div className='flex-1 min-w-0'>
                                    <p className="font-bold truncate">{user.displayName}</p>
                                    <p className="text-xs text-muted-foreground font-normal truncate">{user.email}</p>
                                </div>
                            </div>
                        </div>
                    )}

                    <nav className="flex flex-col p-2">
                        <SheetClose asChild>
                            <Link href="/" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                                <Home className="size-5" />
                                <span>{t('Header.home')}</span>
                            </Link>
                        </SheetClose>
                        {user && (
                           <>
                            <SheetClose asChild>
                                <Link href="/profile" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                                    <User className="size-5" />
                                    <span>{t('Header.profile')}</span>
                                </Link>
                            </SheetClose>
                            <Separator className="my-1" />
                            <SheetClose asChild>
                                <Button variant="ghost" className="w-full justify-start items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary" onClick={onOpenChat}>
                                    <MessageSquare className="size-5" />
                                    <span>{t('Header.messages')}</span>
                                    {unreadChatsCount > 0 && <Badge variant="destructive" className="ms-auto">{unreadChatsCount > 9 ? '9+' : unreadChatsCount}</Badge>}
                                </Button>
                            </SheetClose>
                            <SheetClose asChild>
                                <Button variant="ghost" className="w-full justify-start items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary" onClick={onOpenNotifications}>
                                    <Bell className="size-5" />
                                    <span>{t('Header.notifications')}</span>
                                    {unreadNotifsCount > 0 && <Badge variant="destructive" className="ms-auto">{unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}</Badge>}
                                </Button>
                            </SheetClose>
                           </>
                        )}
                    </nav>

                    <Separator className="my-1" />

                     <div className="px-3 pt-2 text-xs font-semibold uppercase text-muted-foreground/80 tracking-wider">
                        {t('ProfilePage.accountManagement')}
                    </div>
                     <nav className="flex flex-col p-2">
                        <SheetClose asChild>
                            <Link href="/privacy" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                                <Shield className="size-5" />
                                <span>{t('ProfilePage.privacySecurityTitle')}</span>
                            </Link>
                        </SheetClose>
                        <SheetClose asChild>
                            <Link href="/help" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                                <HelpCircle className="size-5" />
                                <span>{t('ProfilePage.helpCenterTitle')}</span>
                            </Link>
                        </SheetClose>
                        <SheetClose asChild>
                            <Link href="/about" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                                <Info className="size-5" />
                                <span>{t('ProfilePage.aboutAppTitle')}</span>
                            </Link>
                        </SheetClose>
                        <div onClick={handleShareApp} className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary cursor-pointer">
                            <Share2 className="size-5" />
                            <span>{t('ProfilePage.share')}</span>
                        </div>
                    </nav>
                    
                    <Separator className="my-1" />

                    <nav className="flex flex-col p-2">
                        <Button variant="ghost" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="flex w-full justify-start items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                           {theme === 'dark' ? <Sun className="size-5" /> : <Moon className="size-5" />}
                           <span>{t('Header.toggleTheme')}</span>
                        </Button>
                        <SheetClose asChild>
                           <Button variant="ghost" onClick={toggleLanguage} className="flex w-full justify-start items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary">
                               <Globe className="size-5" />
                               <span>{i18n.language === 'ar' ? t('Header.switchToEnglish') : t('Header.switchToArabic')}</span>
                           </Button>
                        </SheetClose>
                    </nav>
                </div>
                
                <div className="mt-auto border-t p-3">
                    {user ? (
                        <SheetClose asChild>
                            <Button variant="outline" onClick={handleLogout} className="w-full text-destructive hover:text-destructive">
                                <LogOut className="me-2" />
                                {t('Header.logout')}
                            </Button>
                        </SheetClose>
                    ) : (
                        <div className="flex flex-col gap-2">
                            <SheetClose asChild>
                                <Link href="/login" passHref>
                                <Button className="w-full">
                                        <LogIn className="me-2" />
                                        {t('Auth.login')}
                                    </Button>
                                </Link>
                            </SheetClose>
                            <SheetClose asChild>
                                <Link href="/signup" passHref>
                                    <Button variant="outline" className="w-full">
                                        <UserPlus className="me-2" />
                                        {t('Auth.signup')}
                                    </Button>
                                </Link>
                            </SheetClose>
                        </div>
                    )}
                </div>
            </SheetContent>
        </Sheet>
    )
}

export function Header() {
  const isMobile = useIsMobile();
  const hasMounted = useHasMounted();
  const { user } = useUser();
  const { t, i18n } = useTranslation();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const searchParams = useSearchParams();
  const urlQuery = searchParams.get('q');
  const [searchTerm, setSearchTerm] = useState(urlQuery || '');
  const [isChatSheetOpen, setIsChatSheetOpen] = useState(false);
  const [isNotificationsSheetOpen, setIsNotificationsSheetOpen] = useState(false);

  useEffect(() => {
    setSearchTerm(urlQuery || '');
  }, [urlQuery]);


  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
  };
  
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const term = searchTerm.trim();
    if (term) {
        router.push(`/?q=${encodeURIComponent(term)}`);
    } else {
        router.push('/');
    }
  };

  const WelcomeMessage = () => {
      if (!user || !user.displayName) {
          return (
             <Link href="/" className="flex items-center gap-2">
                <h1 className="text-2xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
            </Link>
          );
      }
      const firstName = user.displayName?.split(' ')[0];
      const message = !firstName
          ? t('Header.welcomeVisitor')
          : t('Header.welcome', { name: firstName });
      
      return <p className="font-semibold text-foreground">{message}</p>;
  }

  return (
    <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-md dark:bg-background/80">
      <div className="container mx-auto flex h-14 items-center justify-between gap-4 px-4">
        <div className="flex items-center gap-2 md:hidden">
            {hasMounted ? <WelcomeMessage /> : (
                <Link href="/" className="flex items-center gap-2">
                    <h1 className="text-2xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
                </Link>
            )}
        </div>
        
        <div className="hidden md:flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2">
                <LinkIcon className="size-7 text-primary" />
                <h1 className="text-3xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
            </Link>
        </div>

        <div className="hidden md:flex flex-1 justify-center items-center gap-4 px-8">
            <form onSubmit={handleSearchSubmit} className="relative w-full max-w-lg">
                <Input
                    placeholder={t('Header.searchPlaceholder')}
                    className="h-11 rounded-full bg-secondary ps-12 pe-4"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button
                    type="submit"
                    variant="ghost"
                    size="icon"
                    className="absolute top-1/2 -translate-y-1/2 left-2 rtl:right-2 rtl:left-auto"
                    aria-label="Search"
                >
                    <Search className="size-5 text-muted-foreground" />
                </Button>
            </form>
            <Link href="/add-ad">
                <Button className="h-11 bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg shadow-accent/30">
                    <PlusCircle className="me-2 size-5" />
                    {t('Header.addAd')}
                </Button>
            </Link>
        </div>
        
        <div className="flex items-center gap-1 md:gap-2">
            <div className="hidden md:flex items-center gap-1">
                 <Button variant="ghost" size="sm" onClick={toggleLanguage} className="font-bold text-sm">
                    <Globe className="size-4 me-1.5" />
                    {i18n.language === 'ar' ? 'EN' : 'العربية'}
                </Button>
                <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={t('Header.toggleTheme')}>
                    <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                    <span className="sr-only">{t('Header.toggleTheme')}</span>
                </Button>
                <ProfileMenu onOpenChat={() => setIsChatSheetOpen(true)} onOpenNotifications={() => setIsNotificationsSheetOpen(true)} />
            </div>
             <div className="md:hidden">
                {hasMounted && isMobile ? <MobileSidebar onOpenChat={() => setIsChatSheetOpen(true)} onOpenNotifications={() => setIsNotificationsSheetOpen(true)} /> : null}
            </div>
        </div>
      </div>
      <ChatSheet open={isChatSheetOpen} onOpenChange={setIsChatSheetOpen} />
      <NotificationsSheet open={isNotificationsSheetOpen} onOpenChange={setIsNotificationsSheetOpen} />
    </header>
  );
}
