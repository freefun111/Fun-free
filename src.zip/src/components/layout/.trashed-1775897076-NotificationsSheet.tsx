'use client';

import { Bell, Loader2, MailCheck } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit, doc, updateDoc } from 'firebase/firestore';
import type { Notification } from '@/lib/notifications';
import { useRouter } from 'next/navigation';
import { formatDistanceToNow, toDate } from 'date-fns';
import { ar, enUS, fr } from 'date-fns/locale';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useTranslation } from 'react-i18next';

const locales: {[key: string]: Locale} = { ar, en: enUS, fr };

export function NotificationsSheet({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();
    const router = useRouter();
    const { t, i18n } = useTranslation();
    
    function formatTimestamp(timestamp: any): string {
        if (!timestamp) return 'غير متوفر';
        try {
            const date = toDate(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
            return formatDistanceToNow(date, { addSuffix: true, locale: locales[i18n.language] });
        } catch (e) {
            return new Date(timestamp).toLocaleDateString(i18n.language);
        }
    };


    const notificationsQuery = useMemoFirebase(() => {
        if (!firestore || !user) return null;
        return query(collection(firestore, 'users', user.uid, 'notifications'), orderBy('createdAt', 'desc'), limit(20));
    }, [firestore, user]);

    const { data: notifications, isLoading: areNotificationsLoading } = useCollection<Notification>(notificationsQuery);

    const handleNotificationClick = async (notification: Notification) => {
        onOpenChange(false);
        if (!user || !firestore) return;
        if (!notification.isRead) {
            const notifRef = doc(firestore, 'users', user.uid, 'notifications', notification.id);
            await updateDoc(notifRef, { isRead: true });
        }
        router.push(notification.link);
    };
    
    const isLoading = isUserLoading || areNotificationsLoading;

    return (
        <Sheet open={open} onOpenChange={onOpenChange}>
            <SheetContent className="p-0 flex flex-col" onOpenAutoFocus={(e) => e.preventDefault()}>
                <SheetHeader className="p-6 pb-2 border-b">
                    <SheetTitle>{t('Notifications.title')}</SheetTitle>
                </SheetHeader>
                <ScrollArea className="flex-1">
                    <div className="p-6 pt-4 space-y-3">
                        {isLoading && (
                            <div className="flex justify-center py-10">
                                <Loader2 className="size-8 animate-spin text-primary" />
                            </div>
                        )}
                        {!isLoading && notifications?.length === 0 && (
                            <div className="text-center py-10 text-muted-foreground">
                                <MailCheck className="mx-auto size-12 mb-4" />
                                <p className="font-semibold">{t('Notifications.noNotifications')}</p>
                                <p className="text-sm">{t('Notifications.allQuiet')}</p>
                            </div>
                        )}
                        {notifications?.map(notification => (
                             <div
                                key={notification.id}
                                role="button"
                                tabIndex={0}
                                onClick={() => handleNotificationClick(notification)}
                                onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && handleNotificationClick(notification)}
                                className={`w-full text-right p-3 rounded-lg transition-colors cursor-pointer ${
                                    notification.isRead
                                    ? 'bg-transparent hover:bg-secondary/50'
                                    : 'bg-primary/10 hover:bg-primary/20'
                                }`}
                            >
                                <p className="font-bold text-sm break-words">{notification.title}</p>
                                <p className="text-xs text-muted-foreground mt-1 break-words">{notification.body}</p>
                                <p className="text-xs text-muted-foreground/80 mt-2">{formatTimestamp(notification.createdAt)}</p>
                            </div>
                        ))}
                    </div>
                </ScrollArea>
            </SheetContent>
        </Sheet>
    )
}
