'use client';

import { Home, Briefcase, GraduationCap, Plus, User } from 'lucide-react';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';

export function BottomNav() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentListingType = searchParams.get('listingType');
  const { t } = useTranslation();

  const navItems = [
    { href: '/', icon: Home, label: t('BottomNav.home'), listingType: null },
    { href: '/?listingType=jobs', icon: Briefcase, label: t('BottomNav.jobs'), listingType: 'jobs' },
    { href: '/add-ad', icon: Plus, label: t('BottomNav.addAd'), isCenter: true },
    { href: '/?listingType=training', icon: GraduationCap, label: t('BottomNav.trainings'), listingType: 'training' },
    { href: '/profile', icon: User, label: t('BottomNav.myAccount') },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-background/95 dark:bg-background/95 border-t border-border/50 backdrop-blur-xl z-40 md:hidden">
      <div className="max-w-lg mx-auto flex justify-around items-center h-14 px-2">
        {navItems.map((item) => {
          if (item.isCenter) {
            return (
              <Link
                key={item.label}
                href={item.href}
                className="relative -top-4"
              >
                <div className="flex items-center justify-center size-14 bg-primary rounded-full shadow-lg shadow-primary/30">
                  <item.icon className="size-7 text-primary-foreground" />
                </div>
              </Link>
            );
          }
          
          let isActive = false;
          if (item.listingType !== undefined) {
              isActive = pathname === '/' && currentListingType === item.listingType;
          } else {
              isActive = pathname === item.href;
          }


          return (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                'flex flex-col items-center justify-center gap-1 transition-colors w-16 h-full',
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <item.icon className="size-6" fill={isActive ? 'currentColor' : 'none'} />
              <span className="text-[10px] font-bold">{item.label}</span>
            </Link>
          );
        })}
      </div>
      <div className="h-[env(safe-area-inset-bottom)] bg-transparent"></div>
    </nav>
  );
}
