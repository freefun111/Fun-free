
'use client';

import React from 'react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

export function Footer() {
  const { toast } = useToast();
  const { t } = useTranslation();

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: t('Share.shareAppTitle'),
        text: t('Share.shareAppText'),
        url: window.location.origin,
      })
      .catch((error) => {
        if (error.name === 'AbortError') return;
        navigator.clipboard.writeText(window.location.origin);
        toast({
          title: t('Share.unavailableTitle'),
          description: t('Share.unavailableDescription'),
        });
      });
    } else {
      navigator.clipboard.writeText(window.location.origin);
      toast({
        title: t('Share.linkCopiedTitle'),
        description: t('Share.linkCopiedDescription'),
      });
    }
  };

  return (
    <footer className="bg-secondary text-secondary-foreground mt-auto hidden md:block">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h2 className="text-xl font-black text-foreground">{t('Header.title')}</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              {t('ProfilePage.appVersion')}
            </p>
          </div>
          <div>
            <h3 className="text-base font-semibold text-foreground">{t('Footer.quickLinks')}</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li><Link href="/" className="text-muted-foreground hover:text-foreground">{t('Header.home')}</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-base font-semibold text-foreground">{t('Footer.contactUs')}</h3>
            <ul className="mt-4 space-y-2 text-sm">
                <li><button onClick={handleShare} className="text-muted-foreground hover:text-foreground">{t('ProfilePage.share')}</button></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-4 text-center text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} {t('Header.title')}. {t('Footer.allRightsReserved')}</p>
        </div>
      </div>
    </footer>
  );
}
