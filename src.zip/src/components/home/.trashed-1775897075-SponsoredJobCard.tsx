
import * as React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { MapPin, Crown, Star, Eye, Heart } from 'lucide-react';
import type { Job, JobImage } from '@/lib/jobs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { useTranslation } from 'react-i18next';

interface SponsoredJobCardProps {
  job: Job;
}

export function SponsoredJobCard({ job }: SponsoredJobCardProps) {
  const { t } = useTranslation();
  const displayImage: JobImage | undefined = (job.images && job.images.length > 0)
    ? job.images[0]
    : PlaceHolderImages.find((img) => img.id === 'job-detail-1');

  return (
    <Link href={`/jobs/${job.id}`} className="block group">
      <div className="relative rounded-lg p-[2px] bg-gradient-to-tr from-amber-400 via-primary to-amber-300 shadow-xl">
        <Card className="overflow-hidden rounded-md bg-card border-0">
          <div className="relative h-80 w-full">
            {displayImage ? (
              <Image
                src={displayImage.imageUrl}
                alt={job.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
                data-ai-hint={displayImage.imageHint}
                placeholder="blur"
                blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
              />
            ) : (
              <div className="w-full h-full bg-secondary flex items-center justify-center p-4 text-center">
                <p className="text-muted-foreground text-lg font-semibold">{job.company}</p>
              </div>
            )}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
            <div className="absolute top-2 left-2 pointer-events-none">
              {job.packageType === 'premium' ? (
                <Badge
                  variant="default"
                  className="flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-amber-500 text-black shadow-lg border-yellow-300/50 py-1 px-2.5"
                >
                  <Crown className="size-3.5 fill-black" />
                  <span className="font-bold text-xs">{t('JobCard.recommended')}</span>
                </Badge>
              ) : (
                <Badge
                  variant="default"
                  className="flex items-center gap-2 bg-gradient-to-r from-sky-400 to-cyan-500 text-white shadow-lg border-sky-300/50 py-1 px-2.5"
                >
                  <Star className="size-3.5 fill-white" />
                  <span className="font-bold text-xs">{t('JobCard.popular')}</span>
                </Badge>
              )}
            </div>
            <div className="absolute bottom-0 p-3 text-right w-full pointer-events-none">
              <h3 className="text-white text-xl font-bold leading-tight line-clamp-2">
                {job.title}
              </h3>
              <p className="text-slate-100 text-xs font-medium mt-0.5">{job.company}</p>
              <div className="mt-2 flex items-center justify-between text-slate-200 text-xs">
                <div className="flex items-center gap-3">
                  {(job.views || 0) > 0 && (
                      <div className="flex items-center gap-1">
                          <Eye className="size-3.5" /> 
                          <span>{job.views}</span>
                      </div>
                  )}
                  {(job.likes || 0) > 0 && (
                      <div className="flex items-center gap-1">
                          <Heart className="size-3.5" />
                          <span>{job.likes}</span>
                      </div>
                  )}
                  {(job.ratingCount || 0) > 0 && (
                       <div className="flex items-center gap-1">
                          <Star className="size-3.5" />
                          <span>{job.averageRating?.toFixed(1)}</span>
                      </div>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="size-3" /> 
                  <span>{job.location}</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </Link>
  );
}
