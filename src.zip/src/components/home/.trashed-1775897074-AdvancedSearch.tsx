
'use client';

import * as React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Search } from 'lucide-react';

import { wilayas } from '@/lib/wilayas';
import { useTranslation } from 'react-i18next';

import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
  SheetClose
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';

const allKeywords = [
  "مطور ويب", "مطور برمجيات", "مطور Laravel", "مصمم واجهات", "مصمم UX/UI",
  "كهربائي صناعي", "تقني صيانة", "سائق توصيل", "سائق شاحنة", "مدرس لغة انجليزية",
  "ممرض", "مسوق رقمي", "خبير SEO", "مهندس مدني", "بناء", "سباك", "نجار",
  "محاسب", "مدير مبيعات", "مندوب مبيعات", "خدمة عملاء", "طباخ", "مساعد مطبخ",
  "نادل", "مدير فندق", "استقبال فندقي", "حارس أمن", "عامل نظافة", "ميكانيكي سيارات"
];

const formSchema = z.object({
  keywords: z.string().min(1, { message: 'الرجاء إدخال كلمة مفتاحية للبحث.' }),
  wilaya: z.string().optional(),
  salary: z.string().optional(),
  accommodation: z.boolean().default(false).optional(),
  meals: z.boolean().default(false).optional(),
  transport: z.boolean().default(false).optional(),
});

export type SearchCriteria = z.infer<typeof formSchema>;

type AdvancedSearchProps = {
  onSearch: (criteria: SearchCriteria) => void;
};

export function AdvancedSearch({ onSearch }: AdvancedSearchProps) {
  const [open, setOpen] = React.useState(false);
  const [keywordSuggestions, setKeywordSuggestions] = React.useState<string[]>([]);
  const { toast } = useToast();
  const { t } = useTranslation();


  const form = useForm<SearchCriteria>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      keywords: '',
      wilaya: 'all',
      salary: '',
      accommodation: false,
      meals: false,
      transport: false,
    },
  });

  const keywordsValue = form.watch('keywords');

  React.useEffect(() => {
    if (keywordsValue && keywordsValue.length >= 2) {
      const filtered = allKeywords.filter(k =>
        k.toLowerCase().includes(keywordsValue.toLowerCase())
      );
      setKeywordSuggestions(filtered);
    } else {
      setKeywordSuggestions([]);
    }
  }, [keywordsValue]);

  function onSubmit(values: SearchCriteria) {
    onSearch(values);
    setOpen(false);
    setKeywordSuggestions([]);
    toast({
      title: t('AdvancedSearch.toastTitle'),
      description: t('AdvancedSearch.toastDescription'),
    });
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <div className="fixed bottom-24 start-4 z-30 md:bottom-6">
          <Button size="icon" className="rounded-full shadow-2xl w-14 h-14 hover:scale-105 active:scale-95 transition-all" aria-label={t('HomePage.advancedSearch')}>
            <Search className="size-6" />
          </Button>
        </div>
      </SheetTrigger>
      <SheetContent side="bottom" className="max-w-lg mx-auto rounded-t-xl h-[90dvh] p-4 flex flex-col">
        <SheetHeader className="text-right px-2">
          <SheetTitle>{t('AdvancedSearch.title')}</SheetTitle>
          <SheetDescription>
            {t('AdvancedSearch.description')}
          </SheetDescription>
        </SheetHeader>
        <div className="flex-1 overflow-y-auto px-2 py-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="keywords"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('AdvancedSearch.keywordsLabel')}</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          className="h-14 text-base"
                          placeholder={t('AdvancedSearch.keywordsPlaceholder')}
                          {...field}
                          autoComplete="off"
                        />
                        {keywordSuggestions.length > 0 && (
                          <div className="absolute z-10 w-full mt-1 bg-card border border-border rounded-md shadow-lg">
                            <ul className="max-h-48 overflow-auto py-1">
                              {keywordSuggestions.map((suggestion, index) => (
                                <li
                                  key={index}
                                  className="px-3 py-2 text-sm hover:bg-secondary cursor-pointer"
                                  onClick={() => {
                                    form.setValue('keywords', suggestion);
                                    setKeywordSuggestions([]);
                                  }}
                                  onMouseDown={(e) => e.preventDefault()} // Prevents input blur on click
                                >
                                  {suggestion}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="wilaya"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('AdvancedSearch.wilayaLabel')}</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="h-14 text-base">
                          <SelectValue placeholder={t('AdvancedSearch.wilayaPlaceholder')} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="all">{t('AdvancedSearch.allWilayas')}</SelectItem>
                        {wilayas.map(w => <SelectItem key={w.code} value={w.name}>{`${w.code.toString().padStart(2, '0')} - ${w.name}`}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="salary"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('AdvancedSearch.salaryLabel')}</FormLabel>
                    <FormControl>
                      <Input className="h-14 text-base" placeholder={t('AdvancedSearch.salaryPlaceholder')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div>
                <FormLabel>{t('AdvancedSearch.benefitsLabel')}</FormLabel>
                <div className="space-y-2 mt-2">
                   <FormField
                    control={form.control}
                    name="accommodation"
                    render={({ field }) => (
                      <FormItem className="flex flex-row-reverse items-center justify-end gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          {t('AdvancedSearch.accommodation')}
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="meals"
                    render={({ field }) => (
                      <FormItem className="flex flex-row-reverse items-center justify-end gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          {t('AdvancedSearch.meals')}
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="transport"
                    render={({ field }) => (
                      <FormItem className="flex flex-row-reverse items-center justify-end gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="font-normal cursor-pointer">
                          {t('AdvancedSearch.transport')}
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </form>
          </Form>
        </div>
        <SheetFooter className="p-2">
           <div className="flex gap-2 w-full">
            <Button
                onClick={form.handleSubmit(onSubmit)}
                disabled={form.formState.isSubmitting}
                className="w-full h-12"
              >
                {t('AdvancedSearch.searchJobs')}
              </Button>
            <SheetClose asChild>
                <Button variant="outline" className="w-full h-12">{t('AdvancedSearch.cancel')}</Button>
            </SheetClose>
           </div>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
