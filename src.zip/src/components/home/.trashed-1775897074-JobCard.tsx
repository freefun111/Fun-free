'use client';

import Image from 'next/image';
import Link from 'next/link';
import { MapPin, Star, Crown, Eye, Heart } from 'lucide-react';
import type { Job } from '@/lib/jobs';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AdImageFade from './AdImageFade';
import { useTranslation } from 'react-i18next';

interface JobCardProps {
  job: Job;
}

export function JobCard({ job }: JobCardProps) {
    const { t } = useTranslation();
    const firstImage = job.images?.[0];
    const isRegular = job.packageType === 'regular';
    const hasImages = job.images && job.images.length > 0;

    // Paid Ad Card
    if (!isRegular) {
        return (
            <Link href={`/jobs/${job.id}`} className="block group">
                <Card className="overflow-hidden rounded-lg shadow-sm transition-shadow hover:shadow-md bg-card border">
                    <div className="relative w-full h-80">
                        {hasImages ? (
                            <AdImageFade images={job.images} interval={2500} />
                        ) : (
                            <div className="w-full h-full bg-secondary flex items-center justify-center p-4 text-center">
                                <p className="text-muted-foreground text-lg font-semibold">{job.company}</p>
                            </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                        
                        <div className="absolute top-3 left-3 flex flex-wrap items-center gap-2">
                            <Badge variant={job.adType === 'offer' ? 'default' : 'secondary'}>
                                {t(job.adType === 'offer' ? 'JobCard.offer' : 'JobCard.request')}
                            </Badge>
                            {job.packageType === 'premium' && (
                                <Badge variant="outline" className="gap-1.5 border-amber-400 bg-amber-950/40 text-amber-300 backdrop-blur-sm">
                                    <Crown className="size-3.5 fill-amber-400 text-amber-400" />
                                    {t('JobCard.recommended')}
                                </Badge>
                            )}
                            {job.packageType === 'sponsored' && (
                                <Badge variant="outline" className="gap-1.5 border-yellow-400 bg-yellow-950/40 text-yellow-300 backdrop-blur-sm">
                                    <Star className="size-3.5 fill-yellow-400 text-yellow-400" />
                                    {t('JobCard.popular')}
                                </Badge>
                            )}
                        </div>

                        <div className="absolute top-3 right-3 flex items-center gap-2">
                            <Badge variant="outline" className="font-normal bg-black/20 text-white border-white/50 backdrop-blur-sm">{job.category}</Badge>
                        </div>

                        <div className="absolute bottom-0 p-3 text-right w-full">
                            <h3 className="text-white font-bold text-lg leading-tight line-clamp-2">
                                {job.title}
                            </h3>
                            
                             <div className="flex items-center justify-between gap-2 text-slate-200 text-xs mt-2">
                                <div className="flex items-center gap-2">
                                    {(job.views || 0) > 0 && (
                                        <div className="flex items-center gap-1">
                                            <Eye className="size-3.5" /> 
                                            <span>{job.views}</span>
                                        </div>
                                    )}
                                    {(job.likes || 0) > 0 && (
                                        <div className="flex items-center gap-1">
                                            <Heart className="size-3.5" />
                                            <span>{job.likes}</span>
                                        </div>
                                    )}
                                     {(job.ratingCount || 0) > 0 && (
                                        <div className="flex items-center gap-1">
                                            <Star className="size-3.5" />
                                            <span>{job.averageRating?.toFixed(1)}</span>
                                        </div>
                                    )}
                                </div>
                                <div className="flex items-center gap-1">
                                    <MapPin className="size-3.5" /> 
                                    <span>{job.location}</span>
                                </div>
                            </div>

                            <div className="flex items-center justify-end gap-2 mt-1">
                                <p className="font-bold text-base text-white">
                                    {job.salary}
                                </p>
                            </div>

                        </div>
                    </div>
                </Card>
            </Link>
        );
    }
    
    // Regular Ad Card
    return (
        <Link href={`/jobs/${job.id}`} className="block group h-full">
            <Card className="h-full overflow-hidden rounded-lg shadow-sm transition-shadow hover:shadow-md bg-card border p-0 flex sm:flex-col items-start sm:items-stretch">
                {/* Image Section */}
                <div className="relative size-28 sm:size-auto sm:w-full sm:h-40 shrink-0">
                     {firstImage?.imageUrl ? (
                        <Image
                            src={firstImage.imageUrl}
                            alt={job.title}
                            fill
                            className="object-cover rounded-r-lg sm:rounded-r-none sm:rounded-t-lg"
                            sizes="(max-width: 640px) 112px, (max-width: 1024px) 50vw, 33vw"
                            data-ai-hint={firstImage.imageHint}
                            loading="lazy"
                            placeholder="blur"
                            blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
                        />
                    ) : (
                        <div className="w-full h-full bg-secondary flex items-center justify-center text-center rounded-r-lg sm:rounded-r-none sm:rounded-t-lg">
                             <p className="text-muted-foreground text-sm font-semibold p-2">{job.company}</p>
                        </div>
                    )}
                     <div className="absolute top-2 right-2">
                        <Badge variant={job.adType === 'offer' ? 'default' : 'secondary'} className="text-[10px] px-1.5 py-0">
                            {t(job.adType === 'offer' ? 'JobCard.offer' : 'JobCard.request')}
                        </Badge>
                    </div>
                </div>

                {/* Details Section */}
                <div className="flex-1 p-2 pt-3 sm:p-3 sm:pt-2 w-full flex flex-col justify-between">
                    <div>
                        <p className="text-xs text-muted-foreground">{job.category}</p>
                        <h3 className="font-bold leading-tight line-clamp-2 mt-0.5 text-sm sm:text-base">
                            {job.title}
                        </h3>
                         <div className="flex items-center gap-1 mt-1 text-muted-foreground text-xs">
                            <MapPin className="size-3.5" /> 
                            <span className="truncate">{job.location}</span>
                        </div>
                    </div>
                    
                    <div className="mt-2 flex items-end justify-between gap-2 text-xs">
                       <div className="flex items-center gap-2 text-muted-foreground">
                            {(job.views || 0) > 0 && (
                                <div className="flex items-center gap-1">
                                    <Eye className="size-3.5" />
                                    <span>{job.views}</span>
                                </div>
                            )}
                            {(job.likes || 0) > 0 && (
                                <div className="flex items-center gap-1">
                                    <Heart className="size-3.5" />
                                    <span>{job.likes}</span>
                                </div>
                            )}
                            {(job.ratingCount || 0) > 0 && (
                                <div className="flex items-center gap-1">
                                    <Star className="size-3.5" />
                                    <span>{job.averageRating?.toFixed(1)}</span>
                                </div>
                            )}
                        </div>
                        <p className="font-bold text-primary text-sm whitespace-nowrap">
                            {job.salary}
                        </p>
                    </div>
                </div>
            </Card>
        </Link>
    );
}
