"use client";

import { useEffect, useState } from "react";
import Image from 'next/image';
import type { JobImage } from "@/lib/jobs";

type Props = {
  images: JobImage[];
  interval?: number; // بالميلي ثانية
};

export default function AdImageFade({ images, interval = 2500 }: Props) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (images.length <= 1) return;
    
    let timer: NodeJS.Timeout;

    // Introduce a random delay to de-synchronize the animations
    const randomDelay = Math.random() * interval;

    const timeoutId = setTimeout(() => {
        timer = setInterval(() => {
            setIndex((prev) => (prev + 1) % images.length);
        }, interval);
    }, randomDelay);


    return () => {
        clearTimeout(timeoutId);
        if (timer) {
            clearInterval(timer);
        }
    };
  }, [images, interval]);

  return (
    <div className="relative w-full h-full overflow-hidden">
      {images.map((img, i) => (
        <Image
          key={i}
          src={img.imageUrl}
          alt={img.description || ''}
          fill
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${i === index ? "opacity-100" : "opacity-0"}`}
          sizes="100vw"
          data-ai-hint={img.imageHint}
          loading={i === 0 ? 'eager' : 'lazy'}
          placeholder="blur"
          blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
        />
      ))}
    </div>
  );
}
