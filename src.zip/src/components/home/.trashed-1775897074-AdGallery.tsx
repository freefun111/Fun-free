"use client";

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import type { JobImage } from "@/lib/jobs";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface AdGalleryProps {
  images: JobImage[];
}

export default function AdGallery({ images }: AdGalleryProps) {
  if (!images || images.length === 0) return null;

  const [active, setActive] = useState(images[0].imageUrl);
  const [open, setOpen] = useState(false);

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation(); // Prevent lightbox from closing when button is clicked
    const currentIndex = images.findIndex((img) => img.imageUrl === active);
    const nextIndex = (currentIndex + 1) % images.length;
    setActive(images[nextIndex].imageUrl);
  };

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation(); // Prevent lightbox from closing when button is clicked
    const currentIndex = images.findIndex((img) => img.imageUrl === active);
    const prevIndex = (currentIndex - 1 + images.length) % images.length;
    setActive(images[prevIndex].imageUrl);
  };

  return (
    <>
      <div className="w-full">
        {/* Main Image */}
        <div
          className="w-full h-72 md:h-96 bg-muted rounded-lg overflow-hidden relative cursor-pointer group"
          onClick={() => setOpen(true)}
        >
          <Image
            src={active}
            alt="Main ad image"
            fill
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            sizes="100vw"
            priority
            placeholder="blur"
            blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
          />
          <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />

          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 -translate-y-1/2 size-10 rounded-full bg-background/50 hover:bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0"
                onClick={handlePrev}
              >
                <ChevronLeft className="size-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 size-10 rounded-full bg-background/50 hover:bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0"
                onClick={handleNext}
              >
                <ChevronRight className="size-6" />
              </Button>
            </>
          )}
        </div>

        {/* Thumbnails */}
        {images.length > 1 && (
          <div className="mt-3 hide-scrollbar flex gap-2 overflow-x-auto pb-2">
            {images.map((img, index) => (
              <button
                key={index}
                onClick={() => setActive(img.imageUrl)}
                className={cn(
                  "w-20 h-20 flex-shrink-0 rounded-md overflow-hidden border-2 transition-colors",
                  active === img.imageUrl ? "border-primary" : "border-transparent hover:border-primary/50"
                )}
              >
                <Image
                  src={img.imageUrl}
                  alt={img.description || `Thumbnail ${index + 1}`}
                  width={80}
                  height={80}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      {open && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center"
          onClick={() => setOpen(false)}
        >
          <button
              onClick={() => setOpen(false)}
              className="absolute top-4 right-4 z-[51] rounded-full p-2 bg-black/50 text-white opacity-80 transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-white"
              aria-label="Close image viewer"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
          </button>
          
          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 -translate-y-1/2 size-12 rounded-full bg-black/50 text-white hover:bg-black/80 z-[51]"
                onClick={handlePrev}
              >
                <ChevronLeft className="size-8" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 -translate-y-1/2 size-12 rounded-full bg-black/50 text-white hover:bg-black/80 z-[51]"
                onClick={handleNext}
              >
                <ChevronRight className="size-8" />
              </Button>
            </>
          )}

          <img
            src={active}
            alt="Full screen ad image"
            className="max-w-[85vw] max-h-[95vh] object-contain"
            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking image
          />
        </div>
      )}
    </>
  );
}
