'use client';

import * as React from 'react';
import Autoplay from 'embla-carousel-autoplay';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import type { Job } from '@/lib/jobs';
import { SponsoredJobCard } from './SponsoredJobCard';
import { Skeleton } from '@/components/ui/skeleton';
import { useTranslation } from 'react-i18next';

export function FeaturedPartners({ jobs, isLoading }: { jobs: Job[] | null, isLoading: boolean }) {
  const { t } = useTranslation();
  
  const plugin = React.useRef(
    Autoplay({ delay: 4000, stopOnInteraction: false, stopOnMouseEnter: false })
  );

  if (isLoading) {
    return (
      <section aria-labelledby="featured-ads-title" className="pb-4">
         <h2 id="featured-ads-title" className="text-xl font-bold leading-tight px-4 pb-3">
            {t('HomePage.featuredPartners')}
          </h2>
          <Skeleton className="h-80 w-full rounded-lg" />
      </section>
    );
  }

  if (!jobs || jobs.length === 0) {
    return null;
  }

  return (
    <section aria-labelledby="featured-ads-title" className="pb-4">
       <h2 id="featured-ads-title" className="text-xl font-bold leading-tight px-4 pb-3 md:hidden">
          {t('HomePage.featuredPartners')}
        </h2>
      <Carousel
        plugins={[plugin.current]}
        className="w-full group"
        opts={{
          align: "start",
          loop: jobs.length > 1,
        }}
      >
        <CarouselContent>
          {jobs.map((job) => (
            <CarouselItem key={job.id} className="md:basis-1/2">
              <SponsoredJobCard job={job} />
            </CarouselItem>
          ))}
        </CarouselContent>
        {jobs.length > 2 && (
            <>
                <CarouselPrevious className="absolute left-3 top-1/2 -translate-y-1/2 size-10 bg-background/50 hover:bg-background/80 disabled:hidden opacity-0 group-hover:opacity-100 transition-opacity" />
                <CarouselNext className="absolute right-3 top-1/2 -translate-y-1/2 size-10 bg-background/50 hover:bg-background/80 disabled:hidden opacity-0 group-hover:opacity-100 transition-opacity" />
            </>
        )}
      </Carousel>
    </section>
  );
}
