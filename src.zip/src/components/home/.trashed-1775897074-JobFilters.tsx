'use client';

import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useTranslation } from 'react-i18next';

interface JobFiltersProps {
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
}

export function JobFilters({ activeFilter, setActiveFilter }: JobFiltersProps) {
  const { t } = useTranslation();
  const filters = [
    { label: t('JobFilters.all'), value: 'all' },
    { label: t('JobFilters.jobs'), value: 'jobs' },
    { label: t('JobFilters.trainings'), value: 'training' },
  ];

  return (
    <div className="pb-4 pt-2">
      <div className="flex justify-center">
        <Tabs value={activeFilter} onValueChange={setActiveFilter} className="w-auto">
          <TabsList>
            {filters.map((filter) => (
              <TabsTrigger key={filter.value} value={filter.value} className="text-sm">
                {filter.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>
    </div>
  );
}
