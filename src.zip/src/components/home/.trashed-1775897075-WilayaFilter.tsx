'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { wilayas } from '@/lib/wilayas';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface WilayaFilterProps {
  selectedWilayas: string[];
  onWilayaChange: (wilayas: string[]) => void;
}

export function WilayaFilter({ selectedWilayas, onWilayaChange }: WilayaFilterProps) {
  const { t } = useTranslation();
  const [open, setOpen] = React.useState(false);
  const [localSelection, setLocalSelection] = React.useState<string[]>(selectedWilayas);
  
  React.useEffect(() => {
    if (open) {
      setLocalSelection(selectedWilayas);
    }
  }, [open, selectedWilayas]);


  const handleSelect = (wilayaName: string) => {
    setLocalSelection(prev => 
      prev.includes(wilayaName) 
        ? prev.filter(w => w !== wilayaName)
        : [...prev, wilayaName]
    );
  };

  const handleApply = () => {
    onWilayaChange(localSelection);
    setOpen(false);
  };
  
  const handleClear = () => {
    setLocalSelection([]);
  }

  return (
    <div className="pt-0 pb-4">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="w-full h-11 justify-start text-left font-normal text-muted-foreground">
            {selectedWilayas.length === 0 
              ? t('WilayaFilter.placeholder') 
              : selectedWilayas.length === 1 
                ? selectedWilayas[0]
                : t('WilayaFilter.selected', { count: selectedWilayas.length })
            }
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0">
          <div className="p-4 font-semibold border-b">{t('WilayaFilter.title')}</div>
          <ScrollArea className="h-72">
            <div className="p-4 space-y-3">
              {wilayas.map(wilaya => (
                <div key={wilaya.code} className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id={`wilaya-${wilaya.code}`}
                    checked={localSelection.includes(wilaya.name)}
                    onCheckedChange={() => handleSelect(wilaya.name)}
                  />
                  <Label htmlFor={`wilaya-${wilaya.code}`} className="flex-1 cursor-pointer">
                    {`${wilaya.code.toString().padStart(2, '0')} - ${wilaya.name}`}
                  </Label>
                </div>
              ))}
            </div>
          </ScrollArea>
          <div className="flex justify-end gap-2 p-4 border-t">
            <Button variant="ghost" onClick={handleClear}>{t('WilayaFilter.clearAll')}</Button>
            <Button onClick={handleApply}>{t('WilayaFilter.apply')}</Button>
          </div>
        </PopoverContent>
      </Popover>
      {selectedWilayas.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 pt-3">
            {selectedWilayas.map(w => (
                <Badge key={w} variant="secondary" className="gap-1 ps-3">
                    {w}
                    <button onClick={() => onWilayaChange(selectedWilayas.filter(s => s !== w))} className="p-1 rounded-full hover:bg-muted-foreground/20">
                        <X className="size-3" />
                    </button>
                </Badge>
            ))}
             <Button variant="ghost" size="sm" className="text-xs text-destructive hover:bg-destructive/10 hover:text-destructive h-auto p-1" onClick={() => onWilayaChange([])}>
                {t('WilayaFilter.clearAll')}
            </Button>
          </div>
      )}
    </div>
  );
}
