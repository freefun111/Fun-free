'use client';

import { useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import type { Notification } from '@/lib/notifications';

interface UnreadNotificationsResult {
    unreadCount: number;
    isLoading: boolean;
}

export function useUnreadNotifications(): UnreadNotificationsResult {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const notificationsQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(
        collection(firestore, 'users', user.uid, 'notifications'),
        where('isRead', '==', false)
    );
  }, [firestore, user]);

  const { data: unreadNotifications, isLoading: areNotificationsLoading } = useCollection<Notification>(notificationsQuery);

  return {
      unreadCount: unreadNotifications?.length ?? 0,
      isLoading: isUserLoading || areNotificationsLoading,
  };
}
