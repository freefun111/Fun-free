'use client';

import { useState, useEffect } from 'react';
import { useUser, useFirestore } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';

interface UserDataResult {
    role: string | null;
    isLoading: boolean;
    companyName: string | null;
    firestoreUser: any | null;
}

export function useUserRole(): UserDataResult {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const [role, setRole] = useState<string | null>(null);
  const [companyName, setCompanyName] = useState<string | null>(null);
  const [firestoreUser, setFirestoreUser] = useState<any | null>(null);
  const [isRoleLoading, setIsRoleLoading] = useState(true);

  useEffect(() => {
    if (isUserLoading) {
        return;
    }
    if (!user) {
      setIsRoleLoading(false);
      setRole(null);
      setCompanyName(null);
      setFirestoreUser(null);
      return;
    }

    const fetchUserDoc = async () => {
      if (!firestore) return;
      setIsRoleLoading(true);
      const userDocRef = doc(firestore, 'users', user.uid);
      try {
        const docSnap = await getDoc(userDocRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setRole(data.role || null);
          setCompanyName(data.name || null);
          setFirestoreUser(data);
        } else {
            // This might happen for new users, especially Google sign-in before the doc is created
            setRole('applicant'); // Default assumption
            setCompanyName(user.displayName);
            setFirestoreUser(null);
        }
      } catch (error) {
        console.error("Error fetching user role:", error);
        setRole(null);
        setCompanyName(null);
        setFirestoreUser(null);
      } finally {
        setIsRoleLoading(false);
      }
    };

    fetchUserDoc();
  }, [user, isUserLoading, firestore]);

  return {
      role,
      isLoading: isUserLoading || isRoleLoading,
      companyName,
      firestoreUser,
  };
}
