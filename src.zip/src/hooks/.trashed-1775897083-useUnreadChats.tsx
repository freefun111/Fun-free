

'use client';

import { useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import type { Chat } from '@/lib/chat';

interface UnreadChatsResult {
    unreadCount: number;
    isLoading: boolean;
}

export function useUnreadChats(): UnreadChatsResult {
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const chatsQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(
        collection(firestore, 'chats'), 
        where('participantIds', 'array-contains', user.uid)
    );
  }, [firestore, user]);

  const { data: conversations, isLoading: isConversationsLoading } = useCollection<Chat>(chatsQuery);

  const unreadCount = useMemo(() => {
    if (!conversations || !user) return 0;
    
    return conversations.reduce((count, conv) => {
        // A chat is unread if there's a last message that isn't from the current user
        if (conv.lastMessageSenderId && conv.lastMessageSenderId !== user.uid) {
            const lastMessageTimestamp = conv.lastMessageTimestamp;
            // The user's last read timestamp for this specific conversation
            const userLastReadTimestamp = conv.lastReadBy?.[user.uid];

            // If the user has never read this convo, or the last message is newer than their last read
            if (!userLastReadTimestamp || (lastMessageTimestamp && lastMessageTimestamp > userLastReadTimestamp)) {
                return count + 1;
            }
        }
        return count;
    }, 0);
  }, [conversations, user]);

  return {
      unreadCount: unreadCount,
      isLoading: isUserLoading || isConversationsLoading,
  };
}

    