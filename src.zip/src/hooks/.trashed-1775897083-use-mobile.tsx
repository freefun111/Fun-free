'use client';

import * as React from 'react';
import { useHasMounted } from './use-has-mounted';

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  const hasMounted = useHasMounted();
  const [isMobile, setIsMobile] = React.useState(false);

  React.useEffect(() => {
    if (!hasMounted) return;

    const checkIsMobile = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };

    checkIsMobile();
    window.addEventListener('resize', checkIsMobile);
    return () => window.removeEventListener('resize', checkIsMobile);
  }, [hasMounted]);

  return isMobile;
}
