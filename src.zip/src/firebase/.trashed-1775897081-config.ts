export const firebaseConfig = {
  "projectId": "studio-7733302294-89631",
  "appId": "1:535634514124:web:643c0bcd3e34c19a243269",
  "apiKey": "AIzaSyBOeENUV1KrsKOCWhTxUm0Yu1TiScnZ8Qc",
  "authDomain": "studio-7733302294-89631.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "535634514124"
};
