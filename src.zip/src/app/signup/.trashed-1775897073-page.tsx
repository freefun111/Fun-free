
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, updateProfile } from 'firebase/auth';
import { useAuth, useFirestore } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useTranslation } from 'react-i18next';

const passwordValidation = (t: (key: string) => string) => z.string().min(6, { message: t('Auth.passwordLengthError', { count: 6 }) });
const emailValidation = (t: (key: string) => string) => z.string().email({ message: t('Auth.emailInvalid') });

const getSignupSchema = (t: (key: string) => string) => z.object({
  name: z.string().min(2, { message: t('Auth.nameLengthError', { count: 2 }) }),
  email: emailValidation(t),
  password: passwordValidation(t),
  confirmPassword: passwordValidation(t),
}).refine(data => data.password === data.confirmPassword, {
  message: t('Auth.passwordMismatch'),
  path: ["confirmPassword"],
});


type SignupFormValues = z.infer<ReturnType<typeof getSignupSchema>>;

const GoogleIcon = () => (
    <svg className="size-5" viewBox="0 0 48 48">
      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"></path>
      <path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"></path>
      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.223 0-9.655-3.438-11.303-8H6.306C9.656 39.663 16.318 44 24 44z"></path>
      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-.792 2.237-2.231 4.166-4.087 5.571l6.19 5.238C42.012 35.259 44 30.035 44 24c0-1.341-.138-2.65-.389-3.917z"></path>
    </svg>
);
  
export default function SignupPage() {
  const router = useRouter();
  const auth = useAuth();
  const firestore = useFirestore();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const signupSchema = getSignupSchema(t);

  const form = useForm<SignupFormValues>({ resolver: zodResolver(signupSchema), defaultValues: { name: '', email: '', password: '', confirmPassword: '' } });

  const handleSignup = async (data: SignupFormValues) => {
    setIsLoading(true);
    if (!auth || !firestore) {
        toast({ variant: "destructive", title: t('Common.error'), description: "Firebase not initialized" });
        setIsLoading(false);
        return;
    }
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
        const user = userCredential.user;
        await updateProfile(user, { displayName: data.name });
        
        const userDocData: any = {
            id: user.uid,
            role: 'applicant', // Default role
            name: data.name,
            email: data.email,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            status: 'active',
        };

        await setDoc(doc(firestore, 'users', user.uid), userDocData);
      
        router.push('/profile');

    } catch (error: any) {
      console.error("Signup Error:", error);
      let description = t('Auth.signupErrorUnexpected');
      if (error.code === 'auth/operation-not-allowed') {
        description = t('Auth.signupErrorEmailDisabled');
      } else if (error.code === 'auth/email-already-in-use') {
        description = t('Auth.signupErrorEmailInUse');
      }
      toast({
        variant: "destructive",
        title: t('Auth.signupErrorTitle'),
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    if (!auth || !firestore) {
        toast({ variant: "destructive", title: t('Common.error'), description: "Firebase not initialized" });
        setIsGoogleLoading(false);
        return;
    }
    const provider = new GoogleAuthProvider();
    try {
        const userCredential = await signInWithPopup(auth, provider);
        const user = userCredential.user;
        const userDocRef = doc(firestore, 'users', user.uid);
        
        await setDoc(userDocRef, {
            id: user.uid,
            role: 'applicant', // Default role for Google Sign-In
            name: user.displayName,
            email: user.email,
            photoURL: user.photoURL,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            status: 'active',
        }, { merge: true });

        router.push('/profile');
    } catch (error: any) {
        console.error("Google Sign-In Error: ", error);
        let description = t('Auth.googleSignInError');
        if (error.code === 'auth/operation-not-allowed') {
            description = t('Auth.googleSignInDisabled');
        }
        toast({
            variant: "destructive",
            title: t('Auth.loginErrorTitle'),
            description,
        });
    } finally {
        setIsGoogleLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link href="/" className="inline-flex items-center mb-4">
            <h1 className="text-2xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
          </Link>
          <h2 className="text-2xl font-bold tracking-tight">{t('Auth.createAccountTitle')}</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {t('Auth.hasAccount')}{' '}
            <Link href="/login" className="font-medium text-primary hover:underline">
              {t('Auth.loginLink')}
            </Link>
          </p>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
            <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSignup)} className="space-y-4">
                    <FormField control={form.control} name="name" render={({ field }) => (<FormItem><FormLabel>{t('Auth.userNameLabel')}</FormLabel><FormControl><Input placeholder={t('Auth.userNamePlaceholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={form.control} name="email" render={({ field }) => (<FormItem><FormLabel>{t('Auth.emailLabel')}</FormLabel><FormControl><Input type="email" placeholder="email@example.com" {...field} /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={form.control} name="password" render={({ field }) => (<FormItem><FormLabel>{t('Auth.passwordLabel')}</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={form.control} name="confirmPassword" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.confirmPasswordLabel')}</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                    <Button type="submit" className="w-full h-11" disabled={isLoading}>{isLoading && <Loader2 className="me-2 size-4 animate-spin" />} {t('Auth.createAccountButton')}</Button>
                </form>
            </Form>
        </div>
        
        <div className="relative my-6">
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
                <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center">
                <span className="bg-background px-2 text-sm text-muted-foreground">{t('Auth.orSeparator')}</span>
            </div>
        </div>

        <div className="space-y-4 px-6">
            <Button variant="outline" className="w-full h-11" onClick={handleGoogleSignIn} disabled={isGoogleLoading}>
              {isGoogleLoading ? ( <Loader2 className="me-2 size-4 animate-spin" /> ) : ( <GoogleIcon /> )}
              {t('Auth.continueWithGoogle')}
            </Button>
        </div>
        
        <p className="text-xs text-muted-foreground text-center px-4 mt-6">
            {t('Auth.termsIntro')}{' '}
            <Link href="/terms" className="underline hover:text-primary">{t('Auth.termsLink')}</Link>{' '}{t('Auth.and')}{' '}
            <Link href="/privacy" className="underline hover:text-primary">{t('Auth.privacyLink')}</Link>.
        </p>

         <div className="mt-6 text-center">
            <Button variant="ghost" onClick={() => router.push('/')} className="text-sm text-muted-foreground">
                <ArrowRight className="ms-2 size-4" />
                {t('Auth.backToHome')}
            </Button>
        </div>
      </div>
    </div>
  );
}
