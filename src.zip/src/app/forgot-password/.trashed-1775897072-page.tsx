
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { sendPasswordResetEmail } from 'firebase/auth';
import { useAuth } from '@/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

const getForgotPasswordSchema = (t: (key: string) => string) => z.object({
  email: z.string().email({ message: t('Auth.emailInvalid') }),
});

type ForgotPasswordFormValues = z.infer<ReturnType<typeof getForgotPasswordSchema>>;

export default function ForgotPasswordPage() {
  const router = useRouter();
  const auth = useAuth();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(false);

  const forgotPasswordSchema = getForgotPasswordSchema(t);

  const { register, handleSubmit, formState: { errors } } = useForm<ForgotPasswordFormValues>({
    resolver: zodResolver(forgotPasswordSchema),
  });

  const onSubmit = async (data: ForgotPasswordFormValues) => {
    setIsLoading(true);
    try {
      if (!auth) throw new Error("Auth service not available");
      await sendPasswordResetEmail(auth, data.email);
      toast({
        title: t('Auth.resetLinkSentTitle'),
        description: t('Auth.resetLinkSentDescription'),
      });
      router.push('/login');
    } catch (error: any) {
      console.error("Forgot Password Error:", error);
      let description = t('Auth.resetLinkErrorUnexpected');
      if (error.code === 'auth/user-not-found') {
        description = t('Auth.resetLinkErrorUserNotFound');
      }
      toast({
        variant: "destructive",
        title: t('Common.error'),
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
            <Link href="/" className="inline-flex items-center mb-4">
                <h1 className="text-2xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
            </Link>
          <h2 className="text-2xl font-bold tracking-tight">{t('Auth.resetPasswordTitle')}</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {t('Auth.resetPasswordDescription')}
          </p>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t('Auth.emailLabel')}</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                {...register('email')}
                className={errors.email ? 'border-destructive' : ''}
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>
            <Button type="submit" className="w-full h-11" disabled={isLoading}>
              {isLoading && <Loader2 className="me-2 size-4 animate-spin" />}
              {t('Auth.sendResetLinkButton')}
            </Button>
          </form>
        </div>
        
        <div className="mt-6 text-center">
            <Button variant="ghost" onClick={() => router.push('/login')} className="text-sm text-muted-foreground">
                <ArrowRight className="ms-2 size-4" />
                {t('Auth.backToLogin')}
            </Button>
        </div>
      </div>
    </div>
  );
}
