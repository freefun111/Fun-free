import type { Metadata } from 'next';
import { Tajawal } from 'next/font/google';
import './globals.css';
import { RootProvider } from '@/providers/RootProvider';

const tajawal = Tajawal({
  subsets: ['arabic'],
  weight: ['300', '400', '500', '700'],
  variable: '--font-tajawal',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'وصلة ديزاد - الحل الذكي للتوظيف و التكوين في الجزائر',
  description: 'الحل الذكي للتوظيف و التكوين في الجزائر',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html>
      <body className={`${tajawal.variable} font-body antialiased bg-background flex flex-col min-h-screen`}>
        <RootProvider>{children}</RootProvider>
      </body>
    </html>
  );
}
