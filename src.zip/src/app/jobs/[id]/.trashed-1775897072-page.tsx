'use client';

import { useParams, useRouter } from 'next/navigation';
import { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { BadgeCheck, MapPin, MessageSquare, Phone, Loader2, X, Share2, Clock, Award, FileText, CalendarClock, Sparkles, GraduationCap, Building, Hourglass, Eye, Heart, Star } from 'lucide-react';
import { type Job } from '@/lib/jobs';
import { recordJobView, toggleJobLike, isJobLikedByVisitor } from '@/lib/tracking';
import { submitJobRating, getUserRatingForJob } from '@/lib/ratings';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { useUser, useFirestore, useMemoFirebase, useCollection, useDoc } from '@/firebase';
import { doc, getDoc, collection, query, where, limit, Timestamp } from 'firebase/firestore';
import { Dialog, DialogContent, DialogClose, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogCancel, AlertDialogFooter } from '@/components/ui/alert-dialog';
import { normalizePhone, cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { findOrCreateChat } from '@/lib/chat';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { formatDistanceToNow, toDate } from 'date-fns';
import { ar, fr, enUS } from 'date-fns/locale';
import AdGallery from '@/components/home/AdGallery';
import { useTranslation } from 'react-i18next';
import { JobList } from '@/components/home/JobList';
import { Badge } from '@/components/ui/badge';
import { useChat } from '@/providers/ChatProvider';

const locales: { [key: string]: Locale } = { ar, fr, en: enUS };


const publisherAvatar = PlaceHolderImages.find((img) => img.id === 'publisher-avatar');

const WhatsAppIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg
      {...props}
      role="img"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
    >
      <path d="M12.04 2.016c-5.52 0-9.98 4.47-9.98 9.98 0 1.74.45 3.48.97 4.9l-1.03 3.78 3.87-1.02c1.4.52 2.94.98 4.5.98h.01c5.52 0 9.98-4.47 9.98-9.98s-4.46-9.98-9.98-9.98zm0 18.26c-1.4 0-2.8-.27-4.12-.99l-.3-.18-3.07.8.82-3.02-.2-.32c-.8-1.3-1.22-2.8-1.22-4.3s1.63-5.8 4.5-7.8c2.86-2 6.6-2.2 9.65-.62 3.05 1.57 4.92 4.63 4.92 8.1 0 4.54-3.7 8.24-8.23 8.24zm4.5-6.2c-.24-.12-1.44-.7-1.66-.78-.23-.08-.38-.12-.55.12-.17.24-.63.78-.77.94-.14.16-.28.18-.52.06s-1.03-.38-1.95-1.2c-.72-.63-1.2-1.4-1.34-1.64s-.02-.28.1-.38c.11-.1.24-.27.37-.4.12-.13.16-.22.25-.37s.04-.28-.02-.4c-.06-.12-.55-1.32-.75-1.8s-.4-.4-.55-.4h-.5c-.17 0-.45.06-.68.3s-.88.85-.88 2.07c0 1.22.9 2.4 1.03 2.56.12.17 1.75 2.67 4.25 3.75s1.7.8 2.28.75c.68-.06 1.44-.6 1.64-.82.2-.2.2-.4.15-.52s-.17-.24-.24-.32z" />
    </svg>
);

const StarRating = ({ rating, onRatingChange, disabled }: { rating: number, onRatingChange: (r: number) => void, disabled: boolean }) => {
  const {t} = useTranslation();
  return (
    <div className="flex items-center gap-1" dir="ltr">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={cn(
            "size-8 cursor-pointer transition-colors",
            rating >= star ? "text-yellow-400 fill-yellow-400" : "text-gray-300",
            !disabled && "hover:text-yellow-300"
          )}
          onClick={() => !disabled && onRatingChange(star)}
        />
      ))}
    </div>
  );
};


export default function JobDetailsPage() {
  const router = useRouter();
  const params = useParams();
  const jobId = params.id as string;
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const jobDocRef = useMemoFirebase(() => (firestore && jobId ? doc(firestore, 'jobs', jobId) : null), [firestore, jobId]);
  const { data: job, isLoading: isJobLoading, error } = useDoc<Job>(jobDocRef);


  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(job?.likes || 0);
  const [isLiking, setIsLiking] = useState(false);
  const { toast } = useToast();
  const [isCreatingChat, setIsCreatingChat] = useState(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [showPublisherInfo, setShowPublisherInfo] = useState(false);
  const [publisher, setPublisher] = useState<any>(null);
  const [isPublisherLoading, setIsPublisherLoading] = useState(true);
  const { t, i18n } = useTranslation();
  const { openChat } = useChat();

  const [userRating, setUserRating] = useState<number>(0);
  const [isRating, setIsRating] = useState(false);
  const [hasRated, setHasRated] = useState(false);


  const formatTimestamp = (timestamp: any): string => {
    if (!timestamp) return t('JobDetails.unavailable');
    try {
        const date = toDate(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
        return formatDistanceToNow(date, { addSuffix: true, locale: locales[i18n.language] });
    } catch (e) {
        return new Date(timestamp).toLocaleDateString(i18n.language);
    }
  };
  
  useEffect(() => {
    if (jobId && firestore) {
      recordJobView(firestore, jobId);
    }
    if (jobId) {
        setIsLiked(isJobLikedByVisitor(jobId));
    }
    if (job) {
      setLikeCount(job.likes || 0);
    }
  }, [jobId, firestore, job]);
  
  useEffect(() => {
    if (user && jobId && firestore) {
      getUserRatingForJob(firestore, jobId, user.uid).then(rating => {
        if (rating !== null) {
          setUserRating(rating);
          setHasRated(true);
        }
      });
    }
  }, [user, jobId, firestore]);


  useEffect(() => {
    if (!job || !firestore) return;

    const fetchPublisher = async () => {
      setIsPublisherLoading(true);
      const publisherDocRef = doc(firestore, 'users', job.userId);
      try {
        const docSnap = await getDoc(publisherDocRef);
        if (docSnap.exists()) {
          setPublisher(docSnap.data());
        } else {
          setPublisher(null);
        }
      } catch (error) {
        console.error("Error fetching publisher data:", error);
        setPublisher(null);
      } finally {
        setIsPublisherLoading(false);
      }
    };

    fetchPublisher();
  }, [job, firestore]);


  const similarJobsQuery = useMemoFirebase(() => {
    if (!firestore || !job?.category) return null;
    return query(
      collection(firestore, 'jobs'),
      where('category', '==', job.category),
      limit(4) // Fetch 4 to have enough after filtering current one
    );
  }, [firestore, job?.category]);

  const { data: similarJobsData } = useCollection<Job>(similarJobsQuery);

  const similarJobs = useMemo(() => {
    if (!similarJobsData || !jobId) return [];
    // Filter out the current job and take up to 3
    return similarJobsData.filter(j => j.id !== jobId).slice(0, 3);
  }, [similarJobsData, jobId]);

  
  const handleContactAction = (action: () => void) => {
    if (!user) {
      setShowLoginPrompt(true);
    } else {
      action();
    }
  };

  const handleLike = async () => {
    if (!jobId || !firestore || isLiking) return;

    handleContactAction(async () => {
      setIsLiking(true);
      try {
        const newLikedState = await toggleJobLike(firestore, jobId);
        setIsLiked(newLikedState);
        setLikeCount((prev) => (newLikedState ? prev + 1 : Math.max(0, prev - 1)));
        toast({
          title: newLikedState ? t('JobDetails.adLiked') : t('JobDetails.adUnliked'),
        });
      } catch (error) {
        console.error("Error toggling job like:", error);
        toast({
          variant: "destructive",
          title: t('Common.error'),
          description: t('JobDetails.likeError'),
        });
      } finally {
        setIsLiking(false);
      }
    });
  };

  const handleRatingSubmit = async (newRating: number) => {
    if (!user || !firestore || !jobId || isRating || isOwner) return;
    
    handleContactAction(async () => {
      setIsRating(true);
      try {
        await submitJobRating(firestore, jobId, user.uid, newRating);
        setUserRating(newRating);
        setHasRated(true);
        toast({
          title: t('JobDetails.ratingToastTitle'),
          description: t('JobDetails.ratingToastDescription', { rating: newRating }),
        });
      } catch (error) {
        console.error("Failed to submit rating:", error);
        toast({
          variant: 'destructive',
          title: t('Common.error'),
          description: t('JobDetails.ratingError'),
        });
      } finally {
        setIsRating(false);
      }
    });
  };

  const isOwner = user?.uid === job?.userId;

  const handleStartConversation = async () => {
    if (isUserLoading || isOwner || !user || !job || !publisher || !firestore) {
      return;
    };
    
    setIsCreatingChat(true);
    try {
        const otherUser = {
            uid: job.userId,
            name: publisher.name || job.company,
            photoURL: publisher.photoURL || '',
        };
        const jobInfo = {
            id: job.id,
            title: job.title,
        };

        const chatId = await findOrCreateChat(firestore, user, otherUser, jobInfo);
        openChat(chatId);

    } catch (error) {
        console.error("Failed to find or create chat:", error);
        toast({
            variant: "destructive",
            title: t('Chat.startErrorTitle'),
            description: t('Chat.startErrorDescription'),
        });
    } finally {
        setIsCreatingChat(false);
    }
  };

  const handleShowPublisherInfo = () => {
    if (isOwner) {
      return;
    }
    if (!user) {
      setShowLoginPrompt(true);
      return;
    }
    setShowPublisherInfo(true);
  };

  const handleShareAd = () => {
    if (!job) return;

    const shareData = {
      title: job.title,
      text: t('Share.shareAdText', { title: job.title }),
      url: window.location.href,
    };

    const fallbackToClipboard = () => {
      navigator.clipboard.writeText(window.location.href)
        .then(() => {
          toast({
            title: t('Share.linkCopiedTitle'),
            description: t('Share.adLinkCopiedDescription'),
          });
        })
        .catch((err) => {
          console.error("Failed to copy ad link: ", err);
          toast({
            variant: 'destructive',
            title: t('Share.shareAdErrorTitle'),
            description: t('Share.shareAdErrorDescription')
          });
        });
    };

    if (navigator.share) {
      navigator.share(shareData).catch((error) => {
        if (error.name !== 'AbortError') {
          console.warn('Web Share API failed, falling back to clipboard:', error);
          fallbackToClipboard();
        }
      });
    } else {
      fallbackToClipboard();
    }
  };

  const negotiableText = useMemo(() => {
    if (!job) return '';
    if (job.salary) return job.salary;
    if (job.listingType === 'training') {
        return t('JobDetails.negotiablePriceTraining');
    }
    return t('JobDetails.negotiableSalaryJob');
  }, [job, t]);

  if (isJobLoading || isPublisherLoading) {
    return (
      <main className="flex-1 flex items-center justify-center min-h-screen">
          <Loader2 className="size-8 animate-spin text-primary" />
      </main>
    );
  }

  if (!job) {
    return (
      <main className="flex-1 flex items-center justify-center">
        <p>{t('JobDetails.notFound')}</p>
      </main>
    );
  }
  
  const displayImages: JobImage[] = (job.images && job.images.length > 0) 
    ? job.images 
    : PlaceHolderImages.find((img) => img.id === 'job-detail-1') 
      ? [PlaceHolderImages.find((img) => img.id === 'job-detail-1')!] 
      : [];

  const DetailItem = ({ icon: Icon, label, value }: { icon: React.ElementType, label: string, value: string | null | undefined }) => {
    if (!value) return null;
    return (
        <div className="flex items-start gap-3 text-sm">
            <Icon className="size-5 mt-1 text-muted-foreground" />
            <div>
                <p className="font-semibold text-muted-foreground">{label}</p>
                <p className="text-foreground font-bold">{value}</p>
            </div>
        </div>
    );
  };


  return (
    <div className="bg-background text-foreground">
      <div className="mx-auto max-w-none">
        <main className="pb-40 pt-4 md:pt-8 md:pb-24">
            <div>
                {displayImages.length > 0 && (
                  <div className="px-4">
                    <AdGallery images={displayImages} />
                  </div>
                )}

                <div className="mt-6 px-4">
                    <p className="text-sm font-bold uppercase text-primary">{job.category}</p>
                    <div className="flex justify-between items-start gap-4">
                        <h1 className="text-2xl md:text-3xl font-extrabold mt-1 flex-1">{job.title}</h1>
                        <div className="flex items-center">
                            <div className="relative">
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="rounded-full size-12 shrink-0"
                                    onClick={handleLike}
                                    aria-label={isLiked ? t('JobDetails.unlikeAd') : t('JobDetails.likeAd')}
                                    disabled={isLiking}
                                >
                                    <Heart className={cn("size-7 transition-all", isLiked ? "text-red-500 fill-red-500" : "text-muted-foreground")} />
                                </Button>
                                {likeCount > 0 && (
                                    <Badge variant="destructive" className="absolute top-1 right-1 px-1.5 py-0.5 text-xs rounded-full pointer-events-none">
                                        {likeCount > 99 ? '99+' : likeCount}
                                    </Badge>
                                )}
                            </div>
                            <Button
                                variant="ghost"
                                size="icon"
                                className="rounded-full size-12 shrink-0"
                                onClick={handleShareAd}
                                aria-label={t('JobDetails.shareAd')}
                            >
                                <Share2 className="size-6 text-muted-foreground" />
                            </Button>
                        </div>
                    </div>
                    <div className="flex items-center mt-2 text-muted-foreground">
                        <span>{job.company}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-muted-foreground">
                        <MapPin className="size-4" />
                        <span>{job.location}</span>
                    </div>
                     <div className="flex items-center flex-wrap gap-x-4 gap-y-1 mt-1 text-muted-foreground text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="size-4" />
                          <span>{t('JobDetails.postedAgo', { timestamp: formatTimestamp(job.createdAt) })}</span>
                        </div>
                        {(job.views || 0) > 0 && (
                          <div className="flex items-center gap-2">
                            <Eye className="size-4" />
                            <span>{job.views?.toLocaleString(i18n.language)} {t('JobDetails.views')}</span>
                          </div>
                        )}
                        {(job.ratingCount || 0) > 0 && (
                          <div className="flex items-center gap-1 font-semibold text-yellow-500">
                              <Star className="size-4 fill-current" />
                              <span>
                                  {job.averageRating?.toFixed(1)} {t('JobDetails.ratingsCount', { count: job.ratingCount })}
                              </span>
                          </div>
                        )}
                    </div>
                    <p className="mt-2 text-xl md:text-2xl font-bold text-emerald-500">{negotiableText}</p>
                </div>
            </div>

            <Separator className="my-6" />

            <div className="px-4">
                <h3 className="font-bold text-lg md:text-xl mb-4">{t('JobDetails.adDetails')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
                    {/* Job Offer Details */}
                    {job.listingType === 'jobs' && job.adType === 'offer' && (
                        <>
                            {job.experienceLevel && <DetailItem icon={Award} label={t('JobDetails.experienceLevel')} value={t(`AddAdPage.${{ 'none': 'noExperience', '1-3': 'experience1_3', '>3': 'experience3plus' }[job.experienceLevel]}` as const) || job.experienceLevel} />}
                            {job.contractType && <DetailItem icon={FileText} label={t('JobDetails.contractType')} value={t(`AddAdPage.${{ 'permanent': 'permanentContract', 'temporary': 'temporaryContract' }[job.contractType]}` as const) || job.contractType} />}
                            {job.contractDuration && <DetailItem icon={CalendarClock} label={t('JobDetails.contractDuration')} value={job.contractDuration} />}
                        </>
                    )}

                    {/* Job Request Details */}
                    {job.listingType === 'jobs' && job.adType === 'request' && (
                        <>
                            {job.experienceLevel && <DetailItem icon={Award} label={t('JobDetails.experienceLevel')} value={t(`AddAdPage.${{ 'beginner': 'beginner', 'intermediate': 'intermediate', 'professional': 'professional' }[job.experienceLevel]}` as const) || job.experienceLevel} />}
                            {job.certificates && <DetailItem icon={GraduationCap} label={t('JobDetails.certificates')} value={job.certificates} />}
                        </>
                    )}
                    
                    {/* Training Offer Details */}
                    {job.listingType === 'training' && job.adType === 'offer' && (
                        <>
                            {job.trainingInstitution && <DetailItem icon={Building} label={t('JobDetails.trainingInstitution')} value={job.trainingInstitution} />}
                            {job.trainingDuration && <DetailItem icon={Hourglass} label={t('JobDetails.trainingDuration')} value={`${job.trainingDuration} ${t('JobDetails.days')}`} />}
                        </>
                    )}

                    {/* Training Request Details */}
                    {job.listingType === 'training' && job.adType === 'request' && (
                        <>
                            {job.trainingDurationType && <DetailItem icon={Hourglass} label={t('JobDetails.trainingDurationType')} value={t(`AddAdPage.${{ 'short': 'shortIntensive', 'medium': 'mediumDuration', 'long': 'longDuration' }[job.trainingDurationType]}` as const) || job.trainingDurationType} />}
                        </>
                    )}

                    {job.benefits && job.benefits.length > 0 && (
                        <div className="sm:col-span-2">
                            <p className="font-semibold text-muted-foreground mb-2 flex items-center gap-2"><Sparkles className="size-4" /> {job.listingType === 'jobs' && job.adType === 'request' ? t('JobDetails.seekerAdvantages') : t('JobDetails.benefits')}</p>
                            <div className="flex flex-wrap gap-2">
                                {job.benefits.map((benefit: string) => <Badge key={benefit} variant="secondary" className="text-base px-3 py-1">{benefit}</Badge>)}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <Separator className="my-6" />

            <div className="px-4">
                <h3 className="font-bold text-lg md:text-xl mb-2">{t('JobDetails.jobDescription')}</h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {job.description}
                </p>
            </div>
            
            <Separator className="my-6" />
            
            <div className="px-4">
              <h3 className="font-bold text-lg md:text-xl mb-2">{t('JobDetails.yourRating')}</h3>
              {isOwner ? (
                <p className="text-sm text-muted-foreground">{t('JobDetails.yourAd')}</p>
              ) : user ? (
                <>
                  <StarRating rating={userRating} onRatingChange={handleRatingSubmit} disabled={isRating || hasRated} />
                  <p className="text-xs text-muted-foreground mt-2">
                    {hasRated ? t('JobDetails.alreadyRated') : t('JobDetails.clickToRate')}
                  </p>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">{t('Auth.loginRequired')}</p>
              )}
            </div>

            <Separator className="my-6" />

            <div className="px-4">
                <h3 className="font-bold text-lg md:text-xl mb-2">{t('JobDetails.aboutPublisher')}</h3>
                <div 
                  className="flex items-center justify-between rounded-lg border bg-card p-4 transition-colors hover:bg-secondary cursor-pointer"
                  onClick={handleShowPublisherInfo}
                >
                    <div className="flex items-center gap-3">
                    <Image 
                        src={publisher?.photoURL || publisherAvatar?.imageUrl || '/default-avatar.png'}
                        alt={publisher?.name || job.company}
                        width={48} 
                        height={48} 
                        className="rounded-full bg-muted object-cover" 
                        data-ai-hint={publisherAvatar?.imageHint || 'person portrait'}
                        placeholder="blur"
                        blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
                    />
                    <div>
                        <p className="font-bold flex items-center gap-1">
                            {publisher?.name || job.company}
                            {publisher?.role === 'employer' && <BadgeCheck className="size-4 text-primary fill-primary" />}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {t('PublisherInfo.memberSince', { date: publisher?.createdAt ? new Date(publisher.createdAt).toLocaleDateString(i18n.language, { year: 'numeric', month: 'long' }) : '...' })}
                        </p>
                    </div>
                    </div>
                </div>
            </div>

            {similarJobs.length > 0 && (
                <div className="p-4 mt-6">
                <h3 className="font-bold text-lg md:text-xl mb-4">{t('JobDetails.similarAds')}</h3>
                <JobList jobs={similarJobs} />
                </div>
            )}
            
        </main>
        
        <div className="fixed bottom-16 left-0 right-0 z-10 w-full bg-background/90 p-3 backdrop-blur-sm border-t md:static md:bottom-auto md:bg-transparent md:p-4 md:mt-8 md:border-none">
            <div className="max-w-4xl mx-auto">
                 {isOwner ? (
                    <Button className="w-full h-12 text-base" disabled>
                        {t('JobDetails.yourAd')}
                    </Button>
                ) : (
                    <div className="flex items-center gap-2">
                        <Button onClick={() => handleContactAction(handleStartConversation)} className="flex-1 h-12 text-base" disabled={isCreatingChat}>
                            {isCreatingChat ? <Loader2 className="me-2 size-5 animate-spin" /> : <MessageSquare className="me-2 size-5" />}
                            {t('JobDetails.startConversation')}
                        </Button>
                        
                        {(job.phone1 || job.whatsapp) && (
                            <>
                                {job.phone1 && (
                                  <a href={`tel:${job.phone1}`}>
                                    <Button variant="outline" size="icon" className="h-12 w-12 shrink-0">
                                        <Phone className="size-5" />
                                        <span className="sr-only">{t('JobDetails.call')}</span>
                                    </Button>
                                  </a>
                                )}
                                {(job.whatsapp || job.phone1) && (
                                  <a href={`https://wa.me/${normalizePhone(job.whatsapp || job.phone1!)}`} target="_blank" rel="noopener noreferrer">
                                    <Button variant="outline" size="icon" className="h-12 w-12 shrink-0">
                                        <WhatsAppIcon className="size-5" />
                                        <span className="sr-only">{t('JobDetails.whatsapp')}</span>
                                    </Button>
                                  </a>
                                )}
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>

        <>
            <AlertDialog open={showLoginPrompt} onOpenChange={setShowLoginPrompt}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>{t('Auth.loginRequired')}</AlertDialogTitle>
                        <AlertDialogDescription>
                           {t('Auth.loginRequiredForContact')}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>{t('Common.cancel')}</AlertDialogCancel>
                        <AlertDialogAction onClick={() => router.push('/login')}>
                            {t('Auth.login')}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <Dialog open={showPublisherInfo} onOpenChange={setShowPublisherInfo}>
            <DialogContent>
                <DialogHeader>
                <DialogTitle>{t('PublisherInfo.title')}</DialogTitle>
                </DialogHeader>
                {isPublisherLoading ? (
                    <div className="flex items-center justify-center p-10">
                        <Loader2 className="size-8 animate-spin text-primary" />
                    </div>
                ) : publisher ? (
                <div className="space-y-4 pt-2">
                    <div className="flex items-center gap-4">
                    <Avatar className="size-20 border">
                        <AvatarImage src={publisher.photoURL || publisherAvatar?.imageUrl || '/default-avatar.png'} alt={publisher.name} />
                        <AvatarFallback>{publisher.name?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                        <p className="text-xl font-bold">{publisher.name}</p>
                        <p className="text-sm text-muted-foreground">{publisher.role === 'employer' ? t('PublisherInfo.employer') : t('PublisherInfo.applicant')}</p>
                    </div>
                    </div>
                    <Separator />
                    <div className="space-y-3 text-sm">
                    {publisher.email && (
                        <div className="flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">{t('PublisherInfo.email')}</span>
                        <span className="font-mono text-foreground">{publisher.email}</span>
                        </div>
                    )}
                    {job.phone1 && (
                        <div className="flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">{t('PublisherInfo.phone')}</span>
                        <span className="font-mono text-foreground" dir="ltr">{job.phone1}</span>
                        </div>
                    )}
                    {job.phone2 && (
                        <div className="flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">{t('PublisherInfo.phone2')}</span>
                        <span className="font-mono text-foreground" dir="ltr">{job.phone2}</span>
                        </div>
                    )}
                    {job.phone3 && (
                        <div className="flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">{t('PublisherInfo.phone3')}</span>
                        <span className="font-mono text-foreground" dir="ltr">{job.phone3}</span>
                        </div>
                    )}
                    {publisher.landlineNumber && (
                        <div className="flex justify-between items-center">
                        <span className="font-semibold text-muted-foreground">{t('PublisherInfo.landline')}</span>
                        <span className="font-mono text-foreground" dir="ltr">{publisher.landlineNumber}</span>
                        </div>
                    )}
                    {publisher.address && publisher.wilaya && (
                        <div className="flex justify-between items-start">
                        <span className="font-semibold text-muted-foreground shrink-0 me-4">{t('PublisherInfo.address')}</span>
                        <span className="text-foreground text-right">{`${publisher.address}, ${publisher.wilaya}`}</span>
                        </div>
                    )}
                    </div>
                    <DialogFooter>
                        <DialogClose asChild><Button variant="outline">{t('Common.close')}</Button></DialogClose>
                    </DialogFooter>
                </div>
                ) : (
                    <div className="space-y-4 pt-2">
                        <div className="flex items-center gap-4">
                            <Avatar className="size-20 border">
                                <AvatarImage src={publisherAvatar?.imageUrl || '/default-avatar.png'} alt={job.company} />
                                <AvatarFallback>{job.company?.charAt(0) || 'C'}</AvatarFallback>
                            </Avatar>
                            <div className="space-y-1">
                                <p className="text-xl font-bold">{job.company}</p>
                                <p className="text-sm text-muted-foreground">{job.adType === 'offer' ? t('PublisherInfo.employer') : t('PublisherInfo.applicant')}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="text-center text-sm text-muted-foreground p-6">
                            {t('PublisherInfo.noContactInfo')}
                        </div>
                        <DialogFooter>
                            <DialogClose asChild>
                                <Button variant="outline">{t('Common.close')}</Button>
                            </DialogClose>
                        </DialogFooter>
                    </div>
                )}
            </DialogContent>
            </Dialog>
        </>
      </div>
    </div>
  );
}
