
'use client';

import { useTranslation } from 'react-i18next';

export default function ObsoletePage() {
  const { t } = useTranslation();
  return (
    <div className="mx-auto max-w-none min-h-screen flex flex-col items-center justify-center bg-background pt-16 pb-24">
        <h2 className="text-lg font-bold leading-tight tracking-tight text-center p-4">
          {t('ObsoletePage.title')}
        </h2>
      <main className="flex-1 p-4 flex items-center justify-center">
        <p className="text-center text-muted-foreground">{t('Chat.redirectToMessages')}</p>
      </main>
    </div>
  );
}
