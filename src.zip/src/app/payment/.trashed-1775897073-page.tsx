'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, UploadCloud, CheckCircle, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { addJob, updateJob, type NewJobData, type UpdateJobData } from '@/lib/jobs';
import { useUser, useFirestore } from '@/firebase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import Image from 'next/image';

const packageDetails: { [key: string]: { name: string; basePrice: number } } = {
    sponsored: { name: 'الممولة', basePrice: 500 },
    premium: { name: 'المميزة', basePrice: 1000 },
};

const durationPricing: { [key: number]: { name: string; multiplier: number } } = {
    7: { name: '7 أيام', multiplier: 1 },
    15: { name: '15 يوم', multiplier: 1.8 },
    30: { name: '30 يوم', multiplier: 3.5 },
};

export default function PaymentPage() {
    const router = useRouter();
    const { toast } = useToast();
    const { user, isUserLoading } = useUser();
    const firestore = useFirestore();

    const [adData, setAdData] = useState<any>(null);
    const [price, setPrice] = useState(0);
    const [receiptPreview, setReceiptPreview] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        const dataString = sessionStorage.getItem('adDataForPayment');
        if (dataString) {
            const data = JSON.parse(dataString);
            setAdData(data);

            const pkg = packageDetails[data.packageType];
            const dur = durationPricing[data.durationDays];
            if (pkg && dur) {
                setPrice(Math.round(pkg.basePrice * dur.multiplier));
            }
        } else {
            // No data, redirect away
            toast({
                variant: 'destructive',
                title: 'لا يوجد إعلان للمعالجة',
                description: 'يتم إعادتك إلى الصفحة الرئيسية.',
            });
            router.replace('/');
        }
    }, [router, toast]);

    const handleCopyCCP = () => {
        const ccp = '12345678 90';
        navigator.clipboard.writeText(ccp).then(() => {
            toast({
                title: "تم نسخ رقم الحساب",
                description: "تم نسخ رقم CCP إلى الحافظة بنجاح.",
            });
        }, (err) => {
            toast({
                variant: 'destructive',
                title: "فشل النسخ",
                description: "لم نتمكن من نسخ الرقم. الرجاء المحاولة يدويًا.",
            });
            console.error('Could not copy text: ', err);
        });
    };

    const handleCopyRIP = () => {
        const rip = '0079999900000000001234567';
        navigator.clipboard.writeText(rip).then(() => {
            toast({
                title: "تم نسخ رقم الحساب",
                description: "تم نسخ رقم RIP إلى الحافظة بنجاح.",
            });
        }, (err) => {
            toast({
                variant: 'destructive',
                title: "فشل النسخ",
                description: "لم نتمكن من نسخ الرقم. الرجاء المحاولة يدويًا.",
            });
            console.error('Could not copy text: ', err);
        });
    };

    const resizeImage = (file: File, maxSize: number, quality: number): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = reject;
            reader.onload = (event) => {
                if (!event.target?.result) {
                    return reject(new Error("FileReader did not return a result."));
                }
                const img = new window.Image();
                img.onerror = reject;
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let { width, height } = img;

                    if (width > maxSize || height > maxSize) {
                        if (width > height) {
                            height = Math.round(height * (maxSize / width));
                            width = maxSize;
                        } else {
                            width = Math.round(width * (maxSize / height));
                            height = maxSize;
                        }
                    }

                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    if (!ctx) {
                        return reject(new Error('Could not get canvas context'));
                    }
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', quality));
                };
                img.src = event.target.result as string;
            };
            reader.readAsDataURL(file);
        });
    };

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            toast({ variant: 'destructive', title: 'ملف غير صالح', description: 'الرجاء اختيار ملف صورة.' });
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            toast({ variant: 'destructive', title: 'حجم الملف كبير جدًا', description: 'الرجاء اختيار صورة أصغر من 5 ميغابايت.' });
            return;
        }

        try {
            const resizedDataUrl = await resizeImage(file, 1024, 0.7);
            setReceiptPreview(resizedDataUrl);
        } catch (error) {
            console.error("Image resize error:", error);
            toast({ variant: "destructive", title: "خطأ في معالجة الصورة" });
        }
    };

    const handleSubmit = async () => {
        if (!adData || !receiptPreview || !firestore) {
            toast({ variant: 'destructive', title: 'بيانات ناقصة', description: 'الرجاء رفع صورة وصل الدفع.' });
            return;
        }

        setIsSubmitting(true);
        
        const dataWithReceipt = {
            ...adData,
            status: 'pending_review' as const,
            paymentReceipt: receiptPreview,
        };

        try {
            if (adData.jobId) {
                // This is an update to an existing job
                const { jobId, ...updateData } = dataWithReceipt;
                await updateJob(firestore, jobId, updateData as UpdateJobData);
            } else {
                // This is a new job
                await addJob(firestore, dataWithReceipt as NewJobData);
            }

            toast({
                title: 'تم إرسال طلبك بنجاح',
                description: 'سيتم مراجعة إعلانك وتفعيله في أقرب وقت ممكن.',
            });
            sessionStorage.removeItem('adDataForPayment');
            router.replace(adData.jobId ? '/my-ads' : '/');

        } catch (error) {
            console.error("Failed to submit paid ad:", error);
            toast({ variant: "destructive", title: "خطأ في الإرسال", description: "حدث خطأ غير متوقع. الرجاء المحاولة مرة أخرى." });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isUserLoading || !adData) {
        return (
            <div className="mx-auto max-w-none min-h-screen flex flex-col items-center justify-center bg-background">
                <Loader2 className="size-8 animate-spin text-primary" />
            </div>
        );
    }
    
    return (
        <div className="mx-auto max-w-lg min-h-screen flex flex-col bg-background pt-16 pb-24">
            <h2 className="text-lg font-bold leading-tight tracking-tight text-center p-4">
                تأكيد الدفع
            </h2>
            <main className="flex-1 p-4 space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle>ملخص الطلب</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                        <div className="flex justify-between">
                            <span className="text-muted-foreground">الباقة:</span>
                            <span className="font-semibold">{packageDetails[adData.packageType]?.name || adData.packageType}</span>
                        </div>
                         <div className="flex justify-between">
                            <span className="text-muted-foreground">المدة:</span>
                            <span className="font-semibold">{durationPricing[adData.durationDays]?.name || `${adData.durationDays} يوم`}</span>
                        </div>
                    </CardContent>
                    <CardFooter className="flex justify-between font-bold text-lg border-t pt-4">
                        <span>المبلغ الإجمالي:</span>
                        <span>{price.toLocaleString('fr-FR')} دج</span>
                    </CardFooter>
                </Card>

                <div className="space-y-2">
                    <Label>معلومات الدفع</Label>
                    <div className="p-4 border rounded-lg text-sm bg-secondary/30">
                        <p className="text-muted-foreground">لإتمام العملية، يرجى تحويل المبلغ المطلوب إلى أحد حساباتنا:</p>
                        <div className="flex items-center justify-between gap-2 mt-2 bg-background/50 p-2 rounded-md">
                            <span className="font-mono font-semibold text-foreground">CCP: 12345678 90</span>
                            <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                onClick={handleCopyCCP}
                                className="text-xs h-auto px-2 py-1"
                            >
                                <Copy className="me-1 size-3" />
                                نسخ
                            </Button>
                        </div>
                        <div className="flex items-center justify-between gap-2 mt-2 bg-background/50 p-2 rounded-md">
                           <span className="font-mono font-semibold text-foreground text-xs sm:text-sm truncate">RIP: 0079999900000000001234567</span>
                           <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                onClick={handleCopyRIP}
                                className="text-xs h-auto px-2 py-1"
                            >
                                <Copy className="me-1 size-3" />
                                نسخ
                            </Button>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">باسم: WASLA DZ</p>
                        
                        <Separator className="my-4 bg-border" />

                        <p className="text-muted-foreground">
                            بعد إتمام التحويل، لديك خياران:
                        </p>
                        <ul className="list-decimal list-inside mt-2 space-y-2 text-muted-foreground">
                            <li>
                                <strong>رفع صورة الوصل مباشرة:</strong> استخدم الزر أدناه لتحميل صورة واضحة لوصل الدفع.
                            </li>
                            <li>
                                <strong>إرسال الوصل عبر البريد الإلكتروني:</strong> يمكنك أيضًا إرسال الوصل إلى <a href="mailto:payment@wasladz.app" className="text-primary font-semibold underline">payment@wasladz.app</a> مع ذكر عنوان إعلانك.
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="space-y-2">
                    <Label htmlFor="receipt">رفع وصل الدفع</Label>
                     <div 
                        className="relative flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-secondary/50 hover:bg-secondary/80"
                        onClick={() => fileInputRef.current?.click()}
                    >
                        {receiptPreview ? (
                            <>
                                <Image src={receiptPreview} alt="معاينة الوصل" fill className="object-contain p-2" />
                                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                                    <p className="text-white text-sm font-semibold">تغيير الصورة</p>
                                </div>
                            </>
                        ) : (
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <UploadCloud className="w-8 h-8 mb-2 text-muted-foreground" />
                                <p className="mb-2 text-sm text-muted-foreground">
                                <span className="font-semibold">انقر للتحميل</span>
                                </p>
                            </div>
                        )}
                        <Input 
                            ref={fileInputRef}
                            id="receipt" 
                            type="file" 
                            className="hidden"
                            accept="image/*"
                            onChange={handleFileChange}
                        />
                    </div>
                </div>

                <Button onClick={handleSubmit} className="w-full h-12" disabled={isSubmitting || !receiptPreview}>
                    {isSubmitting ? (
                        <><Loader2 className="me-2 size-4 animate-spin" /> جاري الإرسال...</>
                    ) : (
                        <> <CheckCircle className="me-2 size-5" /> تأكيد وإرسال للمراجعة </>
                    )}
                </Button>
            </main>
        </div>
    );
}
