'use client';

import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function AboutPage() {
  const { t } = useTranslation();
  return (
    <div className="mx-auto max-w-4xl min-h-screen flex flex-col bg-background pt-16 pb-24">
      <h2 className="text-2xl font-bold leading-tight tracking-tight text-center p-4">
        {t('AboutPage.title')}
      </h2>
      <main className="flex-1 p-4 space-y-6">
        <p className="text-center text-lg text-muted-foreground">
          {t('AboutPage.subtitle')}
        </p>
        
        <Card>
          <CardHeader>
            <CardTitle>{t('AboutPage.missionTitle')}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{t('AboutPage.missionText')}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('AboutPage.visionTitle')}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{t('AboutPage.visionText')}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('AboutPage.whyTitle')}</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li><strong>{t('AboutPage.whyPoint1Title')}:</strong> {t('AboutPage.whyPoint1Text')}</li>
              <li><strong>{t('AboutPage.whyPoint2Title')}:</strong> {t('AboutPage.whyPoint2Text')}</li>
              <li><strong>{t('AboutPage.whyPoint3Title')}:</strong> {t('AboutPage.whyPoint3Text')}</li>
              <li><strong>{t('AboutPage.whyPoint4Title')}:</strong> {t('AboutPage.whyPoint4Text')}</li>
            </ul>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
