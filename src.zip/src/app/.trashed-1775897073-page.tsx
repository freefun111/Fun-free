'use client';

import { useState, useEffect, useMemo } from 'react';
import type { Job } from '@/lib/jobs';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { FeaturedPartners } from '@/components/home/FeaturedPartners';
import { JobFilters } from '@/components/home/JobFilters';
import { WilayaFilter } from '@/components/home/WilayaFilter';
import { JobCard } from '@/components/home/JobCard';
import { AdvancedSearch, type SearchCriteria } from '@/components/home/AdvancedSearch';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useHasMounted } from '@/hooks/use-has-mounted';
import { Loader2 } from 'lucide-react';
import { useSearchParams } from 'next/navigation';
import { useTranslation } from 'react-i18next';
import { sampleJobs } from '@/lib/sample-jobs';

const JOBS_PER_PAGE = 12; // Adjust page size for a multi-column grid

function AdsGridSkeleton() {
  return (
    <div className="space-y-3">
      {/* Skeleton for paid ads */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <Skeleton className="h-80 w-full rounded-lg" />
        <Skeleton className="h-80 w-full rounded-lg" />
        <Skeleton className="h-80 w-full rounded-lg" />
        <Skeleton className="h-80 w-full rounded-lg" />
      </div>

      {/* Skeleton for regular ads grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
        <Skeleton className="h-28 sm:h-64 w-full rounded-lg" />
      </div>
    </div>
  );
}

export default function Home() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [selectedWilayas, setSelectedWilayas] = useState<string[]>([]);
  const [searchCriteria, setSearchCriteria] = useState<SearchCriteria | null>(null);
  const [visibleJobsCount, setVisibleJobsCount] = useState(JOBS_PER_PAGE);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const hasMounted = useHasMounted();
  const firestore = useFirestore();
  const searchParams = useSearchParams();
  const urlListingType = searchParams.get('listingType');
  const urlQuery = searchParams.get('q');
  const { t } = useTranslation();


  useEffect(() => {
    if (urlListingType === 'jobs' || urlListingType === 'training') {
        setActiveFilter(urlListingType);
    }
  }, [urlListingType]);

  // Fetch the 100 most recent jobs to avoid needing a composite index. We will sort them on the client.
  const jobsQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(
        collection(firestore, 'jobs'),
        orderBy('createdAt', 'desc'),
        limit(100)
    );
  }, [firestore]);

  const { data: rawJobs, isLoading: areJobsLoading } = useCollection<Job>(jobsQuery);
  
  const jobs = useMemo(() => {
    // Combine real jobs from Firestore with the sample jobs.
    const combinedJobs = [
      ...(rawJobs || []),
      ...sampleJobs,
    ];

    // Create a unique list of jobs, giving priority to real jobs if IDs overlap.
    const uniqueJobs = Array.from(new Map(combinedJobs.map(job => [job.id, job])).values());
    
    if (uniqueJobs.length === 0) return [];

    // Sort the combined list based on package type and then creation date.
    return [...uniqueJobs].sort((a, b) => {
        const orderA = a.packageOrder || 3;
        const orderB = b.packageOrder || 3;
        if (orderA !== orderB) {
            return orderA - orderB;
        }
        // For jobs with the same packageOrder, sort by creation time descending
        const timeA = a.createdAt?.seconds || 0;
        const timeB = b.createdAt?.seconds || 0;
        return timeB - timeA;
    });
  }, [rawJobs]);

  const filteredJobs = useMemo(() => {
    if (!jobs) return [];
    
    let tempJobs = [...jobs];

    // Filter by listing type (job/training)
    if (activeFilter !== 'all') {
      tempJobs = tempJobs.filter(job => job.listingType === activeFilter);
    }

    // Filter by Wilaya
    if (selectedWilayas.length > 0) {
      tempJobs = tempJobs.filter(job => selectedWilayas.some(w => job.location.includes(w)));
    }
    
    // Header Search Filter (takes priority)
    if (urlQuery) {
        const keywords = urlQuery.toLowerCase();
        tempJobs = tempJobs.filter(job => 
          job.title.toLowerCase().includes(keywords) ||
          job.description.toLowerCase().includes(keywords) ||
          job.category.toLowerCase().includes(keywords)
        );
    }
    // Advanced Search Filter (runs only if no header search)
    else if (searchCriteria) {
      if (searchCriteria.keywords) {
        const keywords = searchCriteria.keywords.toLowerCase();
        tempJobs = tempJobs.filter(job => 
          job.title.toLowerCase().includes(keywords) ||
          job.description.toLowerCase().includes(keywords) ||
          job.category.toLowerCase().includes(keywords)
        );
      }
      if (searchCriteria.wilaya && searchCriteria.wilaya !== 'all') {
         tempJobs = tempJobs.filter(job => job.location.includes(searchCriteria.wilaya!));
      }
      if (searchCriteria.salary) {
        tempJobs = tempJobs.filter(job => job.salary.toLowerCase().includes(searchCriteria.salary!.toLowerCase()));
      }
    }

    return tempJobs;
  }, [jobs, activeFilter, selectedWilayas, searchCriteria, urlQuery]);
  
  const premiumJobs = useMemo(() => 
    filteredJobs.filter(job => job.packageType === 'premium'),
  [filteredJobs]);
  
  const sponsoredJobs = useMemo(() => 
    filteredJobs.filter(job => job.packageType === 'sponsored'), 
  [filteredJobs]);

  const regularJobs = useMemo(() => 
    filteredJobs.filter(job => job.packageType === 'regular'), 
  [filteredJobs]);

  const displayedRegularJobs = useMemo(() => {
    return regularJobs.slice(0, visibleJobsCount);
  }, [regularJobs, visibleJobsCount]);

  // Reset pagination when filters change
  useEffect(() => {
    setVisibleJobsCount(JOBS_PER_PAGE);
  }, [activeFilter, selectedWilayas, searchCriteria, urlQuery]);

  const handleLoadMore = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setVisibleJobsCount(prevCount => prevCount + JOBS_PER_PAGE);
      setIsLoadingMore(false);
    }, 500);
  };
  
  const isLoading = areJobsLoading;

  if (!hasMounted) {
    return (
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="hidden md:flex gap-3 items-start">
            <div className="w-2/3">
                 <Skeleton className="h-80 w-full rounded-lg" />
            </div>
            <div className="w-1/3 h-80 bg-muted rounded-lg" />
        </div>
        <div className="md:hidden">
             <Skeleton className="h-40 w-full rounded-lg" />
        </div>

        <div className="pb-3 pt-6">
          <Skeleton className="h-8 w-48" />
        </div>
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-11 w-full mt-4" />
        <div className="mt-4">
          <AdsGridSkeleton />
        </div>
      </main>
    )
  }

  return (
    <main className="container mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="hidden md:flex gap-3 items-start">
            <div className="w-2/3">
                 <FeaturedPartners jobs={premiumJobs} isLoading={isLoading} />
            </div>
            <div className="w-1/3 h-80 bg-muted rounded-lg flex items-center justify-center text-muted-foreground">
                <span>{t('HomePage.sponsoredAd')}</span>
            </div>
        </div>
        <div className="md:hidden">
            <FeaturedPartners jobs={premiumJobs} isLoading={isLoading} />
        </div>
      

      <div className="pb-3 pt-6">
        <h2 className="text-xl font-bold leading-tight">
          {activeFilter === 'all' ? t('HomePage.latestAds') : activeFilter === 'jobs' ? t('JobFilters.jobs') : t('JobFilters.trainings')}
        </h2>
      </div>

      <JobFilters activeFilter={activeFilter} setActiveFilter={setActiveFilter} />
      <WilayaFilter selectedWilayas={selectedWilayas} onWilayaChange={setSelectedWilayas} />

      {isLoading ? (
        <AdsGridSkeleton />
      ) : (
        <div className="space-y-3">
          {/* Sponsored Ads */}
          {sponsoredJobs.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {sponsoredJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          )}

          {/* Regular Ads */}
          {displayedRegularJobs.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              {displayedRegularJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          )}

          {/* No jobs found message */}
          {sponsoredJobs.length === 0 && displayedRegularJobs.length === 0 && (
             <div className="text-center py-10">
                <p className="text-muted-foreground">{t('HomePage.noJobsFound')}</p>
            </div>
          )}
        </div>
      )}
      
      {displayedRegularJobs.length > 0 && visibleJobsCount < regularJobs.length && (
          <div className="mt-8 text-center">
            <Button onClick={handleLoadMore} disabled={isLoadingMore} className="w-40 h-12">
              {isLoadingMore ? <Loader2 className="animate-spin" /> : t('HomePage.loadMore')}
            </Button>
          </div>
      )}
      
      <AdvancedSearch onSearch={setSearchCriteria} />
    </main>
  );
}
