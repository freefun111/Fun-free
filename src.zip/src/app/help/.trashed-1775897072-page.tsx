'use client';

import { useTranslation } from 'react-i18next';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

export default function HelpPage() {
  const { t } = useTranslation();

  const faqs = [
    { id: 'q1', question: t('HelpPage.q1Title'), answer: t('HelpPage.q1Text') },
    { id: 'q2', question: t('HelpPage.q2Title'), answer: t('HelpPage.q2Text') },
    { id: 'q3', question: t('HelpPage.q3Title'), answer: t('HelpPage.q3Text') },
    { id: 'q4', question: t('HelpPage.q4Title'), answer: t('HelpPage.q4Text') },
    { id: 'q5', question: t('HelpPage.q5Title'), answer: t('HelpPage.q5Text') },
    { id: 'q6', question: t('HelpPage.q6Title'), answer: t('HelpPage.q6Text') },
  ];

  return (
    <div className="mx-auto max-w-4xl min-h-screen flex flex-col bg-background pt-16 pb-24">
      <h2 className="text-2xl font-bold leading-tight tracking-tight text-center p-4">
        {t('HelpPage.title')}
      </h2>
      <main className="flex-1 p-4 space-y-6">
        <p className="text-center text-lg text-muted-foreground">
          {t('HelpPage.subtitle')}
        </p>
        
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq) => (
            <AccordionItem value={faq.id} key={faq.id}>
              <AccordionTrigger className="text-right text-lg">{faq.question}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed text-base">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </main>
    </div>
  );
}
