
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { useAuth, useFirestore } from '@/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { ArrowRight, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from 'react-i18next';

const getLoginSchema = (t: (key: string) => string) => z.object({
  email: z.string().email({ message: t('Auth.emailInvalid') }),
  password: z.string().min(6, { message: t('Auth.passwordLengthError', { count: 6 }) }),
});

type LoginFormValues = z.infer<ReturnType<typeof getLoginSchema>>;

const GoogleIcon = () => (
    <svg className="size-5" viewBox="0 0 48 48">
      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"></path>
      <path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691z"></path>
      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.223 0-9.655-3.438-11.303-8H6.306C9.656 39.663 16.318 44 24 44z"></path>
      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303c-.792 2.237-2.231 4.166-4.087 5.571l6.19 5.238C42.012 35.259 44 30.035 44 24c0-1.341-.138-2.65-.389-3.917z"></path>
    </svg>
  );

export default function LoginPage() {
  const router = useRouter();
  const auth = useAuth();
  const firestore = useFirestore();
  const { toast } = useToast();
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const loginSchema = getLoginSchema(t);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    try {
      if (!auth) throw new Error("Auth service not available");
      await signInWithEmailAndPassword(auth, data.email, data.password);
      router.push('/profile');
    } catch (error: any) {
      console.error("Login Error:", error);
      let description = t('Auth.loginErrorUnexpected');
      if (error.code === 'auth/operation-not-allowed') {
        description = t('Auth.loginErrorEmailDisabled');
      } else if (error.code === 'auth/invalid-credential') {
        description = t('Auth.loginErrorInvalidCredential');
      }
      toast({
        variant: "destructive",
        title: t('Auth.loginErrorTitle'),
        description,
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    if (!auth || !firestore) {
        toast({ variant: "destructive", title: t('Common.error'), description: "Firebase not initialized" });
        setIsGoogleLoading(false);
        return;
    }
    const provider = new GoogleAuthProvider();
    try {
        const userCredential = await signInWithPopup(auth, provider);
        const user = userCredential.user;
        const userDocRef = doc(firestore, 'users', user.uid);
        const userDocSnap = await getDoc(userDocRef);

        const userData = {
            id: user.uid,
            email: user.email,
            name: user.displayName,
            photoURL: user.photoURL,
            updatedAt: new Date().toISOString(),
        };

        if (!userDocSnap.exists()) {
            (userData as any).createdAt = new Date().toISOString();
            (userData as any).role = 'applicant'; // Default role for Google Sign-In
        }

        await setDoc(userDocRef, userData, { merge: true });

        router.push('/profile');
    } catch (error: any) {
        console.error("Google Sign-In Error: ", error);
        let description = t('Auth.googleSignInError');
        if (error.code === 'auth/operation-not-allowed') {
            description = t('Auth.googleSignInDisabled');
        }
        toast({
            variant: "destructive",
            title: t('Auth.loginErrorTitle'),
            description,
        });
    } finally {
        setIsGoogleLoading(false);
    }
  }


  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
            <Link href="/" className="inline-flex items-center mb-4">
                <h1 className="text-2xl font-black leading-tight text-foreground">{t('Header.title')}</h1>
            </Link>
          <h2 className="text-2xl font-bold tracking-tight">{t('Auth.loginTitle')}</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {t('Auth.noAccount')}{' '}
            <Link href="/signup" className="font-medium text-primary hover:underline">
              {t('Auth.createAccountLink')}
            </Link>
          </p>
        </div>

        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t('Auth.emailLabel')}</Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                {...register('email')}
                className={errors.email ? 'border-destructive' : ''}
              />
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">{t('Auth.passwordLabel')}</Label>
                <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                  {t('Auth.forgotPassword')}
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                {...register('password')}
                className={errors.password ? 'border-destructive' : ''}
              />
              {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
            </div>
            <Button type="submit" className="w-full h-11" disabled={isLoading}>
              {isLoading && <Loader2 className="me-2 size-4 animate-spin" />}
              {t('Auth.loginButton')}
            </Button>
          </form>

          <Separator className="my-6" />

          <div className="space-y-4">
            <Button variant="outline" className="w-full h-11" onClick={handleGoogleSignIn} disabled={isGoogleLoading}>
              {isGoogleLoading ? (
                <Loader2 className="me-2 size-4 animate-spin" />
              ) : (
                <GoogleIcon />
              )}
              {t('Auth.continueWithGoogle')}
            </Button>
          </div>
        </div>
        
        <div className="mt-6 text-center">
            <Button variant="ghost" onClick={() => router.push('/')} className="text-sm text-muted-foreground">
                <ArrowRight className="ms-2 size-4" />
                {t('Auth.backToHome')}
            </Button>
        </div>
      </div>
    </div>
  );
}
