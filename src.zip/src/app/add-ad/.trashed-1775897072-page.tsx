
'use client';

import { useState, useEffect, useRef, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, UploadCloud, X, Star, Crown, Briefcase, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { addJob } from '@/lib/jobs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { wilayasWithCommunes } from '@/lib/dz-communes';
import { useUser, useFirestore } from '@/firebase';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from '@/components/ui/checkbox';

type PackageType = 'regular' | 'sponsored' | 'premium';
type MainTab = 'jobs' | 'training';
type SubType = 'offer' | 'request';

const packageConfig = {
    regular: { maxImages: 4, price: 0 },
    sponsored: { maxImages: 10, price: 500 },
    premium: { maxImages: 99, price: 1000 },
};

const jobCategories = [
    'أمن وحراسة', 'إدارة وسكرتارية', 'إعلام وصحافة', 'استقبال وخدمة عملاء', 'استشارات', 'برمجيات وتطوير', 'بناء وحرف', 'بيطرة', 'تأمين', 'تجميل وحلاقة', 'ترجمة', 'تسويق ومبيعات', 'تصميم وجرافيكس', 'تعليم وتدريب', 'تموين ومطاعم', 'حرف يدوية', 'خدمات بترولية', 'خدمات بيئية', 'خدمات لوجستية ونقل', 'خدمات منزلية', 'خياطة ونسيج', 'رعاية صحية وتمريض', 'رياضة ولياقة بدنية', 'زراعة وبستنة', 'سباكة وكهرباء', 'سياحة وفندقة', 'سياقة وتوصيل', 'صناعة وتحويل', 'صيد بحري', 'صيدلة', 'طاقة وتعدين', 'عقارات', 'فن وثقافة', 'قانون ومحاماة', 'كتابة وتحرير محتوى', 'محاسبة ومالية', 'موارد بشرية', 'ميكانيكا سيارات', 'نجارة', 'نظافة', 'هندسة معمارية', 'هندسة مدنية', 'هندسة كهربائية', 'هندسة ميكانيكية'
].sort((a, b) => a.localeCompare(b, 'ar'));


export default function AddAdPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const { t, i18n } = useTranslation();

  // Component State
  const [mainTab, setMainTab] = useState<MainTab>('jobs');
  const [subType, setSubType] = useState<SubType>('offer');
  
  // Form State
  const [formData, setFormData] = useState<any>({});
  const [packageType, setPackageType] = useState<PackageType>('regular');
  const [durationDays, setDurationDays] = useState<number | null>(null);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [communes, setCommunes] = useState<string[]>([]);
  
  // UI State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const maxImages = packageConfig[packageType]?.maxImages ?? 4;

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [isUserLoading, user, router]);

  useEffect(() => {
    // Reset subtype when main tab changes
    setSubType('offer');
    setFormData({});
  }, [mainTab]);
  
  useEffect(() => {
    if (imagePreviews.length > maxImages) {
        setImagePreviews(prev => prev.slice(0, maxImages));
        toast({
            variant: 'destructive',
            title: t('AddAdPage.toastImagesCroppedTitle'),
            description: t('AddAdPage.toastImagesCroppedDescription', { count: maxImages }),
        });
    }
  }, [packageType, imagePreviews.length, maxImages, toast, t]);

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev: any) => ({ ...prev, [field]: value }));
  };

  const handleBenefitsChange = (benefit: string, checked: boolean) => {
    const currentBenefits = formData.benefits || [];
    const newBenefits = checked 
      ? [...currentBenefits, benefit]
      : currentBenefits.filter((b: string) => b !== benefit);
    handleInputChange('benefits', newBenefits);
  };

  const handleWilayaChange = (wilayaName: string) => {
    handleInputChange('wilaya', wilayaName);
    const selectedWilaya = wilayasWithCommunes.find(w => w.name === wilayaName);
    setCommunes(selectedWilaya ? selectedWilaya.communes.sort((a,b) => a.localeCompare(b, 'ar')) : []);
    handleInputChange('commune', '');
  };

  // --- Image Handling ---
  const resizeImage = (file: File, maxSize: number, quality: number): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = reject;
        reader.onload = (event) => {
            if (!event.target?.result) return reject(new Error("FileReader error"));
            const img = new window.Image();
            img.onerror = reject;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let { width, height } = img;
                if (width > maxSize || height > maxSize) {
                    if (width > height) {
                        height = Math.round(height * (maxSize / width));
                        width = maxSize;
                    } else {
                        width = Math.round(width * (maxSize / height));
                        height = maxSize;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) return reject(new Error('Canvas context error'));
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.src = event.target.result as string;
        };
        reader.readAsDataURL(file);
    });
  };

  const handleFiles = async (files: FileList) => {
    if (imagePreviews.length + files.length > maxImages) {
      toast({ variant: "destructive", title: t('AddAdPage.toastMaxImagesTitle'), description: t('AddAdPage.toastMaxImagesDescription', { count: maxImages }) });
      return;
    }
    for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) {
            toast({ variant: "destructive", title: t('AddAdPage.toastInvalidFileTitle'), description: t('AddAdPage.toastInvalidFileDescription', { fileName: file.name }) });
            continue;
        }
        try {
            const resizedDataUrl = await resizeImage(file, 1024, 0.7);
            setImagePreviews(prev => [...prev, resizedDataUrl]);
        } catch (error) {
            console.error("Image resize error:", error);
            toast({ variant: "destructive", title: t('AddAdPage.toastImageProcessErrorTitle'), description: t('AddAdPage.toastImageProcessErrorDescription', { fileName: file.name }) });
        }
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) handleFiles(event.target.files);
    if(event.target) event.target.value = '';
  };
  const removeImage = (index: number) => setImagePreviews(prev => prev.filter((_, i) => i !== index));
  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => { event.preventDefault(); event.stopPropagation(); if (event.dataTransfer.files) handleFiles(event.dataTransfer.files); };
  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => { event.preventDefault(); event.stopPropagation(); };

  // --- Submission ---
  const validateForm = () => {
      const newErrors: Record<string, string> = {};
      if (!formData.title || formData.title.length < 5) newErrors.title = t('AddAdPage.titleError');
      if (!formData.category) newErrors.category = t('AddAdPage.categoryError');
      if (!formData.wilaya) newErrors.wilaya = t('AddAdPage.wilayaError');
      if (!formData.commune) newErrors.commune = t('AddAdPage.communeError');
      if (!formData.phone1) newErrors.phone1 = t('AddAdPage.phone1Error');
      if (!formData.description || formData.description.length < 20) {
        newErrors.description = t('AddAdPage.descriptionError');
      }

      if (packageType !== 'regular' && !durationDays) {
        newErrors.durationDays = t('AddAdPage.durationError');
      }
      
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validateForm() || !user || !firestore) return;
    
    const adData = {
        userId: user.uid,
        company: user.displayName, // Fallback company name
        ...formData,
        listingType: mainTab,
        adType: subType,
        location: `${formData.commune}, ${formData.wilaya}`,
        images: imagePreviews,
        packageType,
        durationDays,
    };
    
    if (packageType === 'regular') {
        setIsSubmitting(true);
        try {
            await addJob(firestore, { ...adData, status: 'active' });
            toast({ title: t('AddAdPage.toastAdPublished') });
            router.push('/');
        } catch (error) {
            console.error("Failed to add ad", error);
            toast({ variant: "destructive", title: t('AddAdPage.toastPublishErrorTitle') });
        } finally {
            setIsSubmitting(false);
        }
    } else {
        try {
            sessionStorage.setItem('adDataForPayment', JSON.stringify(adData));
            router.push('/payment');
        } catch (error) {
            console.error("Failed to save ad data for payment:", error);
            toast({ variant: "destructive", title: t('AddAdPage.toastPaymentErrorTitle') });
        }
    }
  };

  const renderField = (name: string, label: string, placeholder: string, type = 'text', options: {value: string, label: string}[] = []) => (
    <div className="space-y-2">
      <Label htmlFor={name}>{label}</Label>
      {type === 'select' ? (
        <Select 
          onValueChange={name === 'wilaya' ? handleWilayaChange : (value) => handleInputChange(name, value)} 
          value={formData[name] || ''}
        >
          <SelectTrigger id={name}><SelectValue placeholder={placeholder} /></SelectTrigger>
          <SelectContent>{options.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
        </Select>
      ) : type === 'textarea' ? (
        <Textarea id={name} placeholder={placeholder} value={formData[name] || ''} onChange={e => handleInputChange(name, e.target.value)} />
      ) : (
        <Input id={name} type={type} placeholder={placeholder} value={formData[name] || ''} onChange={e => handleInputChange(name, e.target.value)} />
      )}
      {errors[name] && <p className="text-sm font-medium text-destructive">{errors[name]}</p>}
    </div>
  );

  const renderCheckboxGroup = (title: string, items: string[]) => (
    <div className="space-y-2">
        <Label>{title}</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 rounded-md border p-4">
            {items.map(item => (
                <div key={item} className="flex items-center gap-2">
                    <Checkbox id={item} onCheckedChange={(checked) => handleBenefitsChange(item, !!checked)} />
                    <Label htmlFor={item} className="font-normal cursor-pointer">{item}</Label>
                </div>
            ))}
        </div>
    </div>
  );

  if (isUserLoading) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;
  if (!user) return <div className="flex h-screen items-center justify-center">{t('AddAdPage.redirectToLogin')}</div>;

  return (
    <div className="mx-auto max-w-2xl min-h-screen flex flex-col bg-background pt-16 pb-24" dir={i18n.dir()}>
      <main className="flex-1 p-4">
        <Tabs value={mainTab} onValueChange={(v) => setMainTab(v as MainTab)} className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-14">
            <TabsTrigger value="jobs" className="h-full text-base gap-2"><Briefcase /> {t('AddAdPage.jobsTab')}</TabsTrigger>
            <TabsTrigger value="training" className="h-full text-base gap-2"><GraduationCap /> {t('AddAdPage.trainingTab')}</TabsTrigger>
          </TabsList>
          
          <form onSubmit={onSubmit} className="space-y-6 mt-6">
            <RadioGroup value={subType} onValueChange={(v) => setSubType(v as SubType)} className="grid grid-cols-2 gap-4">
                <div>
                    <RadioGroupItem value="offer" id="offer" className="peer sr-only" />
                    <Label htmlFor="offer" className="flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                        {mainTab === 'jobs' ? t('AddAdPage.jobOffer') : t('AddAdPage.trainingOffer')}
                    </Label>
                </div>
                <div>
                    <RadioGroupItem value="request" id="request" className="peer sr-only" />
                    <Label htmlFor="request" className="flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                        {mainTab === 'jobs' ? t('AddAdPage.jobRequest') : t('AddAdPage.trainingRequest')}
                    </Label>
                </div>
            </RadioGroup>

            <>
            {mainTab === 'jobs' && subType === 'offer' && (
                <div className="space-y-4">
                    {renderField('title', t('AddAdPage.offerTitleLabel'), t('AddAdPage.offerTitlePlaceholder'))}
                    {renderField('category', t('AddAdPage.fieldOfWork'), t('AddAdPage.categoryPlaceholder'), 'select', jobCategories.map(c => ({value: c, label: c})))}
                    {renderField('wilaya', t('AddAdPage.wilayaLabel'), t('AddAdPage.wilayaPlaceholder'), 'select', wilayasWithCommunes.map(w => ({value: w.name, label: `${w.code} - ${w.name}`})))}
                    {renderField('commune', t('AddAdPage.communeLabel'), t('AddAdPage.communePlaceholder'), 'select', communes.map(c => ({value: c, label: c})))}
                    {renderCheckboxGroup(t('AddAdPage.benefitsLabel'), [t('AddAdPage.accommodation'), t('AddAdPage.transport'), t('AddAdPage.meals'), t('AddAdPage.bonuses')])}
                    {renderField('experienceLevel', t('AddAdPage.experienceLabel'), '', 'select', [{value:'none', label: t('AddAdPage.noExperience')}, {value:'1-3', label:t('AddAdPage.experience1_3')}, {value:'>3', label:t('AddAdPage.experience3plus')}])}
                    {renderField('contractType', t('AddAdPage.contractTypeLabel'), '', 'select', [{value:'permanent', label: t('AddAdPage.permanentContract')}, {value:'temporary', label:t('AddAdPage.temporaryContract')}])}
                    {formData.contractType === 'temporary' && renderField('contractDuration', t('AddAdPage.contractDurationLabel'), t('AddAdPage.contractDurationPlaceholder'))}
                    {renderField('salaryType', t('AddAdPage.salaryProposalLabel'), '', 'select', [{value:'fixed', label: t('AddAdPage.salaryFrom')}, {value:'negotiable', label: t('AddAdPage.negotiableSalary')}])}
                    {formData.salaryType === 'fixed' && renderField('salary', t('AddAdPage.salaryLabel'), t('AddAdPage.salaryPlaceholder'))}
                    {renderField('phone1', t('AddAdPage.phone1Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone2', t('AddAdPage.phone2Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone3', t('AddAdPage.phone3Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('whatsapp', t('AddAdPage.whatsappLabel'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('description', t('AddAdPage.descriptionLabelOptional'), t('AddAdPage.descriptionPlaceholder'), 'textarea')}
                </div>
            )}

            {mainTab === 'jobs' && subType === 'request' && (
                <div className="space-y-4">
                    {renderField('title', t('AddAdPage.requestTitleLabel'), t('AddAdPage.requestTitlePlaceholder'))}
                    {renderField('category', t('AddAdPage.fieldOfWork'), t('AddAdPage.categoryPlaceholder'), 'select', jobCategories.map(c => ({value: c, label: c})))}
                    {renderField('wilaya', t('AddAdPage.wilayaLabel'), t('AddAdPage.wilayaPlaceholder'), 'select', wilayasWithCommunes.map(w => ({value: w.name, label: `${w.code} - ${w.name}`})))}
                    {renderField('commune', t('AddAdPage.communeLabel'), t('AddAdPage.communePlaceholder'), 'select', communes.map(c => ({value: c, label: c})))}
                    {renderCheckboxGroup(t('AddAdPage.seekerAdvantagesLabel'), [t('AddAdPage.privateVehicle'), t('AddAdPage.teamWork'), t('AddAdPage.twoShifts')])}
                    {renderField('experienceLevel', t('AddAdPage.experienceLabel'), '', 'select', [{value:'beginner', label: t('AddAdPage.beginner')}, {value:'intermediate', label:t('AddAdPage.intermediate')}, {value:'professional', label:t('AddAdPage.professional')}])}
                    {renderField('certificates', t('AddAdPage.certificatesLabel'), t('AddAdPage.certificatesPlaceholder'), 'textarea')}
                    {renderField('phone1', t('AddAdPage.phone1Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone2', t('AddAdPage.phone2LabelOptional'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('whatsapp', t('AddAdPage.whatsappLabel'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('description', t('AddAdPage.descriptionLabelOptional'), t('AddAdPage.requestDescriptionPlaceholder'), 'textarea')}
                </div>
            )}

            {mainTab === 'training' && subType === 'offer' && (
                <div className="space-y-4">
                    {renderField('title', t('AddAdPage.trainingOfferTitleLabel'), t('AddAdPage.trainingOfferTitlePlaceholder'))}
                    {renderField('trainingInstitution', t('AddAdPage.trainingInstitutionLabel'), t('AddAdPage.trainingInstitutionPlaceholder'))}
                    {renderField('category', t('AddAdPage.trainingFieldLabel'), t('AddAdPage.categoryPlaceholder'), 'select', jobCategories.map(c => ({value: c, label: c})))}
                    {renderField('wilaya', t('AddAdPage.wilayaLabel'), t('AddAdPage.wilayaPlaceholder'), 'select', wilayasWithCommunes.map(w => ({value: w.name, label: `${w.code} - ${w.name}`})))}
                    {renderField('commune', t('AddAdPage.communeLabel'), t('AddAdPage.communePlaceholder'), 'select', communes.map(c => ({value: c, label: c})))}
                    {renderCheckboxGroup(t('AddAdPage.benefitsLabel'), [t('AddAdPage.accommodation'), t('AddAdPage.transport'), t('AddAdPage.meals'), t('AddAdPage.certifiedDiploma'), t('AddAdPage.jobContracts')])}
                    <div className="flex gap-4">
                        {renderField('trainingDuration', t('AddAdPage.trainingDurationDaysLabel'), 'e.g., 30')}
                        {renderField('trainingHoursPerDay', t('AddAdPage.trainingHoursPerDayLabel'), 'e.g., 4')}
                    </div>
                    {renderField('phone1', t('AddAdPage.phone1Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone2', t('AddAdPage.phone2LabelOptional'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone3', t('AddAdPage.phone3LabelOptional'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('whatsapp', t('AddAdPage.whatsappLabel'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('description', t('AddAdPage.descriptionLabelOptional'), t('AddAdPage.descriptionPlaceholder'), 'textarea')}
                </div>
            )}

            {mainTab === 'training' && subType === 'request' && (
                <div className="space-y-4">
                    {renderField('title', t('AddAdPage.trainingRequestTitleLabel'), t('AddAdPage.trainingRequestTitlePlaceholder'))}
                    {renderField('category', t('AddAdPage.trainingFieldLabel'), t('AddAdPage.categoryPlaceholder'), 'select', jobCategories.map(c => ({value: c, label: c})))}
                    {renderField('trainingDurationType', t('AddAdPage.trainingDurationLabel'), '', 'select', [{value:'short', label: t('AddAdPage.shortIntensive')}, {value:'medium', label:t('AddAdPage.mediumDuration')}, {value:'long', label:t('AddAdPage.longDuration')}])}
                    {renderField('wilaya', t('AddAdPage.wilayaLabel'), t('AddAdPage.wilayaPlaceholder'), 'select', wilayasWithCommunes.map(w => ({value: w.name, label: `${w.code} - ${w.name}`})))}
                    {renderField('commune', t('AddAdPage.communeLabel'), t('AddAdPage.communePlaceholder'), 'select', communes.map(c => ({value: c, label: c})))}
                    {renderField('phone1', t('AddAdPage.phone1Label'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('phone2', t('AddAdPage.phone2LabelOptional'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('whatsapp', t('AddAdPage.whatsappLabel'), t('AddAdPage.phonePlaceholder'), 'tel')}
                    {renderField('description', t('AddAdPage.descriptionLabelOptional'), t('AddAdPage.requestDescriptionPlaceholder'), 'textarea')}
                </div>
            )}
            </>

            {/* Common Fields: Images and Packages */}
            <div className="space-y-6 pt-4 border-t">
              {/* Image Uploader */}
              <div className="space-y-2">
                <Label>{packageType === 'premium' ? t('AddAdPage.imagesUnlimited') : t('AddAdPage.imagesLabel', { count: maxImages })}</Label>
                  <div onClick={() => fileInputRef.current?.click()} onDrop={handleDrop} onDragOver={handleDragOver} className="relative flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-secondary/50 hover:bg-secondary/80">
                    <UploadCloud className="w-8 h-8 mb-2 text-muted-foreground" />
                    <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">{t('AddAdPage.uploadClick')}</span> {t('AddAdPage.uploadDrag')}</p>
                    <Input ref={fileInputRef} type="file" className="hidden" multiple accept="image/*" onChange={handleFileChange} />
                  </div>
                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-4 gap-2 mt-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square">
                        <Image src={preview} alt={`Preview ${index + 1}`} fill className="object-cover rounded-md" />
                        <Button type="button" variant="destructive" size="icon" className="absolute -top-2 -right-2 h-6 w-6 rounded-full" onClick={() => removeImage(index)}><X className="h-4 w-4" /></Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Package Selector */}
              <div className="space-y-4">
                <Label>{t('AddAdPage.packageTitle')}</Label>
                <RadioGroup onValueChange={(val) => setPackageType(val as PackageType)} value={packageType} className="grid grid-cols-1 gap-4">
                    {/* Regular Package */}
                    <div>
                        <RadioGroupItem value="regular" id="regular" className="peer sr-only" />
                        <Label htmlFor="regular" className="block cursor-pointer rounded-lg border-2 border-transparent p-0.5 transition-colors peer-data-[state=checked]:border-primary">
                            <Card><CardHeader><CardTitle className="text-lg">{t('AddAdPage.regularPackage')}</CardTitle><CardDescription>{t('AddAdPage.regularPackageDescription')}</CardDescription></CardHeader><CardContent className="space-y-2"><p className="font-bold text-lg">{t('AddAdPage.free')}</p><p className="text-sm text-muted-foreground">{t('AddAdPage.maxImages', { count: packageConfig.regular.maxImages })}</p></CardContent></Card>
                        </Label>
                    </div>
                    {/* Sponsored Package */}
                    <div>
                        <RadioGroupItem value="sponsored" id="sponsored" className="peer sr-only" />
                        <Label htmlFor="sponsored" className="block cursor-pointer rounded-lg border-2 border-transparent p-0.5 transition-colors peer-data-[state=checked]:border-primary">
                            <Card className="bg-yellow-50 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-800/50"><CardHeader><CardTitle className="text-lg flex items-center justify-between"><div className="flex items-center gap-2"><Star className="size-5 text-yellow-400 fill-yellow-400"/>{t('AddAdPage.sponsoredPackage')}</div><Badge variant="outline" className="text-yellow-500 border-yellow-500">{t('AddAdPage.popular')}</Badge></CardTitle><CardDescription>{t('AddAdPage.sponsoredPackageDescription')}</CardDescription></CardHeader><CardContent className="space-y-2"><p className="font-bold text-lg">{t('AddAdPage.priceFrom', { price: packageConfig.sponsored.price })}</p><p className="text-sm text-muted-foreground">{t('AddAdPage.maxImages', { count: packageConfig.sponsored.maxImages })}</p></CardContent></Card>
                        </Label>
                    </div>
                    {/* Premium Package */}
                    <div>
                        <RadioGroupItem value="premium" id="premium" className="peer sr-only" />
                        <Label htmlFor="premium" className="block cursor-pointer rounded-lg border-2 border-transparent p-0.5 transition-colors peer-data-[state=checked]:border-primary">
                            <Card className="bg-gradient-to-tr from-amber-100 to-yellow-100 dark:from-amber-950/50 dark:to-yellow-950/30 border-amber-300 dark:border-amber-600"><CardHeader><CardTitle className="text-lg flex items-center justify-between"><div className="flex items-center gap-2"><Crown className="size-5 text-amber-500 fill-amber-500"/>{t('AddAdPage.premiumPackage')}</div><Badge variant="outline" className="text-amber-500 border-amber-500">{t('AddAdPage.recommended')}</Badge></CardTitle><CardDescription>{t('AddAdPage.premiumPackageDescription')}</CardDescription></CardHeader><CardContent className="space-y-2"><p className="font-bold text-lg">{t('AddAdPage.priceFrom', { price: packageConfig.premium.price })}</p><p className="text-sm text-muted-foreground">{t('AddAdPage.unlimitedImages')}</p></CardContent></Card>
                        </Label>
                    </div>
                </RadioGroup>
              </div>

              {/* Duration Selector */}
              {packageType !== 'regular' && (
                <div className="space-y-2">
                  <Label htmlFor="duration">{t('AddAdPage.durationLabel')}</Label>
                  <Select onValueChange={(value) => setDurationDays(value ? parseInt(value) : null)} defaultValue={durationDays ? String(durationDays) : undefined}>
                    <SelectTrigger id="duration"><SelectValue placeholder={t('AddAdPage.durationPlaceholder')} /></SelectTrigger>
                    <SelectContent><SelectItem value="7">{t('AddAdPage.duration7')}</SelectItem><SelectItem value="15">{t('AddAdPage.duration15')}</SelectItem><SelectItem value="30">{t('AddAdPage.duration30')}</SelectItem></SelectContent>
                  </Select>
                  {errors.durationDays && <p className="text-sm font-medium text-destructive">{errors.durationDays}</p>}
                </div>
              )}
            </div>

            <Button type="submit" className="w-full h-12" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="me-2 size-4 animate-spin" /> : (packageType === 'regular' ? t('AddAdPage.submitButton') : t('AddAdPage.submitButtonPaid'))}
            </Button>
          </form>
        </Tabs>
      </main>
    </div>
  );
}
