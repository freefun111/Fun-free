'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { updateJob, type Job, type UpdateJobData } from '@/lib/jobs';
import { JobCard } from '@/components/home/JobCard';
import { Loader2, Edit, UploadCloud, X, Crown, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { wilayasWithCommunes } from '@/lib/dz-communes';
import { useToast } from '@/hooks/use-toast';
import { collection, query, where } from 'firebase/firestore';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from 'react-i18next';


type PackageType = 'regular' | 'sponsored' | 'premium';

const packageConfig = {
    regular: { maxImages: 4, price: 0 },
    sponsored: { maxImages: 10, price: 500 },
    premium: { maxImages: 99, price: 1000 },
};

type EditAdFormValues = z.infer<ReturnType<typeof useEditAdSchema>>;
const useEditAdSchema = () => {
    const { t } = useTranslation();
    return useMemo(() => z.object({
        title: z.string().min(5, { message: t('MyAdsEdit.titleError') }),
        category: z.string().min(1, { message: t('MyAdsEdit.categoryError') }),
        wilaya: z.string().min(1, { message: t('MyAdsEdit.wilayaError') }),
        commune: z.string().min(1, { message: t('MyAdsEdit.communeError') }),
        salary: z.string().optional(),
        description: z.string().min(20, { message: t('MyAdsEdit.descriptionError') }),
        packageType: z.enum(['regular', 'sponsored', 'premium'], { required_error: t('MyAdsEdit.packageTypeError') }),
        durationDays: z.coerce.number().optional().nullable(),
    }), [t]);
};


export default function MyAdsPage() {
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();
  const { t } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isMobile = useIsMobile();
  
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [isConfirmAlertOpen, setIsConfirmAlertOpen] = useState(false);
  const [pendingData, setPendingData] = useState<EditAdFormValues | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [communes, setCommunes] = useState<string[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const myJobsQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(collection(firestore, 'jobs'), where('userId', '==', user.uid));
  }, [firestore, user]);

  const { data: myJobs, isLoading: areJobsLoading } = useCollection<Job>(myJobsQuery);
  
  const editAdSchema = useEditAdSchema();

  const form = useForm<EditAdFormValues>({
    resolver: zodResolver(editAdSchema),
  });

  const selectedPackage = form.watch('packageType') as PackageType;
  const maxImages = packageConfig[selectedPackage]?.maxImages ?? 4;


  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [isUserLoading, user, router]);

  const displayedJobs = useMemo(() => {
    if (!myJobs) return [];
    const limit = isMobile ? 10 : 20;
    return myJobs.slice(0, limit);
  }, [myJobs, isMobile]);

  // When a job is selected for editing, populate the form and images
  useEffect(() => {
    if (editingJob) {
      const [commune, wilaya] = editingJob.location.split(',').map(s => s.trim());
      
      const selectedWilaya = wilayasWithCommunes.find(w => w.name === wilaya);
      setCommunes(selectedWilaya ? selectedWilaya.communes.sort((a,b) => a.localeCompare(b, 'ar')) : []);

      form.reset({
        title: editingJob.title,
        category: editingJob.category,
        wilaya: wilaya || '',
        commune: commune || '',
        salary: editingJob.salary,
        description: editingJob.description,
        packageType: editingJob.packageType,
        durationDays: editingJob.durationDays,
      });
      setImagePreviews(editingJob.images.map(img => img.imageUrl));
    } else {
      setImagePreviews([]);
    }
  }, [editingJob, form]);

  useEffect(() => {
    if (imagePreviews.length > maxImages) {
        setImagePreviews(prev => prev.slice(0, maxImages));
        toast({
            variant: 'destructive',
            title: t('MyAdsEdit.toastImagesCroppedTitle'),
            description: t('MyAdsEdit.toastImagesCroppedDescription', { count: maxImages }),
        });
    }
  }, [selectedPackage, imagePreviews.length, maxImages, toast, t]);

  const handleWilayaChange = (wilayaName: string) => {
    form.setValue('wilaya', wilayaName);
    const selectedWilaya = wilayasWithCommunes.find(w => w.name === wilayaName);
    setCommunes(selectedWilaya ? selectedWilaya.communes.sort((a,b) => a.localeCompare(b, 'ar')) : []);
    form.setValue('commune', '');
  };

  const handleEditClick = (job: Job) => {
    setEditingJob(job);
  };
  
  const handleFormSubmit = (data: EditAdFormValues) => {
    if (data.packageType !== 'regular' && !data.durationDays) {
        form.setError('durationDays', { message: t('MyAdsEdit.durationError') });
        return;
    }
    setPendingData(data);
    setIsConfirmAlertOpen(true);
  };

  const handleConfirmUpdate = async () => {
    if (!pendingData || !editingJob || !firestore) return;

    const isPaidUpgrade = pendingData.packageType !== 'regular' && 
                          (editingJob.packageType !== pendingData.packageType || editingJob.durationDays !== pendingData.durationDays);

    const fullUpdateData: UpdateJobData = {
      title: pendingData.title,
      category: pendingData.category,
      location: `${pendingData.commune}, ${pendingData.wilaya}`,
      salary: pendingData.salary,
      description: pendingData.description,
      images: imagePreviews,
      packageType: pendingData.packageType,
      durationDays: pendingData.durationDays,
    };

    if (isPaidUpgrade) {
      try {
        const paymentData = {
          jobId: editingJob.id,
          ...fullUpdateData
        };
        sessionStorage.setItem('adDataForPayment', JSON.stringify(paymentData));
        router.push('/payment');
      } catch (error) {
        console.error("Failed to save ad data for payment:", error);
        toast({
            variant: "destructive",
            title: t('Common.error'),
            description: t('AddAdPage.toastPaymentErrorDescription'),
        });
      } finally {
        setIsConfirmAlertOpen(false);
        setEditingJob(null);
      }
      return;
    }

    // It's a non-paid update.
    setIsUpdating(true);
    try {
        await updateJob(firestore, editingJob.id, fullUpdateData);
        toast({
          title: t('MyAdsEdit.updateSuccess'),
        });
    } catch (error) {
        console.error("Failed to update job", error);
        toast({
            variant: "destructive",
            title: t('Common.error'),
            description: t('MyAdsEdit.updateError')
        });
    } finally {
        setIsUpdating(false);
        setEditingJob(null);
        setPendingData(null);
        setIsConfirmAlertOpen(false);
    }
  };

    const resizeImage = (file: File, maxSize: number, quality: number): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = reject;
            reader.onload = (event) => {
                if (!event.target?.result) {
                    return reject(new Error("FileReader did not return a result."));
                }
                const img = new window.Image();
                img.onerror = reject;
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let { width, height } = img;

                    if (width > maxSize || height > maxSize) {
                        if (width > height) {
                            height = Math.round(height * (maxSize / width));
                            width = maxSize;
                        } else {
                            width = Math.round(width * (maxSize / height));
                            height = maxSize;
                        }
                    }

                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    if (!ctx) {
                        return reject(new Error('Could not get canvas context'));
                    }
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', quality));
                };
                img.src = event.target.result as string;
            };
            reader.readAsDataURL(file);
        });
    };

    const handleFiles = async (files: FileList) => {
        const newImages = Array.from(files);
        if (imagePreviews.length + newImages.length > maxImages) {
            toast({ variant: "destructive", title: t('MyAdsEdit.toastMaxImagesTitle'), description: t('MyAdsEdit.toastMaxImagesDescription', { count: maxImages }) });
            return;
        }

        const newPreviews: string[] = [];
        for (const file of newImages) {
            if (!file.type.startsWith('image/')) { toast({ variant: "destructive", title: t('MyAdsEdit.toastInvalidFileTitle'), description: t('MyAdsEdit.toastInvalidFileDescription', { fileName: file.name }) }); continue; }
            try {
                const resizedDataUrl = await resizeImage(file, 1024, 0.7);
                newPreviews.push(resizedDataUrl);
            } catch (error) {
                console.error("Image resize error:", error);
                toast({ variant: "destructive", title: t('MyAdsEdit.toastImageProcessErrorTitle'), description: t('MyAdsEdit.toastImageProcessErrorDescription', { fileName: file.name }) });
            }
        }
        setImagePreviews(prev => [...prev, ...newPreviews]);
    };
    
    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) handleFiles(event.target.files);
        if (event.target) event.target.value = '';
    };

    const removeImage = (index: number) => { setImagePreviews(prev => prev.filter((_, i) => i !== index)); };
    const handleDrop = (event: React.DragEvent<HTMLDivElement>) => { event.preventDefault(); event.stopPropagation(); if (event.dataTransfer.files?.length) handleFiles(event.dataTransfer.files); };
    const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => { event.preventDefault(); event.stopPropagation(); };
  
    const jobCategories = [
        'أمن', 'إدارة وسكرتارية', 'إعلام وصحافة', 'استقبال', 'استشارات', 'برمجيات', 'بناء', 
        'بيطرة', 'تأمين', 'تجميل وحلاقة', 'ترجمة', 'تسويق', 'تصميم', 'تعليم', 'تموين ومطاعم', 
        'حرف يدوية', 'خدمات بترولية', 'خدمات بيئية', 'خدمات لوجستية', 'خدمات منزلية', 
        'خدمة عملاء', 'خياطة', 'رعاية صحية', 'رياضة', 'زراعة', 'سباكة', 'سياحة وفندقة', 
        'سياقة ونقل', 'صناعة وتحويل', 'صيد بحري', 'صيدلة', 'طاقة وتعدين', 'عقارات', 
        'فن وثقافة', 'قانون ومحاماة', 'كتابة ومحتوى', 'محاسبة', 'مبيعات', 'موارد بشرية', 
        'ميكانيكا', 'نجارة', 'نظافة', 'هندسة مدنية'
    ].sort((a, b) => a.localeCompare(b, 'ar'));
    
  const wilayaOptions = wilayasWithCommunes.map(w => ({ code: w.code, name: w.name })).sort((a, b) => a.code - b.code);

  if (isUserLoading || areJobsLoading) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 min-h-screen flex flex-col items-center justify-center bg-background pb-20">
        <Loader2 className="size-8 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">{t('MyAds.loading')}</p>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 min-h-screen flex flex-col bg-background pt-16 pb-24">
      <h2 className="text-lg font-bold leading-tight tracking-tight text-center p-4">{t('MyAds.title')}</h2>
      <main className="flex-1">
        {myJobs && myJobs.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-3">
            {displayedJobs.map((job) => (
              <div key={job.id} className="flex flex-col gap-3">
                <JobCard job={job} />
                <Button variant="outline" className="w-full h-12" onClick={() => handleEditClick(job)}>
                  <Edit className="me-2 size-4" /> {t('MyAds.editAd')}
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
             <p className="text-lg font-semibold text-foreground">{t('MyAds.noAdsTitle')}</p>
             <p className="mt-2 text-sm text-muted-foreground">{t('MyAds.noAdsDescription')}</p>
             <Link href="/add-ad" className='mt-6'> <Button>{t('MyAds.addNewAd')}</Button> </Link>
          </div>
        )}
      </main>

      <Dialog open={!!editingJob} onOpenChange={(isOpen) => !isOpen && setEditingJob(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('MyAdsEdit.title')}</DialogTitle>
            <DialogDescription>{t('MyAdsEdit.description')}</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-2">
              <FormField control={form.control} name="title" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.adTitleLabel')}</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="category" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.categoryLabel')}</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue placeholder={t('MyAdsEdit.selectCategoryPlaceholder')} /></SelectTrigger></FormControl><SelectContent>{jobCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="wilaya" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.wilayaLabel')}</FormLabel><Select onValueChange={handleWilayaChange} value={field.value}><FormControl><SelectTrigger><SelectValue placeholder={t('MyAdsEdit.selectWilayaPlaceholder')} /></SelectTrigger></FormControl><SelectContent>{wilayaOptions.map((w) => (<SelectItem key={w.code} value={w.name}>{`${w.code.toString().padStart(2, '0')} - ${w.name}`}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="commune" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.communeLabel')}</FormLabel><Select onValueChange={field.onChange} value={field.value} disabled={communes.length === 0}><FormControl><SelectTrigger><SelectValue placeholder={t('MyAdsEdit.selectCommunePlaceholder')} /></SelectTrigger></FormControl><SelectContent>{communes.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="salary" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.salaryLabel')}</FormLabel><FormControl><Input placeholder={t('MyAdsEdit.salaryPlaceholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="description" render={({ field }) => (<FormItem><FormLabel>{t('MyAdsEdit.descriptionLabel')}</FormLabel><FormControl><Textarea className="min-h-[100px]" {...field} /></FormControl><FormMessage /></FormItem>)} />
              
              <FormItem>
                <FormLabel>
                    {selectedPackage === 'premium' 
                        ? t('MyAdsEdit.unlimitedImages') 
                        : t('MyAdsEdit.imagesLabel', { count: maxImages })
                    }
                </FormLabel>
                <FormControl>
                  <div className="relative flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-secondary/50 hover:bg-secondary/80" onClick={() => fileInputRef.current?.click()} onDrop={handleDrop} onDragOver={handleDragOver}>
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <UploadCloud className="w-8 h-8 mb-2 text-muted-foreground" />
                        <p className="mb-2 text-sm text-muted-foreground">
                            <span className="font-semibold">{t('AddAdPage.uploadClick')}</span> {t('AddAdPage.uploadDrag')}
                        </p>
                    </div>
                    <Input ref={fileInputRef} id="dropzone-file-edit" type="file" className="hidden" multiple accept="image/*" onChange={handleFileChange}/>
                  </div>
                </FormControl>
                <FormMessage />
                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-4 gap-2 mt-4">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative aspect-square">
                        <Image src={preview} alt={`Preview ${index + 1}`} fill className="object-cover rounded-md" />
                        <Button type="button" variant="destructive" size="icon" className="absolute -top-2 -right-2 h-6 w-6 rounded-full" onClick={() => removeImage(index)}> <X className="h-4 w-4" /> </Button>
                      </div>
                    ))}
                  </div>
                )}
              </FormItem>
              
              <Separator />

              <FormField
                control={form.control}
                name="packageType"
                render={({ field }) => (
                  <FormItem className="space-y-4 pt-2">
                    <FormLabel>{t('MyAdsEdit.upgradePackageTitle')}</FormLabel>
                    <FormControl>
                        <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="grid grid-cols-1 gap-4"
                        >
                        <div>
                            <RadioGroupItem value="regular" id="my-ads-edit-regular" className="peer sr-only" />
                            <Label htmlFor="my-ads-edit-regular" className="block cursor-pointer rounded-lg border-2 border-transparent transition-colors peer-data-[state=checked]:border-primary">
                            <Card>
                                <CardHeader>
                                <CardTitle className="text-lg">{t('AddAdPage.regularPackage')}</CardTitle>
                                <CardDescription>{t('AddAdPage.regularPackageDescription')}</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                <p className="font-bold text-lg">{t('AddAdPage.free')}</p>
                                <p className="text-sm text-muted-foreground">{t('AddAdPage.maxImages', { count: packageConfig.regular.maxImages })}</p>
                                </CardContent>
                            </Card>
                            </Label>
                        </div>
                        <div>
                            <RadioGroupItem value="sponsored" id="my-ads-edit-sponsored" className="peer sr-only" />
                            <Label htmlFor="my-ads-edit-sponsored" className="block cursor-pointer rounded-lg border-2 border-transparent transition-colors peer-data-[state=checked]:border-primary">
                            <Card className="bg-yellow-50 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-800/50">
                                <CardHeader>
                                <CardTitle className="text-lg flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                    <Star className="size-5 text-yellow-400 fill-yellow-400"/>
                                    {t('AddAdPage.sponsoredPackage')}
                                    </div>
                                    <Badge variant="outline" className="text-yellow-500 border-yellow-500">{t('AddAdPage.popular')}</Badge>
                                </CardTitle>
                                <CardDescription>{t('AddAdPage.sponsoredPackageDescription')}</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                <p className="font-bold text-lg">{t('AddAdPage.priceFrom', { price: packageConfig.sponsored.price })}</p>
                                <p className="text-sm text-muted-foreground">{t('AddAdPage.maxImages', { count: packageConfig.sponsored.maxImages })}</p>
                                </CardContent>
                            </Card>
                            </Label>
                        </div>
                        <div>
                            <RadioGroupItem value="premium" id="my-ads-edit-premium" className="peer sr-only" />
                            <Label htmlFor="my-ads-edit-premium" className="block cursor-pointer rounded-lg border-2 border-transparent transition-colors peer-data-[state=checked]:border-primary">
                            <Card className="bg-gradient-to-tr from-amber-100 to-yellow-100 dark:from-amber-950/50 dark:to-yellow-950/30 border-amber-300 dark:border-amber-600">
                                <CardHeader>
                                <CardTitle className="text-lg flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <Crown className="size-5 text-amber-500 fill-amber-500"/>
                                        {t('AddAdPage.premiumPackage')}
                                    </div>
                                    <Badge variant="outline" className="text-amber-500 border-amber-500">{t('AddAdPage.recommended')}</Badge>
                                </CardTitle>
                                <CardDescription>{t('AddAdPage.premiumPackageDescription')}</CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-2">
                                <p className="font-bold text-lg">{t('AddAdPage.priceFrom', { price: packageConfig.premium.price })}</p>
                                <p className="text-sm text-muted-foreground">{t('AddAdPage.unlimitedImages')}</p>
                                </CardContent>
                            </Card>
                            </Label>
                        </div>
                        </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {selectedPackage && selectedPackage !== 'regular' && (
                <FormField control={form.control} name="durationDays" render={({ field }) => ( <FormItem> <FormLabel>{t('AddAdPage.durationLabel')}</FormLabel> <Select onValueChange={(value) => field.onChange(value ? parseInt(value) : null)} defaultValue={field.value ? String(field.value) : undefined}><FormControl><SelectTrigger><SelectValue placeholder={t('AddAdPage.durationPlaceholder')} /></SelectTrigger></FormControl><SelectContent> <SelectItem value="7">{t('AddAdPage.duration7')}</SelectItem> <SelectItem value="15">{t('AddAdPage.duration15')}</SelectItem> <SelectItem value="30">{t('AddAdPage.duration30')}</SelectItem> </SelectContent></Select><FormMessage/></FormItem>)}/>
              )}

              <DialogFooter className="pt-4">
                <DialogClose asChild><Button type="button" variant="ghost">{t('Common.cancel')}</Button></DialogClose>
                <Button type="submit">{t('ProfileEdit.saveChanges')}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isConfirmAlertOpen} onOpenChange={setIsConfirmAlertOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>{t('MyAdsEdit.confirmTitle')}</AlertDialogTitle>
                <AlertDialogDescription>{t('MyAdsEdit.confirmDescription')}</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setPendingData(null)}>{t('Common.cancel')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleConfirmUpdate} disabled={isUpdating}>
                    {isUpdating ? <Loader2 className="me-2 size-4 animate-spin" /> : t('Common.confirm')}
                </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}
