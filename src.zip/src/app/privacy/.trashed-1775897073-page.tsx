'use client';

import { useTranslation } from 'react-i18next';

export default function PrivacyPage() {
  const { t } = useTranslation();
  return (
    <div className="mx-auto max-w-4xl min-h-screen flex flex-col bg-background pt-16 pb-24">
      <h2 className="text-2xl font-bold leading-tight tracking-tight text-center p-4">
        {t('PrivacyPage.title')}
      </h2>
      <main className="flex-1 p-4 space-y-6 text-foreground">
        <p className="text-sm text-muted-foreground">{t('PrivacyPage.lastUpdated')}</p>
        
        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.introductionTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.introductionText')}</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.informationWeCollectTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.informationWeCollectText')}</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground pl-4">
                <li><strong>{t('PrivacyPage.personalDataTitle')}:</strong> {t('PrivacyPage.personalDataText')}</li>
                <li><strong>{t('PrivacyPage.usageDataTitle')}:</strong> {t('PrivacyPage.usageDataText')}</li>
            </ul>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.howWeUseYourInformationTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.howWeUseYourInformationText')}</p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground pl-4">
                <li>{t('PrivacyPage.usePoint1')}</li>
                <li>{t('PrivacyPage.usePoint2')}</li>
                <li>{t('PrivacyPage.usePoint3')}</li>
                <li>{t('PrivacyPage.usePoint4')}</li>
            </ul>
        </div>
        
        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.dataSharingTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.dataSharingText')}</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.dataSecurityTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.dataSecurityText')}</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.yourRightsTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.yourRightsText')}</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.changesTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.changesText')}</p>
        </div>

        <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t('PrivacyPage.contactUsTitle')}</h3>
            <p className="text-muted-foreground leading-relaxed">{t('PrivacyPage.contactUsText')} <a href="mailto:privacy@wasla.app" className="text-primary underline">privacy@wasla.app</a>.</p>
        </div>
      </main>
    </div>
  );
}
