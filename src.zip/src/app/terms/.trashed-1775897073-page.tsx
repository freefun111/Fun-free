
'use client';

import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function TermsPage() {
  const { t } = useTranslation();

  const sections = [
    { id: 'intro', title: t('TermsPage.introTitle'), text: t('TermsPage.introText') },
    { id: 'accounts', title: t('TermsPage.accountsTitle'), text: t('TermsPage.accountsText') },
    { id: 'content', title: t('TermsPage.contentTitle'), text: t('TermsPage.contentText') },
    { id: 'prohibited', title: t('TermsPage.prohibitedTitle'), text: t('TermsPage.prohibitedText'), list: [
        t('TermsPage.prohibitedPoint1'),
        t('TermsPage.prohibitedPoint2'),
        t('TermsPage.prohibitedPoint3'),
        t('TermsPage.prohibitedPoint4'),
    ] },
    { id: 'termination', title: t('TermsPage.terminationTitle'), text: t('TermsPage.terminationText') },
    { id: 'disclaimer', title: t('TermsPage.disclaimerTitle'), text: t('TermsPage.disclaimerText') },
    { id: 'limitation', title: t('TermsPage.limitationTitle'), text: t('TermsPage.limitationText') },
    { id: 'changes', title: t('TermsPage.changesTitle'), text: t('TermsPage.changesText') },
    { id: 'contact', title: t('TermsPage.contactTitle'), text: t('TermsPage.contactText') },
  ];

  return (
    <div className="mx-auto max-w-4xl min-h-screen flex flex-col bg-background pt-16 pb-24">
      <h2 className="text-2xl font-bold leading-tight tracking-tight text-center p-4">
        {t('TermsPage.title')}
      </h2>
      <main className="flex-1 p-4 space-y-6 text-foreground">
        <p className="text-sm text-muted-foreground">{t('TermsPage.lastUpdated')}</p>
        
        {sections.map(section => (
            <Card key={section.id}>
                <CardHeader>
                    <CardTitle className="text-xl">{section.title}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground leading-relaxed">{section.text}</p>
                    {section.list && (
                        <ul className="list-disc list-inside space-y-2 mt-4 text-muted-foreground">
                            {section.list.map((item, index) => <li key={index}>{item}</li>)}
                        </ul>
                    )}
                </CardContent>
            </Card>
        ))}
      </main>
    </div>
  );
}
