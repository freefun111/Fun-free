'use client';

import { useRouter } from 'next/navigation';
import { useUserRole } from '@/hooks/useUserRole';
import { Loader2 } from 'lucide-react';
import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';

export default function AdminPage() {
  const router = useRouter();
  const { role, isLoading } = useUserRole();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="size-10 animate-spin text-primary" />
        <p className="ms-4 text-muted-foreground">جاري التحقق من الصلاحيات...</p>
      </div>
    );
  }

  if (role !== 'admin') {
    // Redirect to login or home if not an admin
    router.replace('/login');
    return (
        <div className="flex h-screen items-center justify-center bg-background">
            <p className="text-muted-foreground">ليس لديك صلاحية الوصول. يتم التوجيه...</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1">
            <AdminDashboard />
        </main>
        <Footer />
    </div>
  );
}
