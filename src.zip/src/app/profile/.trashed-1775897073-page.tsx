

'use client';

import { useEffect, useState, useRef, useMemo } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUser, useAuth, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { doc, setDoc, getDoc, collection, query, where } from 'firebase/firestore';
import { updateProfile, updatePassword } from 'firebase/auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import type { Job } from '@/lib/jobs';
import {
  Share2,
  BadgeCheck,
  Megaphone,
  Bell,
  ChevronRight,
  LogOut,
  Loader2,
  Camera,
  FileText,
  Shield,
  HelpCircle,
  Info,
  Eye,
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { useTranslation } from 'react-i18next';

const profileAvatar = PlaceHolderImages.find((img) => img.id === 'profile-avatar');

function ProfileSkeleton() {
    return (
      <div className="p-4 mt-2 animate-pulse">
        <div className="flex w-full flex-col gap-4 items-center">
            <Skeleton className="size-32 rounded-full" />
            <div className="flex flex-col items-center justify-center gap-2 w-full max-w-[200px]">
                <Skeleton className="h-7 w-full" />
                <Skeleton className="h-5 w-4/5" />
                <Skeleton className="h-4 w-3/5" />
            </div>
            <Skeleton className="h-10 w-full max-w-[320px] rounded-md" />
        </div>
        <div className="flex flex-wrap gap-3 px-4 py-4 mt-4">
            <Skeleton className="h-20 flex-1 basis-[fit-content] rounded-xl" />
            <Skeleton className="h-20 flex-1 basis-[fit-content] rounded-xl" />
        </div>
      </div>
    );
}

const phoneRegex = /^(05|06|07)\d{8}$/;
const phoneErrorMessage = 'الرجاء إدخال رقم هاتف جزائري صحيح (10 أرقام).';

const profileFormSchema = z.object({
    name: z.string().min(2, { message: "يجب أن يتكون الاسم من حرفين على الأقل." }),
    phoneNumber: z.string().regex(phoneRegex, { message: phoneErrorMessage }).optional().or(z.literal('')),
    phoneNumber2: z.string().regex(phoneRegex, { message: phoneErrorMessage }).optional().or(z.literal('')),
    phoneNumber3: z.string().regex(phoneRegex, { message: phoneErrorMessage }).optional().or(z.literal('')),
    landlineNumber: z.string().optional().or(z.literal('')),
    password: z.string().min(6, { message: "يجب أن تتكون كلمة المرور من 6 أحرف على الأقل." }).optional().or(z.literal('')),
    confirmPassword: z.string().optional().or(z.literal('')),
}).refine(data => {
    if (data.password && data.password.length > 0) {
        return data.password === data.confirmPassword;
    }
    return true;
}, {
    message: "كلمتا المرور غير متطابقتين.",
    path: ["confirmPassword"],
});
type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function ProfilePage() {
  const router = useRouter();
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const firestore = useFirestore();
  const { toast } = useToast();
  const { t, i18n } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [isConfirmAlertOpen, setIsConfirmAlertOpen] = useState(false);
  const [pendingData, setPendingData] = useState<ProfileFormValues | null>(null);

  const [firestoreUser, setFirestoreUser] = useState<any>(null);
  const [isFirestoreUserLoading, setIsFirestoreUserLoading] = useState(true);

  const jobsQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(collection(firestore, 'jobs'), where('userId', '==', user.uid));
  }, [firestore, user]);

  const { data: userJobs, isLoading: areJobsLoading } = useCollection<Job>(jobsQuery);
  
  const stats = useMemo(() => {
    if (!userJobs) {
      return { adCount: 0, totalViews: 0 };
    }
    const totalViews = userJobs.reduce((acc, job) => acc + (job.views || 0), 0);
    return {
      adCount: userJobs.length,
      totalViews,
    };
  }, [userJobs]);
  
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
        name: '',
        phoneNumber: '',
        phoneNumber2: '',
        phoneNumber3: '',
        landlineNumber: '',
        password: '',
        confirmPassword: '',
    },
  });

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [isUserLoading, user, router]);

  useEffect(() => {
    if (isUserLoading) return;
    if (!user || !firestore) {
      setIsFirestoreUserLoading(false);
      return;
    }

    const fetchUser = async () => {
        setIsFirestoreUserLoading(true);
        const userDocRef = doc(firestore, 'users', user.uid);
        try {
            const docSnap = await getDoc(userDocRef);
            if (docSnap.exists()) {
                setFirestoreUser(docSnap.data());
            } else {
                setFirestoreUser(null);
            }
        } catch (error) {
            console.error("Error fetching user document: ", error);
            setFirestoreUser(null);
        } finally {
            setIsFirestoreUserLoading(false);
        }
    };
    fetchUser();
  }, [user, isUserLoading, firestore]);

  const handleLogout = async () => {
    if (!auth) return;
    await auth.signOut();
    router.push('/login');
  };

  const handleImageClick = () => {
    if (isUploading) return;
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user || !firestore) return;

    if (!file.type.startsWith('image/')) {
        toast({
            variant: "destructive",
            title: "ملف غير صالح",
            description: "الرجاء اختيار ملف صورة.",
        });
        return;
    }
    if (file.size > 700 * 1024) { // 700KB limit
        toast({
            variant: "destructive",
            title: "حجم الملف كبير جدًا",
            description: "الرجاء اختيار صورة أصغر من 700 كيلوبايت.",
        });
        return;
    }

    setIsUploading(true);

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = async () => {
        const photoDataUrl = reader.result as string;
        try {
            const userDocRef = doc(firestore, 'users', user.uid);
            await setDoc(userDocRef, { photoURL: photoDataUrl }, { merge: true });
            toast({
                title: "تم تحديث الصورة",
                description: "تم تحديث صورة ملفك الشخصي بنجاح.",
            });
        } catch (error: any) {
            toast({
                variant: "destructive",
                title: "خطأ في تحديث الصورة",
                description: "حدث خطأ أثناء تحديث صورة ملفك الشخصي.",
            });
        } finally {
            setIsUploading(false);
            if(fileInputRef.current) {
                fileInputRef.current.value = "";
            }
        }
    };
    reader.onerror = () => {
        toast({
            variant: "destructive",
            title: "خطأ في قراءة الملف",
            description: "لم نتمكن من قراءة الملف الذي اخترته.",
        });
        setIsUploading(false);
    };
  };

  const handleFormSubmit = (data: ProfileFormValues) => {
    const hasChanges =
        data.name !== (firestoreUser?.name || user?.displayName || '') ||
        data.phoneNumber !== (firestoreUser?.phoneNumber || '') ||
        data.phoneNumber2 !== (firestoreUser?.phoneNumber2 || '') ||
        (firestoreUser?.role === 'employer' && (
            data.phoneNumber3 !== (firestoreUser?.phoneNumber3 || '') ||
            data.landlineNumber !== (firestoreUser?.landlineNumber || '')
        )) ||
        (data.password && data.password.length > 0);

    if (!hasChanges) {
        toast({ title: t('ProfileEdit.noChangesToastTitle'), description: t('ProfileEdit.noChangesToastDescription') });
        setIsEditDialogOpen(false);
        return;
    }
    
    setPendingData(data);
    setIsConfirmAlertOpen(true);
  };
  
  const handleConfirmUpdate = async () => {
      if (!pendingData || !user || !auth.currentUser || !firestore) return;
      
      setIsUpdatingProfile(true);
      
      try {
          const updatePromises: Promise<any>[] = [];
          const firestoreUpdateData: { [key: string]: any } = {};

          if (pendingData.name !== (firestoreUser?.name || user.displayName)) {
              updatePromises.push(updateProfile(auth.currentUser, { displayName: pendingData.name }));
              firestoreUpdateData.name = pendingData.name;
          }

          if (pendingData.phoneNumber !== (firestoreUser?.phoneNumber || '')) {
              firestoreUpdateData.phoneNumber = pendingData.phoneNumber;
          }

          if (pendingData.phoneNumber2 !== (firestoreUser?.phoneNumber2 || '')) {
              firestoreUpdateData.phoneNumber2 = pendingData.phoneNumber2;
          }
          
          if (firestoreUser?.role === 'employer') {
              if (pendingData.phoneNumber3 !== (firestoreUser?.phoneNumber3 || '')) {
                  firestoreUpdateData.phoneNumber3 = pendingData.phoneNumber3;
              }
              if (pendingData.landlineNumber !== (firestoreUser?.landlineNumber || '')) {
                  firestoreUpdateData.landlineNumber = pendingData.landlineNumber;
              }
          }

          if (pendingData.password && pendingData.password.length >= 6) {
              updatePromises.push(updatePassword(auth.currentUser, pendingData.password));
          }

          if (Object.keys(firestoreUpdateData).length > 0) {
              firestoreUpdateData.updatedAt = new Date().toISOString();
              const userDocRef = doc(firestore, 'users', user.uid);
              updatePromises.push(setDoc(userDocRef, firestoreUpdateData, { merge: true }));
          }

          await Promise.all(updatePromises);
          
          toast({ title: t('ProfileEdit.updateSuccessToastTitle'), description: t('ProfileEdit.updateSuccessToastDescription') });
          
      } catch (error: any) {
          let description = t('ProfileEdit.updateErrorToastDescription');
          if (error.code === 'auth/requires-recent-login') {
              description = t('ProfileEdit.updateErrorReLogin');
          }
          toast({ variant: "destructive", title: t('ProfileEdit.updateErrorToastTitle'), description });
      } finally {
          setIsUpdatingProfile(false);
          setIsConfirmAlertOpen(false);
          setIsEditDialogOpen(false);
          setPendingData(null);
      }
  };

  const handleShareApp = () => {
    if (navigator.share) {
      navigator.share({
        title: t('Share.shareAppTitle'),
        text: t('Share.shareAppText'),
        url: window.location.origin,
      })
      .catch((error) => {
        if (error.name === 'AbortError') return;
        navigator.clipboard.writeText(window.location.origin);
        toast({
          title: t('Share.unavailableTitle'),
          description: t('Share.unavailableDescription'),
        });
      });
    } else {
      navigator.clipboard.writeText(window.location.origin);
      toast({
        title: t('Share.linkCopiedTitle'),
        description: t('Share.linkCopiedDescription'),
      });
    }
  };
  
  if (isUserLoading || isFirestoreUserLoading || areJobsLoading) {
    return (
        <div className="mx-auto max-w-none min-h-screen flex flex-col pt-16 pb-24 bg-background">
            <main className="flex-1">
                <ProfileSkeleton />
            </main>
        </div>
    )
  }

  if (!user) {
      return (
          <div className="mx-auto max-w-none min-h-screen flex flex-col items-center justify-center">
              <Loader2 className="size-8 animate-spin text-primary" />
          </div>
      )
  }

  return (
    <div className="mx-auto max-w-none min-h-screen flex flex-col pt-16 pb-24 bg-background">
      <div className="flex items-center justify-between px-4">
        <h2 className="text-lg font-bold leading-tight tracking-tight">{t('ProfilePage.title')}</h2>
        <Button variant="ghost" size="icon" className="text-foreground" onClick={handleShareApp}>
          <Share2 className="size-6" />
        </Button>
      </div>

      <main className="flex-1">
        <section className="flex p-4 mt-2">
          <div className="flex w-full flex-col gap-4 items-center">
            <div className="flex gap-4 flex-col items-center">
              <div className="relative group">
                <Image
                    src={firestoreUser?.photoURL || user.photoURL || profileAvatar?.imageUrl || '/default-avatar.png'}
                    alt={user.displayName || 'صورة المستخدم'}
                    width={128}
                    height={128}
                    className="rounded-full border-4 border-primary/20 shadow-xl bg-muted object-cover"
                    placeholder="blur"
                    blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mN8/x8AAuMB8DtXNJsAAAAASUVORK5CYII="
                  />
                <div
                    className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    onClick={handleImageClick}
                    aria-label="تغيير صورة الملف الشخصي"
                >
                    {isUploading ? (
                        <Loader2 className="size-8 animate-spin text-white" />
                    ) : (
                        <Camera className="size-8 text-white" />
                    )}
                </div>
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                    accept="image/png, image/jpeg"
                />
                <div className="absolute bottom-1 left-1 bg-primary text-white p-1 rounded-full border-2 border-background">
                  <BadgeCheck className="size-4" fill="currentColor" />
                </div>
              </div>
              <div className="flex flex-col items-center justify-center">
                <p className="text-foreground text-[22px] font-bold leading-tight text-center">{firestoreUser?.name || user.displayName || 'مستخدم جديد'}</p>
                <p className="text-muted-foreground text-base font-normal leading-normal text-center">{user.email}</p>
                <p className="text-muted-foreground/70 text-sm font-normal leading-normal text-center">
                  {t('PublisherInfo.memberSince', { date: user.metadata.creationTime ? new Date(user.metadata.creationTime).toLocaleDateString(i18n.language, { year: 'numeric', month: 'long' }) : '...' })}
                </p>
              </div>
            </div>
            <Dialog 
              open={isEditDialogOpen} 
              onOpenChange={(open) => {
                  if (open && !isFirestoreUserLoading && (firestoreUser || user)) {
                      form.reset({
                          name: firestoreUser?.name || user?.displayName || '',
                          phoneNumber: firestoreUser?.phoneNumber || '',
                          phoneNumber2: firestoreUser?.phoneNumber2 || '',
                          phoneNumber3: firestoreUser?.phoneNumber3 || '',
                          landlineNumber: firestoreUser?.landlineNumber || '',
                          password: '',
                          confirmPassword: '',
                      });
                  }
                  setIsEditDialogOpen(open);
              }}
            >
                <DialogTrigger asChild>
                    <Button className="w-full h-10 px-6 shadow-lg shadow-primary/20 max-w-[320px]">
                        <span className="truncate">{t('ProfilePage.editProfile')}</span>
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>{t('ProfileEdit.title')}</DialogTitle>
                      <DialogDescription>
                        {t('ProfileEdit.description')}
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4 py-4 max-h-[70vh] overflow-y-auto px-2">
                        <FormField control={form.control} name="name" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.fullNameLabel')}</FormLabel><FormControl><Input placeholder={t('ProfileEdit.fullNamePlaceholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                        <FormField control={form.control} name="phoneNumber" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.phoneLabel')}</FormLabel><FormControl><Input type="tel" dir="ltr" placeholder={t('ProfileEdit.phonePlaceholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                        {firestoreUser?.role === 'applicant' && (
                            <FormField control={form.control} name="phoneNumber2" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.phone2Label')}</FormLabel><FormControl><Input type="tel" dir="ltr" placeholder={t('ProfileEdit.phone2Placeholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                        )}
                        {firestoreUser?.role === 'employer' && (
                            <>
                                <FormField control={form.control} name="phoneNumber2" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.phone2Label')}</FormLabel><FormControl><Input type="tel" dir="ltr" placeholder={t('ProfileEdit.phone2Placeholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                                <FormField control={form.control} name="phoneNumber3" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.phone3Label')}</FormLabel><FormControl><Input type="tel" dir="ltr" placeholder={t('ProfileEdit.phone3Placeholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                                <FormField control={form.control} name="landlineNumber" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.landlineLabel')}</FormLabel><FormControl><Input type="tel" dir="ltr" placeholder={t('ProfileEdit.landlinePlaceholder')} {...field} /></FormControl><FormMessage /></FormItem>)} />
                            </>
                        )}
                        <hr className="my-4"/>
                        <p className="text-sm text-muted-foreground">{t('ProfileEdit.passwordChangeInfo')}</p>
                        <FormField control={form.control} name="password" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.newPasswordLabel')}</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                        <FormField control={form.control} name="confirmPassword" render={({ field }) => (<FormItem><FormLabel>{t('ProfileEdit.confirmPasswordLabel')}</FormLabel><FormControl><Input type="password" {...field} /></FormControl><FormMessage /></FormItem>)} />
                        <DialogFooter>
                            <DialogClose asChild><Button variant="ghost">{t('Common.cancel')}</Button></DialogClose>
                            <Button type="submit" disabled={isUpdatingProfile}>
                                {isUpdatingProfile ? (<><Loader2 className="me-2 size-4 animate-spin" />{t('ProfileEdit.saving')}</>) : (t('ProfileEdit.saveChanges'))}
                            </Button>
                        </DialogFooter>
                    </form>
                    </Form>
                </DialogContent>
            </Dialog>
          </div>
        </section>

        <section className="flex flex-wrap gap-3 px-4 py-4">
          <div className="flex min-w-[100px] flex-1 basis-[fit-content] flex-col gap-1 rounded-xl border bg-card p-4 items-center text-center shadow-sm">
            <p className="text-foreground text-2xl font-extrabold leading-tight">{stats.adCount.toLocaleString(i18n.language)}</p>
            <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wider">{t('ProfilePage.myAds')}</p>
          </div>
          <div className="flex min-w-[100px] flex-1 basis-[fit-content] flex-col gap-1 rounded-xl border bg-card p-4 items-center text-center shadow-sm">
            <p className="text-foreground text-2xl font-extrabold leading-tight">{stats.totalViews.toLocaleString(i18n.language)}</p>
            <p className="text-muted-foreground text-xs font-semibold uppercase tracking-wider">{t('ProfilePage.views')}</p>
          </div>
        </section>
        
        <Separator className="my-4" />

        <section>
          <div className="flex flex-col gap-1">
            <Link href="/my-ads" className="block cursor-pointer hover:bg-secondary">
              <div className="flex items-center gap-4 bg-transparent px-4 min-h-[72px] py-3 justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-12">
                    <Megaphone className="size-6" />
                  </div>
                  <div className="flex flex-col justify-center">
                    <p className="text-foreground text-base font-semibold leading-normal line-clamp-1">{t('ProfilePage.myAdsTitle')}</p>
                    <p className="text-muted-foreground text-xs font-normal leading-normal">{t('ProfilePage.myAdsDescription')}</p>
                  </div>
                </div>
                <div className="shrink-0">
                  <ChevronRight className="size-6 text-muted-foreground/50" />
                </div>
              </div>
            </Link>
          </div>
        </section>

        <Separator className="my-4" />

        <section>
          <div className="flex items-center justify-between px-4 pb-2 pt-2">
            <h3 className="text-foreground text-lg font-bold leading-tight">{t('ProfilePage.accountManagement')}</h3>
          </div>
          <div className="flex flex-col gap-1">
            <Dialog>
                <DialogTrigger asChild>
                    <div className="block cursor-pointer hover:bg-secondary">
                        <div className="flex items-center gap-4 bg-transparent px-4 min-h-[72px] py-3 justify-between">
                            <div className="flex items-center gap-4">
                                <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-12">
                                    <Shield className="size-6" />
                                </div>
                                <div className="flex flex-col justify-center">
                                    <p className="text-foreground text-base font-semibold leading-normal line-clamp-1">{t('ProfilePage.privacySecurityTitle')}</p>
                                </div>
                            </div>
                            <div className="shrink-0">
                                <ChevronRight className="size-6 text-muted-foreground/50" />
                            </div>
                        </div>
                    </div>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{t('ProfilePage.privacySecurityTitle')}</DialogTitle>
                    </DialogHeader>
                    <div className="py-4">
                        <p className="text-center text-muted-foreground">صفحة الخصوصية والأمان قيد الإنشاء.</p>
                    </div>
                </DialogContent>
            </Dialog>

            <Dialog>
                <DialogTrigger asChild>
                     <div className="block cursor-pointer hover:bg-secondary">
                        <div className="flex items-center gap-4 bg-transparent px-4 min-h-[72px] py-3 justify-between">
                            <div className="flex items-center gap-4">
                                <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-12">
                                    <HelpCircle className="size-6" />
                                </div>
                                <div className="flex flex-col justify-center">
                                    <p className="text-foreground text-base font-semibold leading-normal line-clamp-1">{t('ProfilePage.helpCenterTitle')}</p>
                                </div>
                            </div>
                            <div className="shrink-0">
                                <ChevronRight className="size-6 text-muted-foreground/50" />
                            </div>
                        </div>
                    </div>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{t('ProfilePage.helpCenterTitle')}</DialogTitle>
                    </DialogHeader>
                    <div className="py-4">
                        <p className="text-center text-muted-foreground">صفحة مركز المساعدة قيد الإنشاء.</p>
                    </div>
                </DialogContent>
            </Dialog>
            
            <Dialog>
                <DialogTrigger asChild>
                    <div className="block cursor-pointer hover:bg-secondary">
                        <div className="flex items-center gap-4 bg-transparent px-4 min-h-[72px] py-3 justify-between">
                            <div className="flex items-center gap-4">
                                <div className="text-primary flex items-center justify-center rounded-lg bg-primary/10 shrink-0 size-12">
                                    <Info className="size-6" />
                                </div>
                                <div className="flex flex-col justify-center">
                                    <p className="text-foreground text-base font-semibold leading-normal line-clamp-1">{t('ProfilePage.aboutAppTitle')}</p>
                                </div>
                            </div>
                            <div className="shrink-0">
                                <ChevronRight className="size-6 text-muted-foreground/50" />
                            </div>
                        </div>
                    </div>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{t('ProfilePage.aboutAppTitle')}</DialogTitle>
                    </DialogHeader>
                    <div className="py-4">
                        <p className="text-center text-muted-foreground">صفحة عن التطبيق قيد الإنشاء.</p>
                    </div>
                </DialogContent>
            </Dialog>
          </div>
        </section>

        <div className="px-4 mt-8">
            <Button variant="outline" onClick={handleLogout} className="w-full h-auto py-4 border-red-500/30 text-red-500 hover:bg-red-500/10 hover:text-red-500">
              <LogOut />
              {t('ProfilePage.logout')}
            </Button>
          <p className="text-center text-xs text-muted-foreground/50 mt-6 pb-8">{t('ProfilePage.appVersion')}</p>
        </div>
      </main>

      <AlertDialog open={isConfirmAlertOpen} onOpenChange={setIsConfirmAlertOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>{t('ProfileEdit.confirmTitle')}</AlertDialogTitle>
                <AlertDialogDescription>
                    {t('ProfileEdit.confirmDescription')}
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setPendingData(null)}>{t('Common.cancel')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleConfirmUpdate} disabled={isUpdatingProfile}>
                    {isUpdatingProfile ? <><Loader2 className="me-2 size-4 animate-spin" />{t('Common.confirm')}</> : t('Common.confirm')}
                </AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}
