'use client';
import { redirect, useParams } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';

export default function DeprecatedPage() {
  const params = useParams();
  const { id } = params;

  useEffect(() => {
    if (id) {
      redirect(`/jobs/${id}`);
    } else {
      redirect('/'); 
    }
  }, [id]);

  return (
    <div className="flex h-screen items-center justify-center">
      <Loader2 className="animate-spin size-8 text-primary" />
    </div>
  );
}
