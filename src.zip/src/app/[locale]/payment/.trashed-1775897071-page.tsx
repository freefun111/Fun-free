'use client';

import { redirect } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';

export default function DeprecatedPage() {
  useEffect(() => {
    redirect('/payment');
  }, []);

  return (
    <div className="flex h-screen items-center justify-center">
      <Loader2 className="animate-spin size-8 text-primary" />
    </div>
  );
}
