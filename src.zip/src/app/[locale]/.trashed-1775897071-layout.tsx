'use client';

// This layout is part of the i18n refactoring.
// It ensures that routes under the old `/[locale]` structure
// are rendered within the main root layout, allowing them to
// execute their client-side redirects correctly.
export default function DeprecatedLocaleLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // This layout does not render any UI of its own. It just passes
  // children through, so that the redirect pages can be rendered
  // within the context of the main root layout, which provides all
  // necessary context providers (like the I18nProvider).
  return <>{children}</>;
}
