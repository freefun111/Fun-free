'use client';

import React, { useEffect, type ReactNode, useState } from 'react';
import { I18nextProvider } from 'react-i18next';
import i18n from '@/i18n';
import { Loader2 } from 'lucide-react';

export function I18nProvider({ children }: { children: ReactNode }) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const savedLang = localStorage.getItem('lang') as 'ar' | 'en' | null;
    const initialLang = savedLang || 'ar';
    
    // Function to set language and direction
    const setLanguage = (lang: string) => {
      document.documentElement.lang = lang;
      document.documentElement.dir = i18n.dir(lang);
      localStorage.setItem('lang', lang);
    };

    const handleLanguageChange = (lng: string) => {
      setLanguage(lng);
    };
    
    if (i18n.language !== initialLang) {
      i18n.changeLanguage(initialLang, (err, t) => {
        if (err) {
          console.error("Error changing language", err);
          return;
        }
        setLanguage(initialLang);
        setIsLoaded(true);
      });
    } else {
      setLanguage(initialLang);
      setIsLoaded(true);
    }
    
    i18n.on('languageChanged', handleLanguageChange);

    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, []);

  if (!isLoaded) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="animate-spin size-8 text-primary" />
      </div>
    );
  }

  return (
    <I18nextProvider i18n={i18n}>
      {children}
    </I18nextProvider>
  );
}
