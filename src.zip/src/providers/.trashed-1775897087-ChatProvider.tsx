'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ChatWindow } from '@/components/chat/ChatWindow';

interface ChatContextType {
  openChat: (chatId: string) => void;
  closeChat: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const [activeChatId, setActiveChatId] = useState<string | null>(null);

  const openChat = (chatId: string) => {
    setActiveChatId(chatId);
  };

  const closeChat = () => {
    setActiveChatId(null);
  };

  const value = { openChat, closeChat };

  return (
    <ChatContext.Provider value={value}>
      {children}
      <Dialog open={!!activeChatId} onOpenChange={(isOpen) => !isOpen && closeChat()}>
        <DialogContent className="p-0 flex flex-col gap-0 w-screen h-screen max-w-full rounded-none border-0 top-0 left-0 translate-x-0 translate-y-0 sm:border sm:rounded-lg sm:w-full sm:max-w-lg sm:h-[80vh] sm:left-1/2 sm:top-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2">
          <DialogHeader className="sr-only">
            <DialogTitle>Chat Window</DialogTitle>
          </DialogHeader>
          {activeChatId && <ChatWindow chatId={activeChatId} />}
        </DialogContent>
      </Dialog>
    </ChatContext.Provider>
  );
}
