'use client';

import React from 'react';
import { ThemeProvider } from '@/components/providers/theme-provider';
import { I18nProvider } from '@/providers/i18n-provider';
import { FirebaseClientProvider } from '@/firebase';
import { Toaster } from '@/components/ui/toaster';
import { ChunkLoadErrorHandler } from '@/components/ChunkLoadErrorHandler';
import { Header } from '@/components/layout/Header';
import { BottomNav } from '@/components/layout/BottomNav';
import { Footer } from '@/components/layout/Footer';
import { ChatProvider } from '@/providers/ChatProvider';

export function RootProvider({ children }: { children: React.ReactNode }) {
  return (
    <ChunkLoadErrorHandler>
      <ThemeProvider>
        <I18nProvider>
          <FirebaseClientProvider>
            <ChatProvider>
              <div className="flex-1 flex flex-col">
                <Header />
                <main className="flex-1">{children}</main>
                <BottomNav />
              </div>
              <Footer />
              <Toaster />
            </ChatProvider>
          </FirebaseClientProvider>
        </I18nProvider>
      </ThemeProvider>
    </ChunkLoadErrorHandler>
  );
}
