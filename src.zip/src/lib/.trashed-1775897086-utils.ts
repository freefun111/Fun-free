import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Normalizes an Algerian phone number by removing the leading '0' and adding the country code.
 * @param phone - The 10-digit Algerian phone number (e.g., "0555123456").
 * @returns The normalized phone number (e.g., "+213555123456").
 */
export function normalizePhone(phone: string): string {
  if (phone.startsWith('0')) {
    return `+213${phone.substring(1)}`;
  }
  // If it doesn't start with 0, assume it's already in a different format or incorrect.
  // For this app's logic, we primarily expect numbers starting with 0.
  return phone;
}

/**
 * Creates a fake email address from a phone number to use with Firebase's
 * email/password authentication provider.
 * @param phone - The 10-digit Algerian phone number.
 * @returns A formatted email string (e.g., "+213555123456@wasladz.app").
 */
export function createEmailFromPhone(phone: string): string {
    const normalizedPhone = normalizePhone(phone.replace(/\s+/g, ''));
    return `${normalizedPhone}@wasladz.app`;
}
