'use client';
import { Firestore, doc, runTransaction, Timestamp, collection, getDoc } from 'firebase/firestore';

// Function to get a user's existing rating for a job
export async function getUserRatingForJob(db: Firestore, jobId: string, userId: string): Promise<number | null> {
  const ratingDocRef = doc(db, 'jobs', jobId, 'ratings', userId);
  const docSnap = await getDoc(ratingDocRef);
  if (docSnap.exists()) {
    return docSnap.data().rating as number;
  }
  return null;
}

// Function to submit or update a rating
export async function submitJobRating(db: Firestore, jobId: string, userId: string, newRating: number): Promise<{ newAverage: number, newCount: number }> {
  const jobRef = doc(db, 'jobs', jobId);
  const ratingRef = doc(jobRef, 'ratings', userId);

  try {
    const { newAverage, newCount } = await runTransaction(db, async (transaction) => {
      const jobDoc = await transaction.get(jobRef);
      const ratingDoc = await transaction.get(ratingRef);

      if (!jobDoc.exists()) {
        throw "Job does not exist!";
      }

      const jobData = jobDoc.data();
      const currentRatingCount = jobData.ratingCount || 0;
      const currentAverageRating = jobData.averageRating || 0;
      const oldRating = ratingDoc.exists() ? ratingDoc.data().rating : 0;
      
      const isNewRating = !ratingDoc.exists();
      const newRatingCount = isNewRating ? currentRatingCount + 1 : currentRatingCount;
      
      // Calculate new average
      const currentTotalRating = currentAverageRating * currentRatingCount;
      const newTotalRating = currentTotalRating - oldRating + newRating;
      const newAverageRating = newRatingCount > 0 ? newTotalRating / newRatingCount : 0;

      // Set/update the rating subcollection document
      transaction.set(ratingRef, { userId, rating: newRating, createdAt: Timestamp.now() });

      // Update the main job document
      transaction.update(jobRef, {
        ratingCount: newRatingCount,
        averageRating: newAverageRating,
        updatedAt: Timestamp.now(),
      });

      return { newAverage: newAverageRating, newCount: newRatingCount };
    });

    return { newAverage, newCount };
  } catch (e) {
    console.error("Rating transaction failed: ", e);
    throw e;
  }
}
