'use client';

import {
  Firestore,
  doc,
  updateDoc,
  Timestamp,
} from 'firebase/firestore';

export interface Notification {
  id: string; // Document ID
  userId: string;
  title: string;
  body: string;
  link: string;
  isRead: boolean;
  type: 'new_rating' | 'new_message' | 'job_application' | 'system' | 'subscription_expiry';
  createdAt: Timestamp;
}

/**
 * Marks a specific notification as read in Firestore.
 * This is a non-blocking "fire and forget" operation.
 * @param firestore The Firestore instance.
 * @param userId The ID of the user who owns the notification.
 * @param notificationId The ID of the notification to update.
 */
export function markNotificationAsRead(firestore: Firestore, userId: string, notificationId: string): void {
  const notificationRef = doc(firestore, 'users', userId, 'notifications', notificationId);
  
  // We don't await this. Let it happen in the background.
  // The UI will update optimistically via the real-time listener.
  updateDoc(notificationRef, { isRead: true }).catch(error => {
    // In a production app, you might want to emit this error to a global handler
    // to potentially show a toast message if the update fails.
    console.error("Failed to mark notification as read:", error);
  });
}
