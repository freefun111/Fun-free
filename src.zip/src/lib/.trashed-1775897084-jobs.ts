'use client';

import {
  Firestore,
  collection,
  addDoc,
  updateDoc,
  doc,
  serverTimestamp,
  Timestamp,
  runTransaction,
  increment,
  getDoc,
  setDoc,
} from 'firebase/firestore';

export interface JobImage {
  imageUrl: string;
  description?: string;
  imageHint?: string;
}

export interface Job {
  id: string; // Firestore Document ID
  userId: string;
  listingType: 'jobs' | 'training';
  adType: 'offer' | 'request';
  title: string;
  company?: string; // For job offers
  trainingInstitution?: string; // For training offers
  category: string;
  location: string;
  description?: string;
  benefits?: string[];
  experienceLevel?: string;
  contractType?: string;
  contractDuration?: string;
  salaryType?: string;
  salary?: string;
  certificates?: string;
  phone1?: string;
  phone2?: string;
  phone3?: string;
  whatsapp?: string;
  trainingDuration?: string; // For training offers (e.g., "30 days / 4 hours per day")
  trainingDurationType?: string; // For training requests (e.g., "short", "medium", "long")
  views?: number;
  likes?: number;
  averageRating?: number;
  ratingCount?: number;

  images: JobImage[];
  status: 'active' | 'pending_review' | 'expired' | 'rejected';
  paymentReceipt?: string;

  // Package info
  packageType: 'premium' | 'sponsored' | 'regular';
  packageOrder: 1 | 2 | 3; // 1 for premium, 2 for sponsored, 3 for regular
  durationDays?: number | null;
  packageExpiresAt?: Timestamp | null;
  
  // Timestamps
  createdAt: Timestamp;
  updatedAt: Timestamp;
}


// A comprehensive type for all possible fields from the new form
export type NewJobData = Partial<Omit<Job, 'id' | 'createdAt' | 'updatedAt' | 'packageOrder' | 'packageExpiresAt' | 'views' | 'likes' | 'averageRating' | 'ratingCount'>> & {
  userId: string;
  listingType: 'jobs' | 'training';
  adType: 'offer' | 'request';
  title: string;
  category: string;
  location: string;
  phone1: string;
  packageType: 'premium' | 'sponsored' | 'regular';
  status: 'active' | 'pending_review';
  images?: string[]; // Expecting array of data URLs
};


export interface UpdateJobData {
  title?: string;
  category?: string;
  location?: string;
  description?: string;
  benefits?: string[];
  experienceLevel?: string;
  contractType?: string;
  contractDuration?: string;
  salaryType?: string;
  salary?: string;
  certificates?: string;
  phone1?: string;
  phone2?: string;
  phone3?: string;
  whatsapp?: string;
  trainingInstitution?: string;
  trainingDuration?: string;
  trainingDurationType?: string;
  images?: string[];
  packageType?: 'premium' | 'sponsored' | 'regular';
  durationDays?: number | null;
  status?: 'active' | 'pending_review' | 'expired' | 'rejected';
  paymentReceipt?: string;
}

function getPackageOrder(packageType: 'premium' | 'sponsored' | 'regular'): 1 | 2 | 3 {
    switch (packageType) {
        case 'premium': return 1;
        case 'sponsored': return 2;
        default: return 3;
    }
}

export const addJob = async (firestore: Firestore, jobData: NewJobData) => {
  const jobsCollection = collection(firestore, 'jobs');
  
  let packageExpiresAt: Date | null = null;
  if (jobData.packageType !== 'regular' && jobData.durationDays) {
      packageExpiresAt = new Date();
      packageExpiresAt.setDate(packageExpiresAt.getDate() + jobData.durationDays);
  }

  const newJob = {
    ...jobData,
    images: jobData.images ? jobData.images.map(url => ({ imageUrl: url })) : [],
    packageOrder: getPackageOrder(jobData.packageType),
    packageExpiresAt: packageExpiresAt ? Timestamp.fromDate(packageExpiresAt) : null,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    views: 0,
    likes: 0,
    averageRating: 0,
    ratingCount: 0,
  };
  
  // Clean up undefined properties before sending to Firestore
  Object.keys(newJob).forEach(key => (newJob as any)[key] === undefined && delete (newJob as any)[key]);

  return await addDoc(jobsCollection, newJob);
};

export const updateJob = async (firestore: Firestore, jobId: string, data: UpdateJobData) => {
    const jobRef = doc(firestore, 'jobs', jobId);
    
    const updateData: { [key: string]: any } = { ...data, updatedAt: serverTimestamp() };
    
    if (data.images !== undefined) {
        updateData.images = data.images.map(url => ({ imageUrl: url }));
    }

    if (data.packageType) {
        updateData.packageOrder = getPackageOrder(data.packageType);
        if (data.packageType !== 'regular' && data.durationDays) {
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + data.durationDays);
            updateData.packageExpiresAt = Timestamp.fromDate(expiryDate);
        } else {
            updateData.packageExpiresAt = null;
        }
    }
    // Remove undefined fields
    Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);
    
    await updateDoc(jobRef, updateData);
};

export const incrementJobView = async (db: Firestore, jobId: string) => {
  const jobRef = doc(db, "jobs", jobId);
  try {
    await updateDoc(jobRef, {
      views: increment(1)
    });
  } catch (error) {
    console.error("Error incrementing job view:", error);
    // Don't throw, fail silently
  }
};

export const toggleJobLike = async (db: Firestore, jobId: string, like: boolean) => {
  const jobRef = doc(db, "jobs", jobId);
  try {
    await updateDoc(jobRef, {
      likes: increment(like ? 1 : -1)
    });
  } catch (error) {
    console.error("Error toggling job like:", error);
    // Don't throw, fail silently
  }
};
