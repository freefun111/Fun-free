import { wilayasWithCommunes } from './dz-communes';

export const wilayas = wilayasWithCommunes.map(w => ({
    code: w.code,
    name: w.name,
})).sort((a,b) => a.code - b.code);

export const wilayaLabels = wilayas.map(w => w.name);
