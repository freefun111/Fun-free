'use client';
import { Firestore, doc, updateDoc, Timestamp } from 'firebase/firestore';

export interface UserProfile {
  id: string;
  role: 'applicant' | 'employer' | 'admin';
  name: string;
  email: string;
  photoURL?: string;
  phoneNumber?: string;
  phoneNumber2?: string;
  phoneNumber3?: string;
  landlineNumber?: string;
  wilaya?: string;
  address?: string;
  status: 'active' | 'banned';
  createdAt: Timestamp | string;
  updatedAt: Timestamp | string;
}

export const updateUserStatus = async (db: Firestore, userId: string, status: 'active' | 'banned') => {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, { status });
};
