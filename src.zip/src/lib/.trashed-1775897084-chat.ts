
'use client';

import {
  Firestore,
  collection,
  query,
  where,
  getDocs,
  addDoc,
  serverTimestamp,
  doc,
  writeBatch,
  Timestamp,
  getDoc,
  updateDoc,
} from 'firebase/firestore';
import { User } from 'firebase/auth';

// Type for a chat document from Firestore
export interface Chat {
  id: string; // Document ID
  participantIds: string[];
  participants: {
    [key: string]: {
      name: string;
      photoURL: string;
    };
  };
  jobId: string;
  jobTitle: string;
  lastMessageText?: string;
  lastMessageTimestamp?: Timestamp;
  lastMessageSenderId?: string;
  lastReadBy?: { [key: string]: Timestamp };
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

// Type for a message document
export interface ChatMessage {
    id: string; // Document ID
    senderId: string;
    text: string;
    createdAt: Timestamp;
}


/**
 * Finds an existing chat between two users for a specific job, or creates a new one.
 * @returns The ID of the existing or new chat.
 */
export async function findOrCreateChat(
  firestore: Firestore,
  currentUser: User,
  otherUser: { uid: string; name: string; photoURL: string },
  job: { id: string; title: string }
): Promise<string> {
  const chatsRef = collection(firestore, 'chats');
  
  // Query for a chat with these exact two participants for this job
  const q = query(
    chatsRef,
    where('jobId', '==', job.id),
    where('participantIds', 'array-contains', currentUser.uid)
  );

  const querySnapshot = await getDocs(q);
  const existingChats = querySnapshot.docs.filter(doc => doc.data().participantIds.includes(otherUser.uid));

  if (existingChats.length > 0) {
    // Chat already exists
    return existingChats[0].id;
  } else {
    // Create a new chat
    const newChatRef = await addDoc(chatsRef, {
      participantIds: [currentUser.uid, otherUser.uid],
      participants: {
        [currentUser.uid]: {
          name: currentUser.displayName || 'مستخدم',
          photoURL: currentUser.photoURL || '',
        },
        [otherUser.uid]: {
          name: otherUser.name,
          photoURL: otherUser.photoURL,
        },
      },
      jobId: job.id,
      jobTitle: job.title,
      lastReadBy: {
        [currentUser.uid]: serverTimestamp(), // Creator has "read" it by creating it.
      },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastMessageText: '',
    });
    return newChatRef.id;
  }
}

/**
 * Sends a message in a chat and updates the chat's metadata.
 */
export async function sendMessage(
  firestore: Firestore,
  chatId: string,
  senderId: string,
  text: string
) {
  if (!text.trim()) return;

  const chatRef = doc(firestore, 'chats', chatId);
  const messagesRef = collection(chatRef, 'messages');

  const batch = writeBatch(firestore);

  // 1. Add the new message
  const newMessageRef = doc(messagesRef);
  batch.set(newMessageRef, {
    senderId,
    text,
    createdAt: serverTimestamp(),
  });

  // 2. Update the parent chat document
  batch.update(chatRef, {
    lastMessageText: text,
    lastMessageSenderId: senderId,
    updatedAt: serverTimestamp(),
    lastMessageTimestamp: serverTimestamp(),
    [`lastReadBy.${senderId}`]: serverTimestamp() // Sender has read their own message
  });


  await batch.commit();
}


/**
 * Marks a chat as read by the specified user by updating their lastReadBy timestamp.
 * @param firestore The Firestore instance.
 * @param chatId The ID of the chat to mark as read.
 * @param userId The ID of the user who is reading the chat.
 */
export async function markChatAsRead(
  firestore: Firestore,
  chatId: string,
  userId: string
) {
  const chatRef = doc(firestore, 'chats', chatId);
  try {
    await updateDoc(chatRef, {
      [`lastReadBy.${userId}`]: serverTimestamp(),
    });
  } catch (error) {
    console.error("Failed to mark chat as read:", error);
  }
}
