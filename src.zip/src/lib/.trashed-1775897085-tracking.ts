'use client';

import { doc, updateDoc, increment, Firestore } from "firebase/firestore";

// Helper function to get or create a unique visitor ID
function getVisitorId(): string {
  if (typeof window === 'undefined') {
    // Return a dummy ID for server-side rendering, it won't be used for writes
    return 'server-side-visitor';
  }
  let id = localStorage.getItem("visitorId");
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem("visitorId", id);
  }
  return id;
}

/**
 * Records a view for a job if the visitor hasn't viewed it before.
 * This is a "fire-and-forget" operation from the UI's perspective.
 * It first updates Firestore, and only on success does it update localStorage.
 */
export async function recordJobView(db: Firestore, jobId: string) {
  if (typeof window === 'undefined') return;
  
  const visitorId = getVisitorId();
  const key = `view_${jobId}_${visitorId}`;

  // If the user has viewed this on this device, don't do anything.
  if (localStorage.getItem(key)) {
    return;
  }

  const jobRef = doc(db, "jobs", jobId);
  try {
    // 1. Update Firestore
    await updateDoc(jobRef, {
      views: increment(1)
    });
    
    // 2. If Firestore update is successful, update localStorage
    localStorage.setItem(key, "true");
  } catch (error) {
    console.error("Error recording view:", error);
    // Fail silently for views. If Firestore fails, we don't set the localStorage key,
    // so it might try again on the next visit, which is acceptable for views.
  }
}

/**
 * Toggles a like for a job for the current visitor.
 * Returns true if the job is now liked, false if it is now unliked.
 * This function is designed to be robust against inconsistencies.
 */
export async function toggleJobLike(db: Firestore, jobId: string): Promise<boolean> {
  if (typeof window === 'undefined') {
      throw new Error("toggleJobLike can only be called on the client.");
  }

  const visitorId = getVisitorId();
  const key = `like_${jobId}_${visitorId}`;
  const jobRef = doc(db, "jobs", jobId);
  const isCurrentlyLiked = !!localStorage.getItem(key);

  try {
    if (isCurrentlyLiked) {
      // UNLIKE: Update Firestore first
      await updateDoc(jobRef, { likes: increment(-1) });
      // If successful, update localStorage
      localStorage.removeItem(key);
      return false; // Now unliked
    } else {
      // LIKE: Update Firestore first
      await updateDoc(jobRef, { likes: increment(1) });
      // If successful, update localStorage
      localStorage.setItem(key, "true");
      return true; // Now liked
    }
  } catch (error) {
    console.error("Error toggling like:", error);
    // If Firestore update fails, we don't touch localStorage and re-throw
    // so the UI can know about the failure and not change its state.
    throw error;
  }
}

/**
 * Checks if a job has been liked by the current visitor, based on localStorage.
 */
export function isJobLikedByVisitor(jobId: string): boolean {
    if (typeof window === 'undefined') return false;
    const visitorId = getVisitorId();
    const key = `like_${jobId}_${visitorId}`;
    return !!localStorage.getItem(key);
}
