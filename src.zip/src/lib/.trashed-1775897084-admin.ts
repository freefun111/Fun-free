'use client';
import { Firestore, doc, updateDoc, deleteDoc, Timestamp } from 'firebase/firestore';

export const approveJob = async (db: Firestore, jobId: string, durationDays: number | null | undefined) => {
    const jobRef = doc(db, 'jobs', jobId);
    const updateData: any = {
        status: 'active',
        updatedAt: Timestamp.now(),
    };
    if (durationDays) {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + durationDays);
        updateData.packageExpiresAt = Timestamp.fromDate(expiryDate);
    }
    await updateDoc(jobRef, updateData);
};

export const rejectJob = async (db: Firestore, jobId: string) => {
    const jobRef = doc(db, 'jobs', jobId);
    await updateDoc(jobRef, { status: 'rejected', updatedAt: Timestamp.now() });
};

export const deleteJobAsAdmin = async (db: Firestore, jobId: string) => {
    const jobRef = doc(db, 'jobs', jobId);
    await deleteDoc(jobRef);
};
